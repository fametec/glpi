#GLPI Dump database on 2018-08-13 18:41

### Dump table glpi_alerts

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_apiclients

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token_date` datetime DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_apiclients` VALUES ('1','0','1','full access from localhost',NULL,'1','2130706433','2130706433','::1','',NULL,'0',NULL);

### Dump table glpi_authldapreplicates

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authldaps_id` (`authldaps_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authldaps

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `condition` text COLLATE utf8_unicode_ci,
  `login_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `sync_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_tls` tinyint(1) NOT NULL DEFAULT '0',
  `group_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_condition` text COLLATE utf8_unicode_ci,
  `group_search_type` int(11) NOT NULL DEFAULT '0',
  `group_member_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_dn` tinyint(1) NOT NULL DEFAULT '1',
  `time_offset` int(11) NOT NULL DEFAULT '0' COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT '0',
  `title_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_condition` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `rootdn_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email3_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email4_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT '0',
  `ldap_maxlimit` int(11) NOT NULL DEFAULT '0',
  `can_support_pagesize` tinyint(1) NOT NULL DEFAULT '0',
  `picture_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `inventory_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_default` (`is_default`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`),
  KEY `sync_field` (`sync_field`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_authldaps` VALUES ('1','fameconsultoria','192.168.56.150','DC=fameconsultoria,DC=local','glpi@fameconsultoria.local','389','(&(objectClass=user)(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))','samaccountname','objectguid','0','memberof','(&(objectClass=user)(objectCategory=person)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))','0','','mail','sn','givenname','telephonenumber','othertelephone','mobile','info','1','0','0','title',NULL,NULL,'ou','(objectclass=organizationalUnit)','2018-01-13 14:53:05','','1','1','57itynr01qk=','employeenumber','','','',NULL,'0','0','0',NULL,'2018-01-13 14:53:05',NULL);

### Dump table glpi_authmails

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connect_string` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_autoupdatesystems

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklistedmailcontents

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklists

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_blacklists` VALUES ('1','1','empty IP','',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('2','1','localhost','127.0.0.1',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('3','1','zero IP','0.0.0.0',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('4','2','empty MAC','',NULL,NULL,NULL);

### Dump table glpi_budgets

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `budgettypes_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_template` (`is_template`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `locations_id` (`locations_id`),
  KEY `budgettypes_id` (`budgettypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_budgets` VALUES ('2','&lt;Departamento&gt;','0','0','Orçamento Anual &lt;Departamento&gt;','0','2018-01-01','2018-12-31','1000000.0000','1','Orçamento anual','2018-05-21 14:44:26','2018-05-21 14:44:26','1','1');
INSERT INTO `glpi_budgets` VALUES ('3','DTI 2018','0','0','Orçamento Anual DTI','0','2018-01-01','2018-12-31','1000000.0000','0','Orçamento anual','2018-05-21 14:47:38','2018-05-21 14:47:38','1','1');

### Dump table glpi_budgettypes

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_budgettypes` VALUES ('1','Anual','Orçamento Anual','2018-05-21 14:22:05','2018-05-21 14:22:05');
INSERT INTO `glpi_budgettypes` VALUES ('2','Projetos','','2018-05-21 14:22:16','2018-05-21 14:22:16');

### Dump table glpi_businesscriticities

DROP TABLE IF EXISTS `glpi_businesscriticities`;
CREATE TABLE `glpi_businesscriticities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `businesscriticities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`businesscriticities_id`,`name`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendars

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `cache_duration` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendars` VALUES ('1','Default','0','1','Default calendar','2018-01-13 14:36:13','[86399,86399,86399,86399,86399,86399,86399]',NULL);

### Dump table glpi_calendars_holidays

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `holidays_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  KEY `holidays_id` (`holidays_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendarsegments

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `day` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendars_id` (`calendars_id`),
  KEY `day` (`day`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendarsegments` VALUES ('8','1','0','1','0','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('9','1','0','1','1','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('15','1','0','1','3','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('16','1','0','1','2','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('17','1','0','1','4','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('18','1','0','1','5','00:00:00','24:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('19','1','0','1','6','00:00:00','24:00:00');

### Dump table glpi_cartridgeitems

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitems_printermodels

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitemtypes

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridges

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printers_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`),
  KEY `printers_id` (`printers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificates

DROP TABLE IF EXISTS `glpi_certificates`;
CREATE TABLE `glpi_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `certificatetypes_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_certificatetypes (id)',
  `dns_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dns_suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (id)',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (id)',
  `locations_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_locations (id)',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_manufacturers (id)',
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_autosign` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` date DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to states (id)',
  `command` text COLLATE utf8_unicode_ci,
  `certificate_request` text COLLATE utf8_unicode_ci,
  `certificate_item` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_template` (`is_template`),
  KEY `is_deleted` (`is_deleted`),
  KEY `certificatetypes_id` (`certificatetypes_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificates_items

DROP TABLE IF EXISTS `glpi_certificates_items`;
CREATE TABLE `glpi_certificates_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certificates_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various tables, according to itemtype (id)',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'see .class.php file',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`certificates_id`,`itemtype`,`items_id`),
  KEY `device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificatetypes

DROP TABLE IF EXISTS `glpi_certificatetypes`;
CREATE TABLE `glpi_certificatetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changecosts

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `changes_id` (`changes_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `time_to_resolve` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `controlistcontent` longtext COLLATE utf8_unicode_ci,
  `rolloutplancontent` longtext COLLATE utf8_unicode_ci,
  `backoutplancontent` longtext COLLATE utf8_unicode_ci,
  `checklistcontent` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `global_validation` (`global_validation`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_groups

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_items

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_problems

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `problems_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  KEY `problems_id` (`problems_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_projects

DROP TABLE IF EXISTS `glpi_changes_projects`;
CREATE TABLE `glpi_changes_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`projects_id`),
  KEY `projects_id` (`projects_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_suppliers

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_tickets

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_users

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changetasks

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `changes_id` (`changes_id`),
  KEY `state` (`state`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changevalidations

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `changes_id` (`changes_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerantiviruses

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `antivirus_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_uptodate` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `antivirus_version` (`antivirus_version`),
  KEY `signature_version` (`signature_version`),
  KEY `is_active` (`is_active`),
  KEY `is_uptodate` (`is_uptodate`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `is_deleted` (`is_deleted`),
  KEY `computers_id` (`computers_id`),
  KEY `date_expiration` (`date_expiration`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computermodels

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `power_consumption` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computermodels` VALUES ('1','M3333','','3333','0','1','1','0','0','0',NULL,NULL,'2017-11-29 10:07:05','2017-11-29 10:07:05');
INSERT INTO `glpi_computermodels` VALUES ('2','VirtualBox','',NULL,'0','1','1','0','0','0',NULL,NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_computermodels` VALUES ('3','SM-N9005','',NULL,'0','1','1','0','0','0',NULL,NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_computers

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `autoupdatesystems_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `computermodels_id` (`computermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `computertypes_id` (`computertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `uuid` (`uuid`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computers` VALUES ('1','0','&lt;DESK-\\Y-###&gt;','','&lt;PAT-\\Y-###&gt;','','','4','0','','2017-11-29 10:07:36','0','1','0','0','1','1','1','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:07:36','0');
INSERT INTO `glpi_computers` VALUES ('2','0','DESK-2017-001','56789','PAT-2017-001','','','4','0','','2017-11-29 10:10:28','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:26','0');
INSERT INTO `glpi_computers` VALUES ('3','0','DESK-2017-002','34567','PAT-2017-002','','','4','0','','2017-11-29 10:10:39','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:33','0');
INSERT INTO `glpi_computers` VALUES ('4','0','DESK-2017-003','67890','PAT-2017-003','','','4','0','','2017-11-29 10:10:50','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:37','0');
INSERT INTO `glpi_computers` VALUES ('5','0','DESK-2017-004','9876','PAT-2017-004','','','4','0','','2017-11-29 10:11:26','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:39','0');
INSERT INTO `glpi_computers` VALUES ('6','0','DESK-2017-005','12345','PAT-2017-005','','','4','0','','2017-11-29 10:09:49','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:49','0');
INSERT INTO `glpi_computers` VALUES ('7','0','DESK-2017-006','2345','PAT-2017-006','','','4','0','','2017-11-29 10:09:56','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:09:56','0');
INSERT INTO `glpi_computers` VALUES ('8','0','DESK-2017-007','23456','PAT-2017-007','','','4','0','','2017-11-30 10:29:09','0','1','0','0','1','1','0','Desktop Exemplo','1','0','0','0','0','1','0.0000','','2017-11-29 10:10:02','0');
INSERT INTO `glpi_computers` VALUES ('9','0','otrs-fame','0',NULL,'root',NULL,'0','0','x86_64/00-00-00 00:23:50
Trocar: 1021','2018-01-17 00:11:27','0','0','0','0','2','3','0',NULL,'8','0','1','0','0','0','0.0000','BC245795-8083-462C-A8E5-C82B1457EAB3','2018-01-17 00:11:27','0');
INSERT INTO `glpi_computers` VALUES ('10','0','MUZZIO-WIN8','Oracle Corporation',NULL,NULL,NULL,'0','0','Trocar: 4089','2018-01-17 00:11:29','0','0','1','0','2','3','0',NULL,'8','0','1','0','0','0','0.0000','014C18CD-DAE1-464E-BC44-88C444F48E07','2018-01-17 00:11:29','0');
INSERT INTO `glpi_computers` VALUES ('11','0','localhost','0',NULL,'root',NULL,'0','0','x86_64/00-00-00 00:09:37
Trocar: 819','2018-01-17 00:11:29','0','0','0','0','2','3','0',NULL,'8','0','1','0','0','0','0.0000','B5024166-731C-4D79-8BD5-A7C6675EB681','2018-01-17 00:11:29','0');
INSERT INTO `glpi_computers` VALUES ('12','0','SM-N9005-3a90c8d173014a1d','c76ab2a1',NULL,'dpi',NULL,'0','0','Trocar: 1023','2018-01-17 00:11:29','0','0','1','0','3','4','0',NULL,'24','0','1','0','0','0','0.0000',NULL,'2018-01-17 00:11:29','0');

### Dump table glpi_computers_items

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computers_items` VALUES ('1','2','2','Monitor','0','0');
INSERT INTO `glpi_computers_items` VALUES ('2','3','3','Monitor','0','0');
INSERT INTO `glpi_computers_items` VALUES ('3','9','4','Monitor','0','0');
INSERT INTO `glpi_computers_items` VALUES ('4','9','5','Monitor','0','0');
INSERT INTO `glpi_computers_items` VALUES ('5','9','6','Monitor','0','0');
INSERT INTO `glpi_computers_items` VALUES ('6','2','2','Peripheral','0','0');
INSERT INTO `glpi_computers_items` VALUES ('7','2','2','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('8','2','3','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('9','2','4','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('10','2','5','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('11','2','6','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('12','2','7','Printer','0','0');
INSERT INTO `glpi_computers_items` VALUES ('13','2','8','Printer','0','0');

### Dump table glpi_computers_softwarelicenses

DROP TABLE IF EXISTS `glpi_computers_softwarelicenses`;
CREATE TABLE `glpi_computers_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `softwarelicenses_id` (`softwarelicenses_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computers_softwarelicenses` VALUES ('5','2','2','0','0');
INSERT INTO `glpi_computers_softwarelicenses` VALUES ('6','3','2','0','0');

### Dump table glpi_computers_softwareversions

DROP TABLE IF EXISTS `glpi_computers_softwareversions`;
CREATE TABLE `glpi_computers_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted_computer` tinyint(1) NOT NULL DEFAULT '0',
  `is_template_computer` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_install` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwareversions_id`),
  KEY `softwareversions_id` (`softwareversions_id`),
  KEY `computers_info` (`entities_id`,`is_template_computer`,`is_deleted_computer`),
  KEY `is_template` (`is_template_computer`),
  KEY `is_deleted` (`is_deleted_computer`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_install` (`date_install`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computers_softwareversions` VALUES ('4','2','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('5','3','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('6','4','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('7','5','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('8','6','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('9','7','2','0','0','0','0','0',NULL);
INSERT INTO `glpi_computers_softwareversions` VALUES ('10','8','2','0','0','0','0','0',NULL);

### Dump table glpi_computertypes

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computertypes` VALUES ('1','Desktop','','2017-11-29 10:05:50','2017-11-29 10:05:50');
INSERT INTO `glpi_computertypes` VALUES ('2','Laptop','','2017-11-29 10:05:56','2017-11-29 10:05:56');
INSERT INTO `glpi_computertypes` VALUES ('3','Other','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_computertypes` VALUES ('4','Mobile','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_computervirtualmachines

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinesystems_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinetypes_id` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  KEY `vcpu` (`vcpu`),
  KEY `ram` (`ram`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `uuid` (`uuid`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_configs

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `context` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`context`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_configs` VALUES ('1','core','version','9.3.0');
INSERT INTO `glpi_configs` VALUES ('2','core','show_jobs_at_login','0');
INSERT INTO `glpi_configs` VALUES ('3','core','cut','250');
INSERT INTO `glpi_configs` VALUES ('4','core','list_limit','15');
INSERT INTO `glpi_configs` VALUES ('5','core','list_limit_max','50');
INSERT INTO `glpi_configs` VALUES ('6','core','url_maxlength','30');
INSERT INTO `glpi_configs` VALUES ('7','core','event_loglevel','5');
INSERT INTO `glpi_configs` VALUES ('8','core','notifications_mailing','1');
INSERT INTO `glpi_configs` VALUES ('9','core','admin_email','chamados@eftech.com.br');
INSERT INTO `glpi_configs` VALUES ('10','core','admin_email_name','GLPI');
INSERT INTO `glpi_configs` VALUES ('11','core','admin_reply','');
INSERT INTO `glpi_configs` VALUES ('12','core','admin_reply_name','');
INSERT INTO `glpi_configs` VALUES ('13','core','mailing_signature','--
Sistema de Chamados
FAME Consultoria
chamados@fameconsultoria.com.br
');
INSERT INTO `glpi_configs` VALUES ('14','core','use_anonymous_helpdesk','0');
INSERT INTO `glpi_configs` VALUES ('15','core','use_anonymous_followups','0');
INSERT INTO `glpi_configs` VALUES ('16','core','language','pt_BR');
INSERT INTO `glpi_configs` VALUES ('17','core','priority_1','#fff2f2');
INSERT INTO `glpi_configs` VALUES ('18','core','priority_2','#ffe0e0');
INSERT INTO `glpi_configs` VALUES ('19','core','priority_3','#ffcece');
INSERT INTO `glpi_configs` VALUES ('20','core','priority_4','#ffbfbf');
INSERT INTO `glpi_configs` VALUES ('21','core','priority_5','#ffadad');
INSERT INTO `glpi_configs` VALUES ('22','core','priority_6','#ff5555');
INSERT INTO `glpi_configs` VALUES ('23','core','date_tax','2005-12-31');
INSERT INTO `glpi_configs` VALUES ('24','core','cas_host','');
INSERT INTO `glpi_configs` VALUES ('25','core','cas_port','443');
INSERT INTO `glpi_configs` VALUES ('26','core','cas_uri','');
INSERT INTO `glpi_configs` VALUES ('27','core','cas_logout','');
INSERT INTO `glpi_configs` VALUES ('28','core','existing_auth_server_field_clean_domain','0');
INSERT INTO `glpi_configs` VALUES ('29','core','planning_begin','08:00:00');
INSERT INTO `glpi_configs` VALUES ('30','core','planning_end','20:00:00');
INSERT INTO `glpi_configs` VALUES ('31','core','utf8_conv','1');
INSERT INTO `glpi_configs` VALUES ('32','core','use_public_faq','0');
INSERT INTO `glpi_configs` VALUES ('33','core','url_base','http://192.168.56.101/glpi');
INSERT INTO `glpi_configs` VALUES ('34','core','show_link_in_mail','0');
INSERT INTO `glpi_configs` VALUES ('35','core','text_login','');
INSERT INTO `glpi_configs` VALUES ('36','core','founded_new_version','');
INSERT INTO `glpi_configs` VALUES ('37','core','dropdown_max','100');
INSERT INTO `glpi_configs` VALUES ('38','core','ajax_wildcard','*');
INSERT INTO `glpi_configs` VALUES ('42','core','ajax_limit_count','10');
INSERT INTO `glpi_configs` VALUES ('43','core','use_ajax_autocompletion','1');
INSERT INTO `glpi_configs` VALUES ('44','core','is_users_auto_add','1');
INSERT INTO `glpi_configs` VALUES ('45','core','date_format','0');
INSERT INTO `glpi_configs` VALUES ('46','core','number_format','0');
INSERT INTO `glpi_configs` VALUES ('47','core','csv_delimiter',';');
INSERT INTO `glpi_configs` VALUES ('48','core','is_ids_visible','0');
INSERT INTO `glpi_configs` VALUES ('50','core','smtp_mode','0');
INSERT INTO `glpi_configs` VALUES ('51','core','smtp_host','');
INSERT INTO `glpi_configs` VALUES ('52','core','smtp_port','25');
INSERT INTO `glpi_configs` VALUES ('53','core','smtp_username','');
INSERT INTO `glpi_configs` VALUES ('54','core','proxy_name','');
INSERT INTO `glpi_configs` VALUES ('55','core','proxy_port','8080');
INSERT INTO `glpi_configs` VALUES ('56','core','proxy_user','');
INSERT INTO `glpi_configs` VALUES ('57','core','add_followup_on_update_ticket','1');
INSERT INTO `glpi_configs` VALUES ('58','core','keep_tickets_on_delete','0');
INSERT INTO `glpi_configs` VALUES ('59','core','time_step','5');
INSERT INTO `glpi_configs` VALUES ('60','core','decimal_number','2');
INSERT INTO `glpi_configs` VALUES ('61','core','helpdesk_doc_url','');
INSERT INTO `glpi_configs` VALUES ('62','core','central_doc_url','');
INSERT INTO `glpi_configs` VALUES ('63','core','documentcategories_id_forticket','0');
INSERT INTO `glpi_configs` VALUES ('64','core','monitors_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('65','core','phones_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('66','core','peripherals_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('67','core','printers_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('68','core','use_log_in_files','1');
INSERT INTO `glpi_configs` VALUES ('69','core','time_offset','0');
INSERT INTO `glpi_configs` VALUES ('70','core','is_contact_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('71','core','is_user_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('72','core','is_group_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('73','core','is_location_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('74','core','state_autoupdate_mode','0');
INSERT INTO `glpi_configs` VALUES ('75','core','is_contact_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('76','core','is_user_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('77','core','is_group_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('78','core','is_location_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('79','core','state_autoclean_mode','0');
INSERT INTO `glpi_configs` VALUES ('80','core','use_flat_dropdowntree','0');
INSERT INTO `glpi_configs` VALUES ('81','core','use_autoname_by_entity','1');
INSERT INTO `glpi_configs` VALUES ('84','core','softwarecategories_id_ondelete','1');
INSERT INTO `glpi_configs` VALUES ('85','core','x509_email_field','');
INSERT INTO `glpi_configs` VALUES ('86','core','x509_cn_restrict','');
INSERT INTO `glpi_configs` VALUES ('87','core','x509_o_restrict','');
INSERT INTO `glpi_configs` VALUES ('88','core','x509_ou_restrict','');
INSERT INTO `glpi_configs` VALUES ('89','core','default_mailcollector_filesize_max','2097152');
INSERT INTO `glpi_configs` VALUES ('90','core','followup_private','0');
INSERT INTO `glpi_configs` VALUES ('91','core','task_private','0');
INSERT INTO `glpi_configs` VALUES ('92','core','default_software_helpdesk_visible','1');
INSERT INTO `glpi_configs` VALUES ('93','core','names_format','0');
INSERT INTO `glpi_configs` VALUES ('95','core','default_requesttypes_id','1');
INSERT INTO `glpi_configs` VALUES ('96','core','use_noright_users_add','1');
INSERT INTO `glpi_configs` VALUES ('97','core','cron_limit','5');
INSERT INTO `glpi_configs` VALUES ('98','core','priority_matrix','{\"1\":{\"1\":1,\"2\":1,\"3\":2,\"4\":2,\"5\":2},\"2\":{\"1\":1,\"2\":2,\"3\":2,\"4\":3,\"5\":3},\"3\":{\"1\":2,\"2\":2,\"3\":3,\"4\":4,\"5\":4},\"4\":{\"1\":2,\"2\":3,\"3\":4,\"4\":4,\"5\":5},\"5\":{\"1\":2,\"2\":3,\"3\":4,\"4\":5,\"5\":5}}');
INSERT INTO `glpi_configs` VALUES ('99','core','urgency_mask','62');
INSERT INTO `glpi_configs` VALUES ('100','core','impact_mask','62');
INSERT INTO `glpi_configs` VALUES ('101','core','user_deleted_ldap','0');
INSERT INTO `glpi_configs` VALUES ('102','core','auto_create_infocoms','0');
INSERT INTO `glpi_configs` VALUES ('103','core','use_slave_for_search','0');
INSERT INTO `glpi_configs` VALUES ('104','core','proxy_passwd','');
INSERT INTO `glpi_configs` VALUES ('105','core','smtp_passwd','');
INSERT INTO `glpi_configs` VALUES ('106','core','transfers_id_auto','0');
INSERT INTO `glpi_configs` VALUES ('107','core','show_count_on_tabs','1');
INSERT INTO `glpi_configs` VALUES ('108','core','refresh_ticket_list','0');
INSERT INTO `glpi_configs` VALUES ('109','core','set_default_tech','1');
INSERT INTO `glpi_configs` VALUES ('110','core','allow_search_view','2');
INSERT INTO `glpi_configs` VALUES ('111','core','allow_search_all','1');
INSERT INTO `glpi_configs` VALUES ('112','core','allow_search_global','1');
INSERT INTO `glpi_configs` VALUES ('113','core','display_count_on_home','5');
INSERT INTO `glpi_configs` VALUES ('114','core','use_password_security','0');
INSERT INTO `glpi_configs` VALUES ('115','core','password_min_length','8');
INSERT INTO `glpi_configs` VALUES ('116','core','password_need_number','1');
INSERT INTO `glpi_configs` VALUES ('117','core','password_need_letter','1');
INSERT INTO `glpi_configs` VALUES ('118','core','password_need_caps','1');
INSERT INTO `glpi_configs` VALUES ('119','core','password_need_symbol','1');
INSERT INTO `glpi_configs` VALUES ('120','core','use_check_pref','0');
INSERT INTO `glpi_configs` VALUES ('121','core','notification_to_myself','1');
INSERT INTO `glpi_configs` VALUES ('122','core','duedateok_color','#06ff00');
INSERT INTO `glpi_configs` VALUES ('123','core','duedatewarning_color','#ffb800');
INSERT INTO `glpi_configs` VALUES ('124','core','duedatecritical_color','#ff0000');
INSERT INTO `glpi_configs` VALUES ('125','core','duedatewarning_less','20');
INSERT INTO `glpi_configs` VALUES ('126','core','duedatecritical_less','5');
INSERT INTO `glpi_configs` VALUES ('127','core','duedatewarning_unit','%');
INSERT INTO `glpi_configs` VALUES ('128','core','duedatecritical_unit','%');
INSERT INTO `glpi_configs` VALUES ('129','core','realname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('130','core','firstname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('131','core','email1_ssofield','');
INSERT INTO `glpi_configs` VALUES ('132','core','email2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('133','core','email3_ssofield','');
INSERT INTO `glpi_configs` VALUES ('134','core','email4_ssofield','');
INSERT INTO `glpi_configs` VALUES ('135','core','phone_ssofield','');
INSERT INTO `glpi_configs` VALUES ('136','core','phone2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('137','core','mobile_ssofield','');
INSERT INTO `glpi_configs` VALUES ('138','core','comment_ssofield','');
INSERT INTO `glpi_configs` VALUES ('139','core','title_ssofield','');
INSERT INTO `glpi_configs` VALUES ('140','core','category_ssofield','');
INSERT INTO `glpi_configs` VALUES ('141','core','language_ssofield','');
INSERT INTO `glpi_configs` VALUES ('142','core','entity_ssofield','');
INSERT INTO `glpi_configs` VALUES ('143','core','registration_number_ssofield','');
INSERT INTO `glpi_configs` VALUES ('144','core','ssovariables_id','0');
INSERT INTO `glpi_configs` VALUES ('145','core','translate_kb','0');
INSERT INTO `glpi_configs` VALUES ('146','core','translate_dropdowns','0');
INSERT INTO `glpi_configs` VALUES ('147','core','pdffont','helvetica');
INSERT INTO `glpi_configs` VALUES ('148','core','keep_devices_when_purging_item','0');
INSERT INTO `glpi_configs` VALUES ('149','core','maintenance_mode','0');
INSERT INTO `glpi_configs` VALUES ('150','core','maintenance_text','');
INSERT INTO `glpi_configs` VALUES ('151','core','use_rich_text','0');
INSERT INTO `glpi_configs` VALUES ('152','core','attach_ticket_documents_to_mail','1');
INSERT INTO `glpi_configs` VALUES ('153','core','backcreated','0');
INSERT INTO `glpi_configs` VALUES ('154','core','task_state','1');
INSERT INTO `glpi_configs` VALUES ('155','core','layout','lefttab');
INSERT INTO `glpi_configs` VALUES ('156','core','ticket_timeline','1');
INSERT INTO `glpi_configs` VALUES ('157','core','ticket_timeline_keep_replaced_tabs','0');
INSERT INTO `glpi_configs` VALUES ('158','core','palette','auror');
INSERT INTO `glpi_configs` VALUES ('159','core','lock_use_lock_item','0');
INSERT INTO `glpi_configs` VALUES ('160','core','lock_autolock_mode','1');
INSERT INTO `glpi_configs` VALUES ('161','core','lock_directunlock_notification','0');
INSERT INTO `glpi_configs` VALUES ('162','core','lock_item_list','[]');
INSERT INTO `glpi_configs` VALUES ('163','core','lock_lockprofile_id','8');
INSERT INTO `glpi_configs` VALUES ('164','core','set_default_requester','1');
INSERT INTO `glpi_configs` VALUES ('165','core','highcontrast_css','0');
INSERT INTO `glpi_configs` VALUES ('166','core','smtp_check_certificate','1');
INSERT INTO `glpi_configs` VALUES ('167','core','enable_api','0');
INSERT INTO `glpi_configs` VALUES ('168','core','enable_api_login_credentials','0');
INSERT INTO `glpi_configs` VALUES ('169','core','enable_api_login_external_token','1');
INSERT INTO `glpi_configs` VALUES ('170','core','url_base_api','http://192.168.56.101/glpi/apirest.php/');
INSERT INTO `glpi_configs` VALUES ('171','core','login_remember_time','604800');
INSERT INTO `glpi_configs` VALUES ('172','core','login_remember_default','1');
INSERT INTO `glpi_configs` VALUES ('173','core','use_notifications','1');
INSERT INTO `glpi_configs` VALUES ('174','core','notifications_ajax','1');
INSERT INTO `glpi_configs` VALUES ('175','core','notifications_ajax_check_interval','5');
INSERT INTO `glpi_configs` VALUES ('176','core','notifications_ajax_sound',NULL);
INSERT INTO `glpi_configs` VALUES ('177','core','notifications_ajax_icon_url','/pics/glpi.png');
INSERT INTO `glpi_configs` VALUES ('178','core','dbversion','9.3');
INSERT INTO `glpi_configs` VALUES ('179','core','smtp_max_retries','5');
INSERT INTO `glpi_configs` VALUES ('180','core','smtp_sender',NULL);
INSERT INTO `glpi_configs` VALUES ('181','core','from_email',NULL);
INSERT INTO `glpi_configs` VALUES ('182','core','from_email_name',NULL);
INSERT INTO `glpi_configs` VALUES ('183','core','instance_uuid','0gWvx8uS98RqMOhhSDuiYi0BpeOQSlukFf0kBPJe');
INSERT INTO `glpi_configs` VALUES ('184','core','registration_uuid','OQme4Tot0EYiOLRaHZQcriKYbxNHkEs3QSvpyucl');
INSERT INTO `glpi_configs` VALUES ('185','core','_no_history','');
INSERT INTO `glpi_configs` VALUES ('186','core','notifications_websocket','1');
INSERT INTO `glpi_configs` VALUES ('187','plugin:telegrambot','token','547981261:AAHyyjkdR8vr8VQO9smWDbS8Y6_OK2dJWcA');
INSERT INTO `glpi_configs` VALUES ('188','plugin:telegrambot','bot_username','glpi_fame_bot');
INSERT INTO `glpi_configs` VALUES ('189','core','smtp_retry_time','5');
INSERT INTO `glpi_configs` VALUES ('190','core','purge_computer_software_install','0');
INSERT INTO `glpi_configs` VALUES ('191','core','purge_software_computer_install','0');
INSERT INTO `glpi_configs` VALUES ('192','core','purge_software_version_install','0');
INSERT INTO `glpi_configs` VALUES ('193','core','purge_infocom_creation','0');
INSERT INTO `glpi_configs` VALUES ('194','core','purge_profile_user','0');
INSERT INTO `glpi_configs` VALUES ('195','core','purge_group_user','0');
INSERT INTO `glpi_configs` VALUES ('196','core','purge_adddevice','0');
INSERT INTO `glpi_configs` VALUES ('197','core','purge_updatedevice','0');
INSERT INTO `glpi_configs` VALUES ('198','core','purge_deletedevice','0');
INSERT INTO `glpi_configs` VALUES ('199','core','purge_connectdevice','0');
INSERT INTO `glpi_configs` VALUES ('200','core','purge_disconnectdevice','0');
INSERT INTO `glpi_configs` VALUES ('201','core','purge_userdeletedfromldap','0');
INSERT INTO `glpi_configs` VALUES ('202','core','purge_addrelation','0');
INSERT INTO `glpi_configs` VALUES ('203','core','purge_deleterelation','0');
INSERT INTO `glpi_configs` VALUES ('204','core','purge_createitem','0');
INSERT INTO `glpi_configs` VALUES ('205','core','purge_deleteitem','0');
INSERT INTO `glpi_configs` VALUES ('206','core','purge_restoreitem','0');
INSERT INTO `glpi_configs` VALUES ('207','core','purge_updateitem','0');
INSERT INTO `glpi_configs` VALUES ('208','core','purge_comments','0');
INSERT INTO `glpi_configs` VALUES ('209','core','purge_datemod','0');
INSERT INTO `glpi_configs` VALUES ('210','core','purge_all','0');
INSERT INTO `glpi_configs` VALUES ('211','core','purge_user_auth_changes','0');
INSERT INTO `glpi_configs` VALUES ('212','core','purge_plugins','0');

### Dump table glpi_consumableitems

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `consumableitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumableitemtypes

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumables

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `consumableitems_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `consumableitems_id` (`consumableitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacttypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `contacttypes_id` (`contacttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts_suppliers

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contacts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  KEY `contacts_id` (`contacts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacttypes

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contractcosts

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `contracts_id` (`contracts_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttypes_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `notice` int(11) NOT NULL DEFAULT '0',
  `periodicity` int(11) NOT NULL DEFAULT '0',
  `billing` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `accounting_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_monday` tinyint(1) NOT NULL DEFAULT '0',
  `max_links_allowed` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `renewal` int(11) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_date` (`begin_date`),
  KEY `name` (`name`),
  KEY `contracttypes_id` (`contracttypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `use_monday` (`use_monday`),
  KEY `use_saturday` (`use_saturday`),
  KEY `alert` (`alert`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_items

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  KEY `FK_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_suppliers

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  KEY `contracts_id` (`contracts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracttypes

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_crontasklogs

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crontasks_id` int(11) NOT NULL,
  `crontasklogs_id` int(11) NOT NULL COMMENT 'id of ''start'' event',
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'message',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `crontasks_id` (`crontasks_id`),
  KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_crontasklogs` VALUES ('1','18','0','2017-11-21 10:15:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('2','18','1','2017-11-21 10:15:42','2','0.00819993','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('3','19','0','2017-11-29 09:57:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('4','19','3','2017-11-29 09:57:12','2','0.121996','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('5','20','0','2017-11-29 10:07:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('6','20','5','2017-11-29 10:07:37','2','0.00320387','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('7','21','0','2017-11-30 09:53:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('8','21','7','2017-11-30 09:53:55','2','0.0504169','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('9','22','0','2017-11-30 09:59:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('10','22','9','2017-11-30 09:59:23','2','0.00279999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('11','23','0','2017-11-30 10:05:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('12','23','11','2017-11-30 10:05:31','2','0.029135','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('13','24','0','2017-11-30 10:12:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('14','24','13','2017-11-30 10:12:05','1','0.000931978','1','Apagar 1 arquivo temporário criado a mais de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('15','24','13','2017-11-30 10:12:05','2','0.00153112','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('16','25','0','2017-11-30 10:19:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('17','25','16','2017-11-30 10:19:01','2','0.00129318','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('18','30','0','2017-11-30 10:20:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('19','30','18','2017-11-30 10:20:48','2','1.97994','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('20','5','0','2017-11-30 10:26:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('21','5','20','2017-11-30 10:26:09','2','0.00111389','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('22','6','0','2017-11-30 10:32:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('23','6','22','2017-11-30 10:32:32','2','0.00457501','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('24','8','0','2017-11-30 10:39:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('25','8','24','2017-11-30 10:39:29','2','0.198897','297','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('26','9','0','2017-12-01 10:00:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('27','9','26','2017-12-01 10:00:52','2','0.075778','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('28','12','0','2017-12-01 10:08:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('29','12','28','2017-12-01 10:08:08','1','0.00138903','9','Limpar 9 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('30','12','28','2017-12-01 10:08:08','2','0.00181794','9','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('31','13','0','2017-12-01 10:13:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('32','13','31','2017-12-01 10:13:18','1','0.000984907','1','Limpar 1 arquivo de gráfico criado a mais de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('33','13','31','2017-12-01 10:13:18','2','0.00175595','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('34','14','0','2017-12-01 10:16:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('35','14','34','2017-12-01 10:16:50','2','0.00110912','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('36','15','0','2017-12-03 12:04:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('37','15','36','2017-12-03 12:04:09','2','0.115398','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('38','16','0','2017-12-03 12:52:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('39','16','38','2017-12-03 12:52:51','2','0.00124192','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('40','17','0','2017-12-03 13:04:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('41','17','40','2017-12-03 13:04:26','2','0.148945','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('42','32','0','2017-12-03 13:15:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('43','32','42','2017-12-03 13:15:41','2','0.0292828','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('44','18','0','2017-12-03 13:20:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('45','18','44','2017-12-03 13:20:43','2','0.00324893','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('46','20','0','2017-12-03 13:25:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('47','20','46','2017-12-03 13:25:51','2','0.00114584','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('48','19','0','2017-12-03 13:30:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('49','19','48','2017-12-03 13:30:52','2','0.00133491','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('50','21','0','2017-12-03 13:40:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('51','21','50','2017-12-03 13:40:43','2','0.00360918','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('52','22','0','2017-12-03 13:46:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('53','22','52','2017-12-03 13:46:31','2','0.00108695','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('54','24','0','2017-12-03 13:51:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('55','24','54','2017-12-03 13:51:39','2','0.000928879','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('56','23','0','2017-12-03 13:56:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('57','23','56','2017-12-03 13:56:49','2','0.00349498','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('58','9','0','2017-12-03 14:06:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('59','9','58','2017-12-03 14:06:20','2','0.115993','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('60','25','0','2017-12-03 14:14:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('61','25','60','2017-12-03 14:14:57','2','0.000846863','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('62','5','0','2017-12-03 14:21:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('63','5','62','2017-12-03 14:21:36','2','0.002249','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('64','6','0','2017-12-03 14:27:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('65','6','64','2017-12-03 14:27:17','2','0.000806093','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('66','13','0','2017-12-03 17:04:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('67','13','66','2017-12-03 17:04:49','2','0.0864489','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('68','14','0','2017-12-03 19:04:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('69','14','68','2017-12-03 19:04:06','2','0.00110006','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('70','12','0','2017-12-03 22:33:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('71','12','70','2017-12-03 22:33:48','1','0.0697691','6','Limpar 6 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('72','12','70','2017-12-03 22:33:48','2','0.07025','6','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('73','17','0','2017-12-06 10:15:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('74','17','73','2017-12-06 10:15:11','2','1.20385','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('75','32','0','2017-12-06 10:20:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('76','32','75','2017-12-06 10:20:22','2','0.0225959','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('77','21','0','2017-12-06 10:26:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('78','21','77','2017-12-06 10:26:57','2','0.00142407','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('79','22','0','2017-12-06 10:33:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('80','22','79','2017-12-06 10:33:32','2','0.000895023','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('81','9','0','2017-12-06 10:38:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('82','9','81','2017-12-06 10:38:44','2','0.117724','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('83','20','0','2017-12-07 10:13:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('84','20','83','2017-12-07 10:13:28','2','0.565899','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('85','24','0','2017-12-07 10:18:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('86','24','85','2017-12-07 10:18:59','2','0.00132394','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('87','13','0','2017-12-07 10:24:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('88','13','87','2017-12-07 10:24:01','2','0.00233102','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('89','14','0','2017-12-07 10:29:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('90','14','89','2017-12-07 10:29:09','2','0.0014329','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('91','15','0','2017-12-07 10:34:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('92','15','91','2017-12-07 10:34:13','2','0.00173593','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('93','16','0','2017-12-07 10:39:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('94','16','93','2017-12-07 10:39:53','2','0.00126982','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('95','18','0','2018-01-02 22:15:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('96','18','95','2018-01-02 22:15:58','2','0.252446','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('97','19','0','2018-01-02 22:34:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('98','19','97','2018-01-02 22:34:20','2','0.00113416','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('99','23','0','2018-01-05 23:40:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('100','23','99','2018-01-05 23:40:15','2','0.15879','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('101','25','0','2018-01-08 10:09:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('102','25','101','2018-01-08 10:09:09','2','0.0556591','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('103','5','0','2018-01-08 10:15:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('104','5','103','2018-01-08 10:15:05','2','0.00173593','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('105','6','0','2018-01-08 10:19:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('106','6','105','2018-01-08 10:19:37','2','0.000916958','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('107','12','0','2018-01-08 10:21:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('108','12','107','2018-01-08 10:21:30','1','0.00145578','11','Limpar 11 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('109','12','107','2018-01-08 10:21:30','2','0.00185084','11','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('110','17','0','2018-01-08 10:27:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('111','17','110','2018-01-08 10:27:01','2','0.00823212','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('112','32','0','2018-01-08 10:37:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('113','32','112','2018-01-08 10:37:46','2','0.043961','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('114','21','0','2018-01-08 10:43:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('115','21','114','2018-01-08 10:43:28','2','0.00102592','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('116','22','0','2018-01-08 10:48:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('117','22','116','2018-01-08 10:48:30','2','0.00146103','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('118','9','0','2018-01-08 10:50:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('119','9','118','2018-01-08 10:50:25','2','0.113478','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('120','8','0','2018-01-08 10:51:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('121','8','120','2018-01-08 10:51:57','2','0.959288','297','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('122','20','0','2018-01-08 10:52:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('123','20','122','2018-01-08 10:52:40','2','0.00170302','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('124','24','0','2018-01-08 10:55:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('125','24','124','2018-01-08 10:55:27','2','0.00109196','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('126','13','0','2018-01-08 10:56:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('127','13','126','2018-01-08 10:56:01','2','0.00116897','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('128','14','0','2018-01-09 10:20:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('129','14','128','2018-01-09 10:20:27','2','0.188055','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('130','15','0','2018-01-09 10:21:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('131','15','130','2018-01-09 10:21:31','2','0.00176311','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('132','16','0','2018-01-09 10:28:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('133','16','132','2018-01-09 10:28:49','2','0.00100303','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('134','30','0','2018-01-09 10:35:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('135','30','134','2018-01-09 10:35:39','2','2.32026','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('136','18','0','2018-01-09 07:44:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('137','18','136','2018-01-09 07:44:32','2','0.0113912','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('138','19','0','2018-01-09 17:04:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('139','19','138','2018-01-09 17:04:17','2','0.056134','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('140','23','0','2018-01-09 17:09:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('141','23','140','2018-01-09 17:09:34','2','0.0309479','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('142','17','0','2018-01-09 17:15:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('143','17','142','2018-01-09 17:15:21','2','0.00877714','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('144','32','0','2018-01-09 17:21:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('145','32','144','2018-01-09 17:21:08','2','0.0499558','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('146','21','0','2018-01-11 06:05:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('147','21','146','2018-01-11 06:05:29','2','0.107083','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('148','22','0','2018-01-11 06:12:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('149','22','148','2018-01-11 06:12:06','2','0.0026269','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('150','9','0','2018-01-11 06:18:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('151','9','150','2018-01-11 06:18:23','2','0.125789','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('152','20','0','2018-01-11 06:23:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('153','20','152','2018-01-11 06:23:30','2','0.00133705','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('154','24','0','2018-01-11 06:28:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('155','24','154','2018-01-11 06:28:43','2','0.00106406','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('156','13','0','2018-01-11 06:38:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('157','13','156','2018-01-11 06:38:01','2','0.00366712','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('158','25','0','2018-01-11 06:43:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('159','25','158','2018-01-11 06:43:10','2','0.0061779','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('160','5','0','2018-01-11 06:53:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('161','5','160','2018-01-11 06:53:45','2','0.00117612','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('162','6','0','2018-01-11 18:28:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('163','6','162','2018-01-11 18:28:23','2','0.0416071','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('164','12','0','2018-01-11 18:34:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('165','12','164','2018-01-11 18:34:35','1','0.0252101','2','Limpar 2 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('166','12','164','2018-01-11 18:34:35','2','0.0256281','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('167','9','0','2018-01-11 18:39:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('168','9','167','2018-01-11 18:39:21','1','0.00187683','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('169','9','167','2018-01-11 18:39:21','1','3.16061','0','Número de mensagens: disponíveis=0, restauradas=0, recusadas=0, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('170','9','167','2018-01-11 18:39:21','2','3.16121','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('171','14','0','2018-01-11 18:39:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('172','14','171','2018-01-11 18:39:44','2','0.000833035','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('173','9','0','2018-01-11 18:42:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('174','9','173','2018-01-11 18:42:30','1','0.00293183','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('175','9','173','2018-01-11 18:42:30','1','10.9361','1','Número de mensagens: disponíveis=1, restauradas=1, recusadas=1, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('176','9','173','2018-01-11 18:42:30','2','10.938','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('177','17','0','2018-01-11 18:45:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('178','17','177','2018-01-11 18:45:27','2','0.0011251','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('179','9','0','2018-01-11 18:45:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('180','9','179','2018-01-11 18:45:39','1','0.00225711','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('181','9','179','2018-01-11 18:45:39','1','4.74057','1','Número de mensagens: disponíveis=1, restauradas=1, recusadas=1, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('182','9','179','2018-01-11 18:45:39','2','4.74229','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('183','32','0','2018-01-11 18:50:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('184','32','183','2018-01-11 18:50:58','2','0.00126886','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('185','9','0','2018-01-11 18:52:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('186','9','185','2018-01-11 18:52:14','1','0.00286388','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('187','9','185','2018-01-11 18:52:14','1','5.39252','1','Número de mensagens: disponíveis=1, restauradas=1, recusadas=0, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('188','9','185','2018-01-11 18:52:14','2','5.39352','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('189','15','0','2018-01-11 18:56:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('190','15','189','2018-01-11 18:56:21','2','0.00131798','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('191','16','0','2018-01-11 19:01:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('192','16','191','2018-01-11 19:01:46','2','0.00115085','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('193','18','0','2018-01-11 20:44:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('194','18','193','2018-01-11 20:44:06','2','0.0107701','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('195','19','0','2018-01-11 20:49:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('196','19','195','2018-01-11 20:49:27','2','0.00196004','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('197','23','0','2018-01-11 20:55:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('198','23','197','2018-01-11 20:55:42','2','0.00184011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('199','21','0','2018-01-13 12:13:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('200','21','199','2018-01-13 12:13:27','2','0.000898123','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('201','22','0','2018-01-13 12:33:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('202','22','201','2018-01-13 12:33:14','2','0.000862122','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('203','20','0','2018-01-13 12:50:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('204','20','203','2018-01-13 12:50:12','2','0.00119901','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('205','9','0','2018-01-13 12:55:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('206','9','205','2018-01-13 12:55:06','1','0.00279999','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('207','9','205','2018-01-13 12:55:06','1','8.73959','6','Número de mensagens: disponíveis=6, restauradas=6, recusadas=1, erros=0, listanegra=5
');
INSERT INTO `glpi_crontasklogs` VALUES ('208','9','205','2018-01-13 12:55:06','2','8.74012','6','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('209','24','0','2018-01-13 12:55:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('210','24','209','2018-01-13 12:55:14','1','0.00120401','1','Apagar 1 arquivo temporário criado a mais de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('211','24','209','2018-01-13 12:55:14','2','0.002496','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('212','9','0','2018-01-13 12:57:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('213','9','212','2018-01-13 12:57:00','1','0.00246596','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('214','9','212','2018-01-13 12:57:00','1','4.74032','1','Número de mensagens: disponíveis=1, restauradas=1, recusadas=0, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('215','9','212','2018-01-13 12:57:00','2','4.74203','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('216','13','0','2018-01-13 13:00:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('217','13','216','2018-01-13 13:00:27','1','0.00100398','1','Limpar 1 arquivo de gráfico criado a mais de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('218','13','216','2018-01-13 13:00:27','2','0.00128102','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('219','9','0','2018-01-13 13:02:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('220','9','219','2018-01-13 13:02:05','1','0.00163913','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('221','9','219','2018-01-13 13:02:05','1','6.48036','3','Número de mensagens: disponíveis=3, restauradas=3, recusadas=0, erros=0, listanegra=2
');
INSERT INTO `glpi_crontasklogs` VALUES ('222','9','219','2018-01-13 13:02:05','2','6.48093','3','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('223','17','0','2018-01-13 13:06:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('224','17','223','2018-01-13 13:06:07','2','0.00105786','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('225','9','0','2018-01-13 13:07:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('226','9','225','2018-01-13 13:07:45','1','0.00158596','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('227','9','225','2018-01-13 13:07:45','1','5.75039','2','Número de mensagens: disponíveis=2, restauradas=2, recusadas=0, erros=0, listanegra=1
');
INSERT INTO `glpi_crontasklogs` VALUES ('228','9','225','2018-01-13 13:07:45','2','5.7519','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('229','32','0','2018-01-13 13:18:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('230','32','229','2018-01-13 13:18:14','2','0.00155807','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('231','14','0','2018-01-13 13:23:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('232','14','231','2018-01-13 13:23:19','2','0.00170112','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('233','25','0','2018-01-13 13:28:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('234','25','233','2018-01-13 13:28:40','2','0.00120091','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('235','5','0','2018-01-13 13:31:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('236','5','235','2018-01-13 13:31:01','2','0.021848','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('237','15','0','2018-01-13 13:32:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('238','15','237','2018-01-13 13:32:56','2','0.00174117','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('239','16','0','2018-01-13 13:38:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('240','16','239','2018-01-13 13:38:17','2','0.00125098','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('241','6','0','2018-01-13 13:43:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('242','6','241','2018-01-13 13:43:23','2','0.00107193','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('243','12','0','2018-01-13 13:45:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('244','12','243','2018-01-13 13:45:38','2','0.00119495','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('245','18','0','2018-01-13 13:47:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('246','18','245','2018-01-13 13:47:57','2','0.0121951','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('247','19','0','2018-01-13 13:50:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('248','19','247','2018-01-13 13:50:38','2','0.00113082','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('249','23','0','2018-01-13 13:52:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('250','23','249','2018-01-13 13:52:19','2','0.001472','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('251','21','0','2018-01-13 13:57:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('252','21','251','2018-01-13 13:57:28','2','0.00102091','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('253','22','0','2018-01-13 14:02:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('254','22','253','2018-01-13 14:02:30','2','0.247541','4','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('255','17','0','2018-01-13 14:08:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('256','17','255','2018-01-13 14:08:11','2','0.000957966','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('257','9','0','2018-01-13 14:08:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('258','9','257','2018-01-13 14:08:30','1','0.00163889','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('259','9','257','2018-01-13 14:08:30','1','13.8857','9','Número de mensagens: disponíveis=9, restauradas=9, recusadas=0, erros=0, listanegra=9
');
INSERT INTO `glpi_crontasklogs` VALUES ('260','9','257','2018-01-13 14:08:30','2','13.8869','9','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('261','32','0','2018-01-13 14:11:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('262','32','261','2018-01-13 14:11:16','2','0.00118208','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('263','20','0','2018-01-13 14:16:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('264','20','263','2018-01-13 14:16:29','2','0.00124788','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('265','24','0','2018-01-13 14:25:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('266','24','265','2018-01-13 14:25:24','2','0.00117588','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('267','13','0','2018-01-13 14:30:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('268','13','267','2018-01-13 14:30:29','2','0.000962019','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('269','21','0','2018-01-13 14:35:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('270','21','269','2018-01-13 14:35:37','2','0.000931978','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('271','22','0','2018-01-13 14:39:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('272','22','271','2018-01-13 14:39:40','2','0.141342','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('273','9','0','2018-01-13 14:41:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('274','9','273','2018-01-13 14:41:47','1','0.00131702','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('275','9','273','2018-01-13 14:41:47','1','13.9015','10','Número de mensagens: disponíveis=10, restauradas=10, recusadas=0, erros=0, listanegra=10
');
INSERT INTO `glpi_crontasklogs` VALUES ('276','9','273','2018-01-13 14:41:47','2','13.9025','10','Action completed, partially processed');
INSERT INTO `glpi_crontasklogs` VALUES ('277','17','0','2018-01-13 14:43:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('278','17','277','2018-01-13 14:43:47','2','0.00314903','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('279','32','0','2018-01-13 14:46:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('280','32','279','2018-01-13 14:46:24','2','0.00090313','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('281','14','0','2018-01-13 14:51:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('282','14','281','2018-01-13 14:51:33','2','0.00165892','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('283','21','0','2018-01-13 14:54:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('284','21','283','2018-01-13 14:54:58','2','0.00132298','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('285','22','0','2018-01-13 14:55:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('286','22','285','2018-01-13 14:55:39','2','0.237009','3','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('287','9','0','2018-01-13 14:57:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('288','9','287','2018-01-13 14:57:13','1','0.00152612','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('289','9','287','2018-01-13 14:57:13','1','19.1912','3','Número de mensagens: disponíveis=3, restauradas=3, recusadas=0, erros=0, listanegra=3
');
INSERT INTO `glpi_crontasklogs` VALUES ('290','9','287','2018-01-13 14:57:13','2','19.1928','3','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('291','17','0','2018-01-13 15:02:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('292','17','291','2018-01-13 15:02:37','2','0.034725','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('293','32','0','2018-01-13 15:03:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('294','32','293','2018-01-13 15:03:19','2','0.00121593','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('295','22','0','2018-01-13 16:38:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('296','22','295','2018-01-13 16:38:36','2','0.00150394','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('297','21','0','2018-01-16 23:57:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('298','21','297','2018-01-16 23:57:45','2','0.0793021','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('299','9','0','2018-01-17 00:09:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('300','9','299','2018-01-17 00:09:10','1','0.138019','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('301','9','299','2018-01-17 00:09:10','1','3.26651','0','Número de mensagens: disponíveis=0, restauradas=0, recusadas=0, erros=0, listanegra=0
');
INSERT INTO `glpi_crontasklogs` VALUES ('302','9','299','2018-01-17 00:09:10','2','3.26699','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('303','17','0','2018-01-18 21:21:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('304','17','303','2018-01-18 21:21:59','2','0.884525','12','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('305','32','0','2018-01-18 21:45:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('306','32','305','2018-01-18 21:45:22','2','0.00104189','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('307','39','0','2018-01-18 21:47:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('308','39','307','2018-01-18 21:47:45','1','2.57932','0','Action successfully completed');
INSERT INTO `glpi_crontasklogs` VALUES ('309','39','307','2018-01-18 21:47:45','2','2.58006','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('310','39','0','2018-01-18 21:49:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('311','39','310','2018-01-18 21:49:05','1','1.38816','0','Action successfully completed');
INSERT INTO `glpi_crontasklogs` VALUES ('312','39','310','2018-01-18 21:49:05','2','1.3885','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('313','20','0','2018-01-18 21:50:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('314','20','313','2018-01-18 21:50:23','2','0.00159001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('315','24','0','2018-01-18 21:53:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('316','24','315','2018-01-18 21:53:32','2','0.000999928','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('317','13','0','2018-02-28 18:36:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('318','13','317','2018-02-28 18:36:19','2','0.0773799','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('319','14','0','2018-02-28 18:36:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('320','14','319','2018-02-28 18:36:36','2','0.039742','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('321','22','0','2018-02-28 18:43:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('322','22','321','2018-02-28 18:43:40','2','0.156601','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('323','15','0','2018-02-28 19:00:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('324','15','323','2018-02-28 19:00:57','2','0.00158715','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('325','16','0','2018-03-10 06:54:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('326','16','325','2018-03-10 06:54:29','2','0.168183','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('327','25','0','2018-03-10 07:00:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('328','25','327','2018-03-10 07:00:54','2','0.137094','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('329','5','0','2018-03-10 07:06:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('330','5','329','2018-03-10 07:06:02','2','0.00363207','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('331','6','0','2018-03-20 07:50:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('332','6','331','2018-03-20 07:50:29','2','0.136418','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('333','12','0','2018-03-20 08:23:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('334','12','333','2018-03-20 08:23:35','1','0.00541496','21','Limpar 21 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('335','12','333','2018-03-20 08:23:35','2','0.00586104','21','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('336','18','0','2018-03-20 08:38:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('337','18','336','2018-03-20 08:38:28','2','0.00896502','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('338','19','0','2018-03-20 08:43:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('339','19','338','2018-03-20 08:43:34','2','0.00122309','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('340','23','0','2018-03-27 18:22:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('341','23','340','2018-03-27 18:22:24','2','0.183907','32','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('342','8','0','2018-03-27 18:28:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('343','8','342','2018-03-27 18:28:04','2','1.76342','332','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('344','21','0','2018-04-05 14:09:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('345','21','344','2018-04-05 14:09:40','2','0.593138','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('346','9','0','2018-05-14 19:08:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('347','9','346','2018-05-14 19:08:25','1','0.287112','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('348','9','346','2018-05-14 19:08:25','1','4.68715','0','Não foi possível conectar ao servidor coletor de e-mails
');
INSERT INTO `glpi_crontasklogs` VALUES ('349','9','346','2018-05-14 19:08:25','2','4.68822','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('350','17','0','2018-05-21 07:59:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('351','17','350','2018-05-21 07:59:31','2','0.288889','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('352','32','0','2018-05-21 14:01:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('353','32','352','2018-05-21 14:01:09','2','0.0999241','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('354','20','0','2018-05-21 14:13:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('355','20','354','2018-05-21 14:13:30','2','0.00802302','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('356','24','0','2018-05-21 14:19:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('357','24','356','2018-05-21 14:19:22','2','0.00121999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('358','30','0','2018-05-21 14:25:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('359','30','358','2018-05-21 14:25:19','2','2.6297','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('360','22','0','2018-05-21 14:28:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('361','22','360','2018-05-21 14:28:48','2','1.54606','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('362','13','0','2018-05-21 14:29:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('363','13','362','2018-05-21 14:29:01','2','0.00133586','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('364','14','0','2018-05-21 14:37:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('365','14','364','2018-05-21 14:37:03','2','0.00135994','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('366','15','0','2018-05-21 14:42:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('367','15','366','2018-05-21 14:42:18','2','0.00154281','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('368','16','0','2018-05-21 14:47:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('369','16','368','2018-05-21 14:47:38','2','0.00116611','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('370','25','0','2018-05-21 14:53:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('371','25','370','2018-05-21 14:53:17','2','0.167757','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('372','5','0','2018-05-21 14:58:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('373','5','372','2018-05-21 14:58:32','2','0.101491','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('374','6','0','2018-05-21 15:20:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('375','6','374','2018-05-21 15:20:35','2','0.00119901','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('376','12','0','2018-05-21 15:26:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('377','12','376','2018-05-21 15:26:11','1','0.00243306','15','Limpar 15 arquivos de sessão criados a mais de 1440 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('378','12','376','2018-05-21 15:26:11','2','0.00308418','15','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('379','18','0','2018-05-21 15:40:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('380','18','379','2018-05-21 15:40:11','2','0.0468009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('381','19','0','2018-05-21 15:46:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('382','19','381','2018-05-21 15:46:28','2','0.00158215','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('383','23','0','2018-05-21 15:57:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('384','23','383','2018-05-21 15:57:35','2','0.024678','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('385','8','0','2018-05-21 16:05:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('386','8','385','2018-05-21 16:05:17','2','0.129003','332','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('387','21','0','2018-05-21 16:10:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('388','21','387','2018-05-21 16:10:23','2','0.00343823','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('389','9','0','2018-05-21 16:19:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('390','9','389','2018-05-21 16:19:37','1','0.113911','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('391','9','389','2018-05-21 16:19:37','1','3.48073','0','Não foi possível conectar ao servidor coletor de e-mails
');
INSERT INTO `glpi_crontasklogs` VALUES ('392','9','389','2018-05-21 16:19:37','2','3.4823','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('393','17','0','2018-05-21 16:28:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('394','17','393','2018-05-21 16:28:58','2','0.00124907','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('395','32','0','2018-05-21 16:40:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('396','32','395','2018-05-21 16:40:49','2','0.00139403','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('397','22','0','2018-05-21 21:23:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('398','22','397','2018-05-21 21:23:39','2','0.31837','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('399','20','0','2018-05-21 21:29:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('400','20','399','2018-05-21 21:29:14','2','0.00143981','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('401','24','0','2018-05-21 21:34:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('402','24','401','2018-05-21 21:34:34','2','0.00109196','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('403','13','0','2018-05-21 21:53:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('404','13','403','2018-05-21 21:53:44','2','0.0036149','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('405','14','0','2018-05-21 22:01:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('406','14','405','2018-05-21 22:01:54','2','0.00173497','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('407','21','0','2018-05-21 22:07:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('408','21','407','2018-05-21 22:07:38','2','0.0431299','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('409','9','0','2018-05-21 22:09:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('410','9','409','2018-05-21 22:09:39','1','0.126816','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('411','9','409','2018-05-21 22:09:39','1','3.82442','0','Não foi possível conectar ao servidor coletor de e-mails
');
INSERT INTO `glpi_crontasklogs` VALUES ('412','9','409','2018-05-21 22:09:39','2','3.82606','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('413','17','0','2018-05-29 10:18:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('414','17','413','2018-05-29 10:18:55','2','0.208284','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('415','32','0','2018-05-29 10:46:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('416','32','415','2018-05-29 10:46:28','2','0.0786378','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('417','22','0','2018-07-09 21:47:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('418','22','417','2018-07-09 21:47:06','2','0.231488','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('419','21','0','2018-07-09 22:05:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('420','21','419','2018-07-09 22:05:05','2','0.12064','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('421','9','0','2018-07-09 23:09:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('422','9','421','2018-07-09 23:09:55','1','0.130113','0','Collect mails from chamados@eftech.com.br ({imap.gmail.com:993/imap/ssl})
');
INSERT INTO `glpi_crontasklogs` VALUES ('423','9','421','2018-07-09 23:09:55','1','3.76825','0','Não foi possível conectar ao servidor coletor de e-mails
');
INSERT INTO `glpi_crontasklogs` VALUES ('424','9','421','2018-07-09 23:09:55','2','3.76922','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('425','20','0','2018-07-09 23:14:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('426','20','425','2018-07-09 23:14:57','2','0.000943899','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('427','24','0','2018-07-09 23:31:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('428','24','427','2018-07-09 23:31:00','2','0.00127792','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('429','13','0','2018-07-09 23:36:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('430','13','429','2018-07-09 23:36:25','2','0.00146985','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('431','14','0','2018-07-29 08:26:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('432','14','431','2018-07-29 08:26:38','2','0.248514','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('433','15','0','2018-08-13 18:19:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('434','15','433','2018-08-13 18:19:49','2','0.0784941','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('435','30','0','2018-08-13 18:39:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('436','30','435','2018-08-13 18:39:34','2','9.16674','0','Action completed, fully processed');

### Dump table glpi_crontasks

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT '1' COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT '3' COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT '0',
  `hourmax` int(11) NOT NULL DEFAULT '24',
  `logs_lifetime` int(11) NOT NULL DEFAULT '30' COMMENT 'number of days',
  `lastrun` datetime DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`name`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Task run by internal / external cron.';

INSERT INTO `glpi_crontasks` VALUES ('2','CartridgeItem','cartridge','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('3','ConsumableItem','consumable','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('4','SoftwareLicense','software','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('5','Contract','contract','86400',NULL,'1','1','3','0','24','30','2018-05-21 14:58:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('6','InfoCom','infocom','86400',NULL,'1','1','3','0','24','30','2018-05-21 15:20:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('7','CronTask','logs','86400','30','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('9','MailCollector','mailgate','300','10','1','1','3','0','24','30','2018-07-09 23:09:00',NULL,NULL,'2018-01-13 13:07:58',NULL);
INSERT INTO `glpi_crontasks` VALUES ('10','DBconnection','checkdbreplicate','300',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('11','CronTask','checkupdate','604800',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('12','CronTask','session','86400',NULL,'1','1','3','0','24','30','2018-05-21 15:26:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('13','CronTask','graph','3600',NULL,'1','1','3','0','24','30','2018-07-09 23:36:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('14','ReservationItem','reservation','3600',NULL,'1','1','3','0','24','30','2018-07-29 08:26:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('15','Ticket','closeticket','43200',NULL,'1','1','3','0','24','30','2018-08-13 18:19:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('16','Ticket','alertnotclosed','43200',NULL,'1','1','3','0','24','30','2018-05-21 14:47:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('17','SlaLevel_Ticket','slaticket','300',NULL,'1','1','3','0','24','30','2018-05-29 10:18:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('18','Ticket','createinquest','86400',NULL,'1','1','3','0','24','30','2018-05-21 15:40:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('19','Crontask','watcher','86400',NULL,'1','1','3','0','24','30','2018-05-21 15:46:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('20','TicketRecurrent','ticketrecurrent','3600',NULL,'1','1','3','0','24','30','2018-07-09 23:14:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('21','PlanningRecall','planningrecall','300',NULL,'1','1','3','0','24','30','2018-07-09 22:05:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('22','QueuedNotification','queuednotification','60','50','1','1','3','0','24','30','2018-07-09 21:47:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('23','QueuedNotification','queuednotificationclean','86400','30','1','1','3','0','24','30','2018-05-21 15:57:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('24','Crontask','temp','3600',NULL,'1','1','3','0','24','30','2018-07-09 23:31:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('25','MailCollector','mailgateerror','86400',NULL,'1','1','3','0','24','30','2018-05-21 14:53:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('26','Crontask','circularlogs','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('27','ObjectLock','unlockobject','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('28','SavedSearch','countAll','604800',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('29','SavedSearch_Alert','savedsearchesalerts','86400',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('30','Telemetry','telemetry','2592000',NULL,'1','1','3','0','24','10','2018-08-13 18:39:00',NULL,NULL,'2018-08-13 18:39:19',NULL);
INSERT INTO `glpi_crontasks` VALUES ('31','Certificate','certificate','86400',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('32','OlaLevel_Ticket','olaticket','300',NULL,'1','1','3','0','24','30','2018-05-29 10:46:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('33','PluginOcsinventoryngThread','CleanOldThreads','3600','24','1','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('34','PluginOcsinventoryngOcsServer','ocsng','300',NULL,'1','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('35','PluginOcsinventoryngNotimportedcomputer','SendAlerts','600','24','1','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('36','PluginOcsinventoryngOcsServer','CleanOldAgents','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('37','PluginOcsinventoryngOcsServer','RestoreOldAgents','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('38','PluginOcsinventoryngRuleImportEntity','CheckRuleImportEntity','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,'2018-01-17 00:09:15','2018-01-17 00:09:15');
INSERT INTO `glpi_crontasks` VALUES ('39','PluginTelegrambotCron','messagelistener','300',NULL,'1','2','3','0','24','30','2018-01-18 21:49:00',NULL,'','2018-01-18 21:45:28','2018-01-18 21:45:28');
INSERT INTO `glpi_crontasks` VALUES ('40','PurgeLogs','PurgeLogs','604800','24','1','2','3','0','24','30',NULL,NULL,NULL,'2018-08-13 18:39:19','2018-08-13 18:39:19');

### Dump table glpi_datacenters

DROP TABLE IF EXISTS `glpi_datacenters`;
CREATE TABLE `glpi_datacenters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_dcrooms

DROP TABLE IF EXISTS `glpi_dcrooms`;
CREATE TABLE `glpi_dcrooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `vis_cols` int(11) DEFAULT NULL,
  `vis_rows` int(11) DEFAULT NULL,
  `blueprint` text COLLATE utf8_unicode_ci,
  `datacenters_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `datacenters_id` (`datacenters_id`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicebatteries

DROP TABLE IF EXISTS `glpi_devicebatteries`;
CREATE TABLE `glpi_devicebatteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `voltage` int(11) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `devicebatterytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicebatterymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicebatterymodels_id` (`devicebatterymodels_id`),
  KEY `devicebatterytypes_id` (`devicebatterytypes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicebatterymodels

DROP TABLE IF EXISTS `glpi_devicebatterymodels`;
CREATE TABLE `glpi_devicebatterymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicebatterytypes

DROP TABLE IF EXISTS `glpi_devicebatterytypes`;
CREATE TABLE `glpi_devicebatterytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasemodels

DROP TABLE IF EXISTS `glpi_devicecasemodels`;
CREATE TABLE `glpi_devicecasemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecases

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecasetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicecasemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicecasetypes_id` (`devicecasetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicecasemodels_id` (`devicecasemodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasetypes

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrolmodels

DROP TABLE IF EXISTS `glpi_devicecontrolmodels`;
CREATE TABLE `glpi_devicecontrolmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrols

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_raid` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicecontrolmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicecontrolmodels_id` (`devicecontrolmodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicecontrols` VALUES ('1','Host bridge [0600]','0',NULL,'9','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('2','ISA bridge [0601]','0',NULL,'10','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('3','IDE interface [0101]','0',NULL,'11','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('4','VGA compatible controller [0300]','0',NULL,'12','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('5','Ethernet controller [0200]','0',NULL,'13','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('6','System peripheral [0880]','0',NULL,'14','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('7','Multimedia audio controller [0401]','0',NULL,'15','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('8','USB controller [0c03]','0',NULL,'16','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('9','Bridge [0680]','0',NULL,'17','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('10','SATA controller [0106]','0',NULL,'18','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicecontrols` VALUES ('11','Standard SATA AHCI Controller','0','Standard SATA AHCI Controller','20','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicecontrols` VALUES ('12','Microsoft Storage Spaces Controller','0','Microsoft Storage Spaces Controller','21','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicecontrols` VALUES ('13','Standard OpenHCD USB Host Controller','0','Standard OpenHCD USB Host Controller','22','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicecontrols` VALUES ('14','USB controller [0c03]','0',NULL,'23','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicedrivemodels

DROP TABLE IF EXISTS `glpi_devicedrivemodels`;
CREATE TABLE `glpi_devicedrivemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrives

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` tinyint(1) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicedrivemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicedrivemodels_id` (`devicedrivemodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicedrives` VALUES ('1','VBOX CD-ROM','1',NULL,NULL,'0','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicedrives` VALUES ('2','Unknown','1',NULL,NULL,'0','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicefirmwaremodels

DROP TABLE IF EXISTS `glpi_devicefirmwaremodels`;
CREATE TABLE `glpi_devicefirmwaremodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicefirmwaremodels` VALUES ('1','VirtualBox','',NULL);
INSERT INTO `glpi_devicefirmwaremodels` VALUES ('2','SM-N9005','',NULL);

### Dump table glpi_devicefirmwares

DROP TABLE IF EXISTS `glpi_devicefirmwares`;
CREATE TABLE `glpi_devicefirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicefirmwaretypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicefirmwaremodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicefirmwaremodels_id` (`devicefirmwaremodels_id`),
  KEY `devicefirmwaretypes_id` (`devicefirmwaretypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicefirmwares` VALUES ('1','VirtualBox','12/01/2006 - Not Specified','8',NULL,NULL,'4','0','0','1','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicefirmwares` VALUES ('2','N9005VJUGBPB1','02/01/16 - LRX21V-0123456789','24',NULL,NULL,'5','0','0','2','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicefirmwaretypes

DROP TABLE IF EXISTS `glpi_devicefirmwaretypes`;
CREATE TABLE `glpi_devicefirmwaretypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicefirmwaretypes` VALUES ('1','BIOS',NULL,NULL,NULL);
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('2','UEFI',NULL,NULL,NULL);
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('3','Firmware',NULL,NULL,NULL);
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('4','Other','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('5','Mobile','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicegenericmodels

DROP TABLE IF EXISTS `glpi_devicegenericmodels`;
CREATE TABLE `glpi_devicegenericmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegenerics

DROP TABLE IF EXISTS `glpi_devicegenerics`;
CREATE TABLE `glpi_devicegenerics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegenerictypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `devicegenericmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicegenerictypes_id` (`devicegenerictypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicegenericmodels_id` (`devicegenericmodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegenerictypes

DROP TABLE IF EXISTS `glpi_devicegenerictypes`;
CREATE TABLE `glpi_devicegenerictypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccardmodels

DROP TABLE IF EXISTS `glpi_devicegraphiccardmodels`;
CREATE TABLE `glpi_devicegraphiccardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccards

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `memory_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicegraphiccardmodels_id` int(11) DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `chipset` (`chipset`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicegraphiccardmodels_id` (`devicegraphiccardmodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicegraphiccards` VALUES ('1','InnoTek Systemberatung GmbH VirtualBox Graphics Adapter','0',NULL,'0','0','0','0',NULL,NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicegraphiccards` VALUES ('2','VirtualBox Graphics Adapter for Windows 8','0',NULL,'0','0','0','0',NULL,NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicegraphiccards` VALUES ('3','Embedded display','0',NULL,'0','0','0','0',NULL,NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_deviceharddrivemodels

DROP TABLE IF EXISTS `glpi_deviceharddrivemodels`;
CREATE TABLE `glpi_deviceharddrivemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrives

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `capacity_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `deviceharddrivemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `deviceharddrivemodels_id` (`deviceharddrivemodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_deviceharddrives` VALUES ('1','VBOX HARDDISK',NULL,'0',NULL,NULL,'0','25595','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicememories

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `size_default` int(11) NOT NULL DEFAULT '0',
  `devicememorytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicememorymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicememorytypes_id` (`devicememorytypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicememorymodels_id` (`devicememorymodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorymodels

DROP TABLE IF EXISTS `glpi_devicememorymodels`;
CREATE TABLE `glpi_devicememorymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorytypes

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicememorytypes` VALUES ('1','EDO',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('2','DDR',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('3','SDRAM',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('4','SDRAM-2',NULL,NULL,NULL);

### Dump table glpi_devicemotherboardmodels

DROP TABLE IF EXISTS `glpi_devicemotherboardmodels`;
CREATE TABLE `glpi_devicemotherboardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicemotherboards

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicemotherboardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicemotherboardmodels_id` (`devicemotherboardmodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcardmodels

DROP TABLE IF EXISTS `glpi_devicenetworkcardmodels`;
CREATE TABLE `glpi_devicenetworkcardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcards

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `mac_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicenetworkcardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicenetworkcardmodels_id` (`devicenetworkcardmodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicenetworkcards` VALUES ('1','eth0','10',NULL,'0',NULL,'0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicenetworkcards` VALUES ('2','Intel(R) PRO/1000 MT Desktop Adapter','1000',NULL,'0',NULL,'0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_devicenetworkcards` VALUES ('3','Wifi/3G interface','19',NULL,'0',NULL,'0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicepcimodels

DROP TABLE IF EXISTS `glpi_devicepcimodels`;
CREATE TABLE `glpi_devicepcimodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcis

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `devicenetworkcardmodels_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicepcimodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicepcimodels_id` (`devicepcimodels_id`),
  KEY `devicenetworkcardmodels_id` (`devicenetworkcardmodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplies

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_atx` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicepowersupplymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicepowersupplymodels_id` (`devicepowersupplymodels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplymodels

DROP TABLE IF EXISTS `glpi_devicepowersupplymodels`;
CREATE TABLE `glpi_devicepowersupplymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessormodels

DROP TABLE IF EXISTS `glpi_deviceprocessormodels`;
CREATE TABLE `glpi_deviceprocessormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_deviceprocessormodels` VALUES ('1','Core i7','','7402');

### Dump table glpi_deviceprocessors

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `frequency_default` int(11) NOT NULL DEFAULT '0',
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `deviceprocessormodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `deviceprocessormodels_id` (`deviceprocessormodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_deviceprocessors` VALUES ('1','Intel Core i7 7400','3000','','2','2000','2','4','0','0','1','2017-11-30 10:32:31','2017-11-30 10:32:31');
INSERT INTO `glpi_deviceprocessors` VALUES ('2','Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz','1996',NULL,'2','0','1',NULL,'0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_deviceprocessors` VALUES ('3','Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz','1995',NULL,'19','1995','4',NULL,'0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_devicesensormodels

DROP TABLE IF EXISTS `glpi_devicesensormodels`;
CREATE TABLE `glpi_devicesensormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesensors

DROP TABLE IF EXISTS `glpi_devicesensors`;
CREATE TABLE `glpi_devicesensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesensortypes_id` int(11) NOT NULL DEFAULT '0',
  `devicesensormodels_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicesensortypes_id` (`devicesensortypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesensortypes

DROP TABLE IF EXISTS `glpi_devicesensortypes`;
CREATE TABLE `glpi_devicesensortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesimcards

DROP TABLE IF EXISTS `glpi_devicesimcards`;
CREATE TABLE `glpi_devicesimcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `voltage` int(11) DEFAULT NULL,
  `devicesimcardtypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `allow_voip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `devicesimcardtypes_id` (`devicesimcardtypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesimcardtypes

DROP TABLE IF EXISTS `glpi_devicesimcardtypes`;
CREATE TABLE `glpi_devicesimcardtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicesimcardtypes` VALUES ('1','Full SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('2','Mini SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('3','Micro SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('4','Nano SIM',NULL,NULL,NULL);

### Dump table glpi_devicesoundcardmodels

DROP TABLE IF EXISTS `glpi_devicesoundcardmodels`;
CREATE TABLE `glpi_devicesoundcardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesoundcards

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicesoundcardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicesoundcardmodels_id` (`devicesoundcardmodels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicesoundcards` VALUES ('1','Multimedia audio controller',NULL,'rev 01','0','0','0',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_devicesoundcards` VALUES ('2','Dispositivo de High Definition Audio',NULL,'Dispositivo de High Definition Audio','0','0','0',NULL,'2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_displaypreferences

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `itemtype` (`itemtype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_displaypreferences` VALUES ('29','Computer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('30','Computer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('31','Computer','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('32','Computer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('33','Computer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('34','Computer','45','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('35','Computer','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('36','Computer','19','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('37','Computer','17','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('38','NetworkEquipment','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('39','NetworkEquipment','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('40','NetworkEquipment','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('41','NetworkEquipment','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('42','NetworkEquipment','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('43','NetworkEquipment','19','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('44','Printer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('45','Printer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('46','Printer','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('47','Printer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('48','Printer','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('49','Monitor','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('50','Monitor','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('51','Monitor','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('52','Monitor','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('53','Monitor','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('54','Monitor','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('55','Peripheral','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('56','Peripheral','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('57','Peripheral','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('58','Peripheral','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('59','Peripheral','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('60','Peripheral','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('61','Software','23','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('62','Software','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('63','Software','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('64','Contact','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('65','Contact','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('66','Contact','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('67','Contact','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('68','Contact','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('69','Supplier','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('70','Supplier','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('71','Supplier','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('72','Supplier','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('73','Supplier','10','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('74','Supplier','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('75','Contract','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('76','Contract','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('77','Contract','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('78','Contract','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('79','Contract','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('80','Contract','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('82','CartridgeItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('83','CartridgeItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('84','CartridgeItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('85','CartridgeItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('86','DocumentType','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('88','DocumentType','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('89','DocumentType','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('90','DocumentType','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('91','Document','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('92','Document','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('93','Document','7','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('94','Document','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('95','Document','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('96','User','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('98','User','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('99','User','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('100','User','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('101','ConsumableItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('102','ConsumableItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('103','ConsumableItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('104','ConsumableItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('105','NetworkEquipment','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('106','Printer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('107','Monitor','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('108','Peripheral','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('109','User','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('110','Phone','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('111','Phone','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('112','Phone','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('113','Phone','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('114','Phone','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('115','Phone','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('116','Phone','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('117','Group','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('118','AllAssets','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('119','ReservationItem','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('120','ReservationItem','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('122','Software','72','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('123','Software','163','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('124','Budget','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('125','Budget','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('126','Budget','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('127','Budget','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('128','Crontask','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('129','Crontask','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('130','Crontask','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('131','Crontask','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('132','RequestType','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('133','RequestType','15','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('134','NotificationTemplate','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('135','NotificationTemplate','16','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('136','Notification','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('137','Notification','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('138','Notification','2','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('139','Notification','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('140','Notification','80','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('141','Notification','86','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('142','MailCollector','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('143','MailCollector','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('144','AuthLDAP','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('145','AuthLDAP','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('146','AuthMail','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('147','AuthMail','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('150','Profile','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('151','Profile','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('152','Profile','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('153','Transfer','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('154','TicketValidation','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('155','TicketValidation','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('156','TicketValidation','8','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('157','TicketValidation','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('158','TicketValidation','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('159','TicketValidation','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('160','NotImportedEmail','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('161','NotImportedEmail','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('162','NotImportedEmail','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('163','NotImportedEmail','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('164','NotImportedEmail','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('165','NotImportedEmail','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('166','RuleRightParameter','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('167','Ticket','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('168','Ticket','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('169','Ticket','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('170','Ticket','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('171','Ticket','4','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('172','Ticket','5','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('173','Ticket','7','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('174','Calendar','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('175','Holiday','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('176','Holiday','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('177','Holiday','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('178','SLA','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('179','Ticket','18','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('180','AuthLdap','30','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('181','AuthMail','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('183','FieldUnicity','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('184','FieldUnicity','80','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('185','FieldUnicity','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('186','FieldUnicity','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('187','FieldUnicity','86','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('188','FieldUnicity','30','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('189','Problem','21','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('190','Problem','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('191','Problem','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('192','Problem','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('193','Problem','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('194','Problem','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('195','Problem','18','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('196','Vlan','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('197','TicketRecurrent','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('198','TicketRecurrent','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('199','TicketRecurrent','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('200','TicketRecurrent','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('201','TicketRecurrent','14','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('202','Reminder','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('203','Reminder','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('204','Reminder','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('205','Reminder','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('206','Reminder','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('207','Reminder','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('208','FQDN','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('209','WifiNetwork','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('210','IPNetwork','18','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('211','IPNetwork','10','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('212','IPNetwork','11','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('213','IPNetwork','12','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('214','IPNetwork','17','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('215','NetworkName','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('216','NetworkName','13','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('217','RSSFeed','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('218','RSSFeed','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('219','RSSFeed','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('220','RSSFeed','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('221','RSSFeed','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('222','RSSFeed','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('223','Blacklist','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('224','Blacklist','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('225','ReservationItem','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('226','QueueMail','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('227','QueueMail','7','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('228','QueueMail','20','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('229','QueueMail','21','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('230','QueueMail','22','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('231','QueueMail','15','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('232','Change','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('233','Change','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('234','Change','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('235','Change','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('236','Change','18','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('237','Project','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('238','Project','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('239','Project','12','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('240','Project','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('241','Project','15','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('242','Project','21','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('243','ProjectState','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('244','ProjectState','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('245','ProjectTask','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('246','ProjectTask','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('247','ProjectTask','14','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('248','ProjectTask','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('249','ProjectTask','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('250','ProjectTask','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('251','ProjectTask','13','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('252','CartridgeItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('253','ConsumableItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('254','ReservationItem','9','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('255','SoftwareLicense','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('256','SoftwareLicense','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('257','SoftwareLicense','10','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('258','SoftwareLicense','162','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('259','SoftwareLicense','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('260','SavedSearch','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('261','SavedSearch','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('262','SavedSearch','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('263','SavedSearch','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('264','SavedSearch','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('265','Ticket','8','10','0');
INSERT INTO `glpi_displaypreferences` VALUES ('266','PluginOcsinventoryngOcsServer','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('267','PluginOcsinventoryngOcsServer','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('268','PluginOcsinventoryngOcsServer','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('269','PluginOcsinventoryngNotimportedcomputer','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('270','PluginOcsinventoryngNotimportedcomputer','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('271','PluginOcsinventoryngNotimportedcomputer','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('272','PluginOcsinventoryngNotimportedcomputer','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('273','PluginOcsinventoryngNotimportedcomputer','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('274','PluginOcsinventoryngNotimportedcomputer','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('275','PluginOcsinventoryngNotimportedcomputer','8','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('276','PluginOcsinventoryngNotimportedcomputer','9','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('277','PluginOcsinventoryngNotimportedcomputer','10','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('278','PluginOcsinventoryngDetail','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('279','PluginOcsinventoryngDetail','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('280','PluginOcsinventoryngDetail','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('281','PluginOcsinventoryngDetail','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('282','PluginOcsinventoryngDetail','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('283','PluginOcsinventoryngDetail','80','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('284','datacenter','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('285','Rack','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('286','Rack','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('287','Rack','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('288','Rack','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('289','DCRoom','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('290','DCRoom','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('291','DCRoom','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('292','PDU','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('293','PDU','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('294','PDU','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('295','Enclosure','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('296','Enclosure','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('297','Enclosure','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('298','Item_DeviceMotherboard','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('299','Item_DeviceMotherboard','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('300','Item_DeviceMotherboard','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('301','Item_DeviceMotherboard','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('302','Item_DeviceFirmware','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('303','Item_DeviceFirmware','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('304','Item_DeviceFirmware','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('305','Item_DeviceFirmware','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('306','Item_DeviceProcessor','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('307','Item_DeviceProcessor','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('308','Item_DeviceProcessor','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('309','Item_DeviceProcessor','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('310','Item_DeviceMemory','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('311','Item_DeviceMemory','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('312','Item_DeviceMemory','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('313','Item_DeviceMemory','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('314','Item_DeviceHardDrive','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('315','Item_DeviceHardDrive','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('316','Item_DeviceHardDrive','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('317','Item_DeviceHardDrive','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('318','Item_DeviceNetworkCard','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('319','Item_DeviceNetworkCard','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('320','Item_DeviceNetworkCard','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('321','Item_DeviceNetworkCard','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('322','Item_DeviceDrive','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('323','Item_DeviceDrive','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('324','Item_DeviceDrive','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('325','Item_DeviceDrive','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('326','Item_DeviceBattery','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('327','Item_DeviceBattery','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('328','Item_DeviceBattery','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('329','Item_DeviceBattery','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('330','Item_DeviceGraphicCard','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('331','Item_DeviceGraphicCard','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('332','Item_DeviceGraphicCard','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('333','Item_DeviceGraphicCard','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('334','Item_DeviceSoundCard','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('335','Item_DeviceSoundCard','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('336','Item_DeviceSoundCard','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('337','Item_DeviceSoundCard','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('338','Item_DeviceControl','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('339','Item_DeviceControl','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('340','Item_DeviceControl','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('341','Item_DeviceControl','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('342','Item_DevicePci','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('343','Item_DevicePci','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('344','Item_DevicePci','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('345','Item_DevicePci','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('346','Item_DeviceCase','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('347','Item_DeviceCase','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('348','Item_DeviceCase','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('349','Item_DeviceCase','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('350','Item_DevicePowerSupply','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('351','Item_DevicePowerSupply','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('352','Item_DevicePowerSupply','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('353','Item_DevicePowerSupply','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('354','Item_DeviceGeneric','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('355','Item_DeviceGeneric','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('356','Item_DeviceGeneric','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('357','Item_DeviceGeneric','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('358','Item_DeviceSimcard','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('359','Item_DeviceSimcard','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('360','Item_DeviceSimcard','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('361','Item_DeviceSimcard','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('362','Item_DeviceSensor','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('363','Item_DeviceSensor','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('364','Item_DeviceSensor','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('365','Item_DeviceSensor','6','4','0');

### Dump table glpi_documentcategories

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documentcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documentcategories` VALUES ('1','Contrato','','0','Contrato','1','[]',NULL,'2018-05-21 15:46:28','2018-05-21 15:46:28');
INSERT INTO `glpi_documentcategories` VALUES ('2','Proposta','','0','Proposta','1','[]',NULL,'2018-05-21 15:46:41','2018-05-21 15:46:41');
INSERT INTO `glpi_documentcategories` VALUES ('3','Procedimento','','0','Procedimento','1','[]',NULL,'2018-05-21 16:07:39','2018-05-21 16:07:39');

### Dump table glpi_documents

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `sha1sum` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `users_id` (`users_id`),
  KEY `documentcategories_id` (`documentcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sha1sum` (`sha1sum`),
  KEY `tag` (`tag`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents` VALUES ('1','0','0','Contrato de manutanção','Selection_1693_411_2018_05_21_0_005.png','PNG/89/06acca6a8b24321550c3a415f308bfcdd1e3b1.PNG','1','image/png','2018-05-21 16:05:17','Contrato','0','','2','0','8906acca6a8b24321550c3a415f308bfcdd1e3b1','0','bc7057ec-d9d62df8-5b031805a115f9.45558892','2018-05-21 16:05:17');
INSERT INTO `glpi_documents` VALUES ('2','0','0','Procedimento',NULL,NULL,'3','','2018-05-21 16:10:33','','1','ftp://10.0.0.150/PFSense/Como%20Instalar%20Fisicamente%20PFSense%20Firewall.docx','2','0',NULL,'0','bc7057ec-d9d62df8-5b031920877702.67506382','2018-05-21 16:08:16');

### Dump table glpi_documents_items

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documents_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) DEFAULT '0',
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`),
  KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documenttypes

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_uploadable` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ext`),
  KEY `name` (`name`),
  KEY `is_uploadable` (`is_uploadable`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documenttypes` VALUES ('1','JPEG','jpg','jpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('2','PNG','png','png-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('3','GIF','gif','gif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('4','BMP','bmp','bmp-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('5','Photoshop','psd','psd-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('6','TIFF','tif','tif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('7','AIFF','aiff','aiff-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('8','Windows Media','asf','asf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('9','Windows Media','avi','avi-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('10','BZip','bz2','bz2-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('11','Word','doc','doc-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('12','DjVu','djvu','','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('13','PostScript','eps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('14','GZ','gz','gz-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('15','HTML','html','html-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('16','Midi','mid','mid-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('17','QuickTime','mov','mov-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('18','MP3','mp3','mp3-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('19','MPEG','mpg','mpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('20','Ogg Vorbis','ogg','ogg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('21','PDF','pdf','pdf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('22','PowerPoint','ppt','ppt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('23','PostScript','ps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('24','QuickTime','qt','qt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('25','RealAudio','ra','ra-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('26','RealAudio','ram','ram-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('27','RealAudio','rm','rm-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('28','RTF','rtf','rtf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('29','StarOffice','sdd','sdd-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('30','StarOffice','sdw','sdw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('31','Stuffit','sit','sit-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('32','OpenOffice Impress','sxi','sxi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('33','OpenOffice','sxw','sxw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('34','Flash','swf','swf-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('35','TGZ','tgz','tgz-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('36','texte','txt','txt-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('37','WAV','wav','wav-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('38','Excel','xls','xls-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('39','XML','xml','xml-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('40','Windows Media','wmv','wmv-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('41','Zip','zip','zip-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('42','MNG','mng','','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('43','Adobe Illustrator','ai','ai-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('44','C source','c','c-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('45','Debian','deb','deb-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('46','DVI','dvi','dvi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('47','C header','h','h-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('48','Pascal','pas','pas-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('49','RedHat/Mandrake/SuSE','rpm','rpm-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('50','OpenOffice Calc','sxc','sxc-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('51','LaTeX','tex','tex-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('52','GIMP multi-layer','xcf','xcf-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('53','JPEG','jpeg','jpg-dist.png','','1','2005-03-07 22:23:17',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('54','Oasis Open Office Writer','odt','odt-dist.png','','1','2006-01-21 17:41:13',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('55','Oasis Open Office Calc','ods','ods-dist.png','','1','2006-01-21 17:41:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('56','Oasis Open Office Impress','odp','odp-dist.png','','1','2006-01-21 17:42:54',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('57','Oasis Open Office Impress Template','otp','odp-dist.png','','1','2006-01-21 17:43:58',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('58','Oasis Open Office Writer Template','ott','odt-dist.png','','1','2006-01-21 17:44:41',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('59','Oasis Open Office Calc Template','ots','ods-dist.png','','1','2006-01-21 17:45:30',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('60','Oasis Open Office Math','odf','odf-dist.png','','1','2006-01-21 17:48:05',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('61','Oasis Open Office Draw','odg','odg-dist.png','','1','2006-01-21 17:48:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('62','Oasis Open Office Draw Template','otg','odg-dist.png','','1','2006-01-21 17:49:46',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('63','Oasis Open Office Base','odb','odb-dist.png','','1','2006-01-21 18:03:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('64','Oasis Open Office HTML','oth','oth-dist.png','','1','2006-01-21 18:05:27',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('65','Oasis Open Office Writer Master','odm','odm-dist.png','','1','2006-01-21 18:06:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('66','Oasis Open Office Chart','odc','','','1','2006-01-21 18:07:48',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('67','Oasis Open Office Image','odi','','','1','2006-01-21 18:08:18',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('68','Word XML','docx','doc-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('69','Excel XML','xlsx','xls-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('70','PowerPoint XML','pptx','ppt-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('71','Comma-Separated Values','csv','csv-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('72','Scalable Vector Graphics','svg','svg-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('73','MP4','mp4','avi-dist.png','','1','2018-05-21 15:29:11','','2018-05-21 15:29:11');

### Dump table glpi_domains

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_domains` VALUES ('1','WORKGROUP','-1','0','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_dropdowntranslations

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  KEY `typeid` (`itemtype`,`items_id`),
  KEY `language` (`language`),
  KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_enclosuremodels

DROP TABLE IF EXISTS `glpi_enclosuremodels`;
CREATE TABLE `glpi_enclosuremodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `power_consumption` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_enclosures

DROP TABLE IF EXISTS `glpi_enclosures`;
CREATE TABLE `glpi_enclosures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enclosuremodels_id` int(11) DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `orientation` tinyint(1) DEFAULT NULL,
  `power_supplies` tinyint(1) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to states (id)',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `enclosuremodels_id` (`enclosuremodels_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `group_id_tech` (`groups_id_tech`),
  KEY `is_template` (`is_template`),
  KEY `is_deleted` (`is_deleted`),
  KEY `states_id` (`states_id`),
  KEY `manufacturers_id` (`manufacturers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notification_subject_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `mail_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_ldapfilter` text COLLATE utf8_unicode_ci,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `use_licenses_alert` int(11) NOT NULL DEFAULT '-2',
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_certificates_alert` int(11) NOT NULL DEFAULT '-2',
  `send_certificates_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_contracts_alert` int(11) NOT NULL DEFAULT '-2',
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_infocoms_alert` int(11) NOT NULL DEFAULT '-2',
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_reservations_alert` int(11) NOT NULL DEFAULT '-2',
  `autoclose_delay` int(11) NOT NULL DEFAULT '-2',
  `notclosed_delay` int(11) NOT NULL DEFAULT '-2',
  `calendars_id` int(11) NOT NULL DEFAULT '-2',
  `auto_assign_mode` int(11) NOT NULL DEFAULT '-2',
  `tickettype` int(11) NOT NULL DEFAULT '-2',
  `max_closedate` datetime DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT '-2',
  `inquest_rate` int(11) NOT NULL DEFAULT '0',
  `inquest_delay` int(11) NOT NULL DEFAULT '-10',
  `inquest_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autofill_warranty_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '-2',
  `entities_id_software` int(11) NOT NULL DEFAULT '-2',
  `default_contract_alert` int(11) NOT NULL DEFAULT '-2',
  `default_infocom_alert` int(11) NOT NULL DEFAULT '-2',
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `delay_send_emails` int(11) NOT NULL DEFAULT '-2',
  `is_notif_enable_default` int(11) NOT NULL DEFAULT '-2',
  `inquest_duration` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `autofill_decommission_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`name`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_entities` VALUES ('0','FAME Consultoria','-1','FAME Consultoria',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0','0','-10','1',NULL,'1','0','0',NULL,'0','0','0','0','0','1','-10','0','0','10','10','0','1','0','2018-01-13 13:57:59',NULL,'0');
INSERT INTO `glpi_entities` VALUES ('1','ABC','0','FAME Consultoria > ABC',NULL,'2','{\"1\":\"1\",\"4\":\"4\",\"3\":\"3\"}','[\"0\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:38:23','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:38:23','2018-01-08 10:38:23','-2');
INSERT INTO `glpi_entities` VALUES ('2','XYZ','0','FAME Consultoria > XYZ',NULL,'2','{\"2\":\"2\",\"5\":\"5\",\"6\":\"6\"}','[\"0\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:38:33','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:38:33','2018-01-08 10:38:33','-2');
INSERT INTO `glpi_entities` VALUES ('3','Produção','1','FAME Consultoria > ABC > Produção','','3',NULL,'[\"0\",\"1\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:39:15','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:39:15','2018-01-08 10:39:15','-2');
INSERT INTO `glpi_entities` VALUES ('4','Administração','1','FAME Consultoria > ABC > Administração','','3',NULL,'[\"0\",\"1\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:39:23','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:39:23','2018-01-08 10:39:23','-2');
INSERT INTO `glpi_entities` VALUES ('5','Administração','2','FAME Consultoria > XYZ > Administração',NULL,'3',NULL,'{\"0\":\"0\",\"2\":\"2\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:39:41','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:39:41','2018-01-08 10:39:41','-2');
INSERT INTO `glpi_entities` VALUES ('6','Produção','2','FAME Consultoria > XYZ > Produção',NULL,'3',NULL,'{\"0\":\"0\",\"2\":\"2\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2018-01-08 10:39:46','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2018-01-08 10:39:46','2018-01-08 10:39:46','-2');

### Dump table glpi_entities_knowbaseitems

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_reminders

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_rssfeeds

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_events

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `level` (`level`),
  KEY `item` (`type`,`items_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_events` VALUES ('1','-1','system','2017-11-21 10:15:49','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('2','-1','system','2017-11-29 09:57:16','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('3','1','State','2017-11-29 10:04:37','setup','4','glpi adicionou o item Operacional');
INSERT INTO `glpi_events` VALUES ('4','2','State','2017-11-29 10:04:46','setup','4','glpi adicionou o item Disponível');
INSERT INTO `glpi_events` VALUES ('5','3','State','2017-11-29 10:04:55','setup','4','glpi adicionou o item Defeito');
INSERT INTO `glpi_events` VALUES ('6','1','Location','2017-11-29 10:05:31','setup','4','glpi adicionou o item Fortaleza');
INSERT INTO `glpi_events` VALUES ('7','1','ComputerType','2017-11-29 10:05:50','setup','4','glpi adicionou o item Desktop');
INSERT INTO `glpi_events` VALUES ('8','2','ComputerType','2017-11-29 10:05:56','setup','4','glpi adicionou o item Laptop');
INSERT INTO `glpi_events` VALUES ('9','1','Manufacturer','2017-11-29 10:06:30','setup','4','glpi adicionou o item Dell');
INSERT INTO `glpi_events` VALUES ('10','1','ComputerModel','2017-11-29 10:07:05','setup','4','glpi adicionou o item M3333');
INSERT INTO `glpi_events` VALUES ('11','1','computers','2017-11-29 10:07:36','inventory','4','glpi adicionou o item &lt;DESK-\\\\Y-###&gt;');
INSERT INTO `glpi_events` VALUES ('12','2','computers','2017-11-29 10:09:26','inventory','4','glpi adicionou o item DESK-2017-001');
INSERT INTO `glpi_events` VALUES ('13','3','computers','2017-11-29 10:09:33','inventory','4','glpi adicionou o item DESK-2017-002');
INSERT INTO `glpi_events` VALUES ('14','4','computers','2017-11-29 10:09:37','inventory','4','glpi adicionou o item DESK-2017-003');
INSERT INTO `glpi_events` VALUES ('15','5','computers','2017-11-29 10:09:39','inventory','4','glpi adicionou o item DESK-2017-004');
INSERT INTO `glpi_events` VALUES ('16','6','computers','2017-11-29 10:09:49','inventory','4','glpi adicionou o item DESK-2017-005');
INSERT INTO `glpi_events` VALUES ('17','7','computers','2017-11-29 10:09:56','inventory','4','glpi adicionou o item DESK-2017-006');
INSERT INTO `glpi_events` VALUES ('18','8','computers','2017-11-29 10:10:02','inventory','4','glpi adicionou o item DESK-2017-007');
INSERT INTO `glpi_events` VALUES ('19','2','computers','2017-11-29 10:10:28','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('20','3','computers','2017-11-29 10:10:39','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('21','4','computers','2017-11-29 10:10:50','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('22','5','computers','2017-11-29 10:11:26','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('23','-1','system','2017-11-30 09:47:03','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('24','9','computers','2017-11-30 10:15:39','inventory','4','glpi adicionou o item Teste');
INSERT INTO `glpi_events` VALUES ('25','-1','system','2017-11-30 10:21:00','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('26','10','computers','2017-11-30 10:27:02','inventory','4','glpi adicionou o item TESTE');
INSERT INTO `glpi_events` VALUES ('27','8','computers','2017-11-30 10:28:51','inventory','4','glpi excluiu um item');
INSERT INTO `glpi_events` VALUES ('28','8','computers','2017-11-30 10:29:09','inventory','4','glpi restaurou um item');
INSERT INTO `glpi_events` VALUES ('29','2','Manufacturer','2017-11-30 10:31:35','setup','4','glpi adicionou o item Intel');
INSERT INTO `glpi_events` VALUES ('30','1','DeviceProcessorModel','2017-11-30 10:32:23','setup','4','glpi adicionou o item Core i7');
INSERT INTO `glpi_events` VALUES ('31','1','DeviceProcessor','2017-11-30 10:32:31','inventory','4','glpi adicionou o item Intel Core i7 7400');
INSERT INTO `glpi_events` VALUES ('32','1','infocom','2017-11-30 10:35:24','financial','4','glpi adicionou o item 1');
INSERT INTO `glpi_events` VALUES ('33','-1','system','2017-12-01 10:00:56','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('34','1','MonitorType','2017-12-01 10:09:39','setup','4','glpi adicionou o item LCD');
INSERT INTO `glpi_events` VALUES ('35','1','MonitorModel','2017-12-01 10:10:08','setup','4','glpi adicionou o item L21');
INSERT INTO `glpi_events` VALUES ('36','1','monitors','2017-12-01 10:10:42','inventory','4','glpi adicionou o item &lt;MON-\\\\Y-###&gt;');
INSERT INTO `glpi_events` VALUES ('37','2','monitors','2017-12-01 10:11:11','inventory','4','glpi adicionou o item MON-2017-001');
INSERT INTO `glpi_events` VALUES ('38','3','monitors','2017-12-01 10:11:17','inventory','4','glpi adicionou o item MON-2017-002');
INSERT INTO `glpi_events` VALUES ('39','4','monitors','2017-12-01 10:11:24','inventory','4','glpi adicionou o item MON-2017-003');
INSERT INTO `glpi_events` VALUES ('40','5','monitors','2017-12-01 10:11:33','inventory','4','glpi adicionou o item MON-2017-004');
INSERT INTO `glpi_events` VALUES ('41','6','monitors','2017-12-01 10:11:39','inventory','4','glpi adicionou o item MON-2017-005');
INSERT INTO `glpi_events` VALUES ('42','7','monitors','2017-12-01 10:11:45','inventory','4','glpi adicionou o item MON-2017-006');
INSERT INTO `glpi_events` VALUES ('43','8','monitors','2017-12-01 10:11:51','inventory','4','glpi adicionou o item MON-2017-007');
INSERT INTO `glpi_events` VALUES ('44','2','computers','2017-12-01 10:12:41','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('45','3','computers','2017-12-01 10:13:00','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('46','9','monitors','2017-12-01 10:14:15','inventory','4','glpi adicionou o item KVM01');
INSERT INTO `glpi_events` VALUES ('47','4','computers','2017-12-01 10:14:37','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('48','5','computers','2017-12-01 10:14:44','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('49','6','computers','2017-12-01 10:14:49','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('50','2','infocom','2017-12-01 10:15:19','financial','4','glpi adicionou o item 2');
INSERT INTO `glpi_events` VALUES ('51','-1','system','2017-12-03 12:04:13','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('52','3','Manufacturer','2017-12-03 13:16:39','setup','4','glpi adicionou o item libreoffice.org');
INSERT INTO `glpi_events` VALUES ('53','2','SoftwareCategory','2017-12-03 13:17:09','setup','4','glpi adicionou o item Manual');
INSERT INTO `glpi_events` VALUES ('54','3','SoftwareCategory','2017-12-03 13:17:15','setup','4','glpi adicionou o item OCS');
INSERT INTO `glpi_events` VALUES ('55','1','software','2017-12-03 13:17:34','inventory','4','glpi adicionou o item LibreOffice');
INSERT INTO `glpi_events` VALUES ('56','1','OperatingSystem','2017-12-03 13:18:43','setup','4','glpi adicionou o item Windows');
INSERT INTO `glpi_events` VALUES ('57','2','OperatingSystem','2017-12-03 13:18:52','setup','4','glpi adicionou o item GNU/Linux');
INSERT INTO `glpi_events` VALUES ('58','1','software','2017-12-03 13:19:10','inventory','4','glpi adicionou a versão 1');
INSERT INTO `glpi_events` VALUES ('59','1','software','2017-12-03 13:20:36','inventory','4','glpi adicionou a licença 1');
INSERT INTO `glpi_events` VALUES ('60','1','software','2017-12-03 13:21:19','inventory','4','glpi atualizou a licença 1');
INSERT INTO `glpi_events` VALUES ('61','1','software','2017-12-03 13:22:57','inventory','4','glpi atualizou a licença 1');
INSERT INTO `glpi_events` VALUES ('62','2','computers','2017-12-03 13:24:00','inventory','5','glpi instalou um software');
INSERT INTO `glpi_events` VALUES ('63','1','softwarelicense','2017-12-03 13:24:12','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('64','1','software','2017-12-03 13:26:20','inventory','4','glpi atualizou a licença 1');
INSERT INTO `glpi_events` VALUES ('65','2','computers','2017-12-03 13:26:59','inventory','5','glpi instalou um software');
INSERT INTO `glpi_events` VALUES ('66','1','softwarelicense','2017-12-03 13:27:09','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('67','1','softwarelicense','2017-12-03 13:27:58','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('68','2','computers','2017-12-03 13:28:27','inventory','5','glpi instalou um software');
INSERT INTO `glpi_events` VALUES ('69','1','softwarelicense','2017-12-03 13:28:41','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('70','1','software','2017-12-03 13:29:31','inventory','4','glpi excluiu a licença 1');
INSERT INTO `glpi_events` VALUES ('71','1','software','2017-12-03 13:29:39','inventory','4','glpi apagou a licença 1');
INSERT INTO `glpi_events` VALUES ('72','1','software','2017-12-03 13:29:47','inventory','4','glpi apagou a versão 1');
INSERT INTO `glpi_events` VALUES ('73','1','software','2017-12-03 13:29:52','inventory','4','glpi excluiu um item');
INSERT INTO `glpi_events` VALUES ('74','1','software','2017-12-03 13:29:58','inventory','4','glpi apagou um item');
INSERT INTO `glpi_events` VALUES ('75','4','Manufacturer','2017-12-03 14:16:22','setup','4','glpi adicionou o item libreoffice.org');
INSERT INTO `glpi_events` VALUES ('76','4','SoftwareCategory','2017-12-03 14:16:46','setup','4','glpi adicionou o item Manual');
INSERT INTO `glpi_events` VALUES ('77','5','SoftwareCategory','2017-12-03 14:16:51','setup','4','glpi adicionou o item OCS');
INSERT INTO `glpi_events` VALUES ('78','2','software','2017-12-03 14:17:33','inventory','4','glpi adicionou o item LibreOffice');
INSERT INTO `glpi_events` VALUES ('79','3','OperatingSystem','2017-12-03 14:18:53','setup','4','glpi adicionou o item Windows');
INSERT INTO `glpi_events` VALUES ('80','2','software','2017-12-03 14:19:06','inventory','4','glpi adicionou a versão 2');
INSERT INTO `glpi_events` VALUES ('81','5','Manufacturer','2017-12-03 14:21:16','setup','4','glpi adicionou o item Mozilla Foundation');
INSERT INTO `glpi_events` VALUES ('82','2','software','2017-12-03 14:21:36','inventory','4','glpi adicionou a licença 2');
INSERT INTO `glpi_events` VALUES ('83','2','computers','2017-12-03 14:22:40','inventory','5','glpi instalou um software');
INSERT INTO `glpi_events` VALUES ('84','2','softwarelicense','2017-12-03 14:23:02','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('85','2','software','2017-12-03 14:24:06','inventory','4','glpi atualizou a licença 2');
INSERT INTO `glpi_events` VALUES ('86','3','computers','2017-12-03 14:24:34','inventory','5','glpi instalou um software');
INSERT INTO `glpi_events` VALUES ('87','2','softwarelicense','2017-12-03 14:24:46','inventory','4','glpi associou um computador e uma licença');
INSERT INTO `glpi_events` VALUES ('88','-1','system','2017-12-03 17:04:52','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('89','-1','system','2017-12-03 22:33:53','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('90','-1','system','2017-12-06 10:15:18','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('91','1','PeripheralType','2017-12-06 10:18:27','setup','4','glpi adicionou o item Scanner');
INSERT INTO `glpi_events` VALUES ('92','6','Manufacturer','2017-12-06 10:18:40','setup','4','glpi adicionou o item HP');
INSERT INTO `glpi_events` VALUES ('93','1','PeripheralModel','2017-12-06 10:18:59','setup','4','glpi adicionou o item USB001');
INSERT INTO `glpi_events` VALUES ('94','1','peripherals','2017-12-06 10:19:25','inventory','4','glpi adicionou o item &lt;SCN-\\\\Y-###&gt;');
INSERT INTO `glpi_events` VALUES ('95','2','peripherals','2017-12-06 10:19:43','inventory','4','glpi adicionou o item SCN-2017-001');
INSERT INTO `glpi_events` VALUES ('96','2','computers','2017-12-06 10:20:03','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('97','1','NetworkEquipmentType','2017-12-06 10:26:09','setup','4','glpi adicionou o item Switch');
INSERT INTO `glpi_events` VALUES ('98','2','NetworkEquipmentType','2017-12-06 10:26:15','setup','4','glpi adicionou o item Router');
INSERT INTO `glpi_events` VALUES ('99','1','NetworkEquipmentModel','2017-12-06 10:26:40','setup','4','glpi adicionou o item HP-5500');
INSERT INTO `glpi_events` VALUES ('100','1','networkequipment','2017-12-06 10:26:57','inventory','4','glpi adicionou o item &lt;SWT-###&gt;');
INSERT INTO `glpi_events` VALUES ('101','2','networkequipment','2017-12-06 10:27:17','inventory','4','glpi adicionou o item SWT-001');
INSERT INTO `glpi_events` VALUES ('102','0','networkport','2017-12-06 10:28:32','inventory','5','glpi adicionou diversas portas de rede');
INSERT INTO `glpi_events` VALUES ('103','25','networkport','2017-12-06 10:30:23','inventory','5','glpi adicionou um item');
INSERT INTO `glpi_events` VALUES ('104','25','networkport','2017-12-06 10:33:58','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('105','1','Netpoint','2017-12-06 10:35:33','setup','4','glpi adicionou o item path-6-1-10');
INSERT INTO `glpi_events` VALUES ('106','2','networkport','2017-12-06 10:35:42','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('107','2','Netpoint','2017-12-06 10:36:42','setup','4','glpi adicionou o item path-10-1-6');
INSERT INTO `glpi_events` VALUES ('108','3','Netpoint','2017-12-06 10:37:05','setup','4','glpi adicionou o item path-10-1-6');
INSERT INTO `glpi_events` VALUES ('109','25','networkport','2017-12-06 10:37:13','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('110','25','networkport','2017-12-06 10:37:19','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('111','-1','system','2017-12-07 10:13:31','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('112','-1','system','2017-12-07 10:13:46','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('113','1','PrinterType','2017-12-07 10:17:29','setup','4','glpi adicionou o item Impressora');
INSERT INTO `glpi_events` VALUES ('114','7','Manufacturer','2017-12-07 10:17:40','setup','4','glpi adicionou o item Kyoceara');
INSERT INTO `glpi_events` VALUES ('115','1','PrinterModel','2017-12-07 10:17:56','setup','4','glpi adicionou o item KM2030');
INSERT INTO `glpi_events` VALUES ('116','1','printers','2017-12-07 10:18:05','inventory','4','glpi adicionou o item &lt;IMP-/Y-###&gt;');
INSERT INTO `glpi_events` VALUES ('117','1','printers','2017-12-07 10:18:34','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('118','2','printers','2017-12-07 10:18:58','inventory','4','glpi adicionou o item IMP-2017-001');
INSERT INTO `glpi_events` VALUES ('119','4','Netpoint','2017-12-07 10:19:42','setup','4','glpi adicionou o item path-6-1-11');
INSERT INTO `glpi_events` VALUES ('120','26','networkport','2017-12-07 10:19:54','inventory','5','glpi adicionou um item');
INSERT INTO `glpi_events` VALUES ('121','26','networkport','2017-12-07 10:20:25','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('122','1','Network','2017-12-07 10:21:45','setup','4','glpi adicionou o item REDE_IMPRESSORAS');
INSERT INTO `glpi_events` VALUES ('123','2','printers','2017-12-07 10:21:53','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('124','2','printers','2017-12-07 10:22:28','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('125','2','computers','2017-12-07 10:22:40','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('126','3','computers','2017-12-07 10:22:44','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('127','4','computers','2017-12-07 10:22:49','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('128','5','computers','2017-12-07 10:22:53','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('129','6','computers','2017-12-07 10:22:56','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('130','7','computers','2017-12-07 10:22:59','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('131','8','computers','2017-12-07 10:23:03','inventory','5','glpi conectou um item');
INSERT INTO `glpi_events` VALUES ('132','26','networkport','2017-12-07 10:24:00','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('133','26','networkport','2017-12-07 10:24:15','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('134','1','Vlan','2017-12-07 10:28:13','setup','4','glpi adicionou o item vlan200');
INSERT INTO `glpi_events` VALUES ('135','0','networkport','2017-12-07 10:28:50','inventory','5','glpi associou uma VLAN a uma porta de rede');
INSERT INTO `glpi_events` VALUES ('136','2','Vlan','2017-12-07 10:29:35','setup','4','glpi adicionou o item Default');
INSERT INTO `glpi_events` VALUES ('137','0','networkport','2017-12-07 10:29:45','inventory','5','glpi associou uma VLAN a uma porta de rede');
INSERT INTO `glpi_events` VALUES ('138','0','networkport','2017-12-07 10:30:14','inventory','5','glpi associou uma VLAN a uma porta de rede');
INSERT INTO `glpi_events` VALUES ('139','2','networkname','2017-12-07 10:31:27','inventory','5','glpi adicionou um item');
INSERT INTO `glpi_events` VALUES ('140','3','networkname','2017-12-07 10:32:37','inventory','5','glpi adicionou um item');
INSERT INTO `glpi_events` VALUES ('141','1','IPNetwork','2017-12-07 10:33:40','setup','4','glpi adicionou o item LAN-1andar');
INSERT INTO `glpi_events` VALUES ('142','3','networkname','2017-12-07 10:33:57','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('143','3','networkname','2017-12-07 10:34:03','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('144','3','networkname','2017-12-07 10:34:21','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('145','3','networkname','2017-12-07 10:34:41','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('146','0','ipnetwork','2017-12-07 10:36:01','inventory','5','glpi associou uma VLAN a uma porta de rede');
INSERT INTO `glpi_events` VALUES ('147','3','networkname','2017-12-07 10:38:34','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('148','2','networkname','2017-12-07 10:38:38','inventory','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('149','0','networkport','2017-12-07 10:38:59','inventory','5','glpi associou um nome de rede a um item');
INSERT INTO `glpi_events` VALUES ('150','-1','system','2018-01-02 22:16:03','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('151','-1','system','2018-01-05 23:40:27','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('152','-1','system','2018-01-08 10:09:16','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('153','6','users','2018-01-08 10:17:49','setup','4','glpi adicionou o item eduardo');
INSERT INTO `glpi_events` VALUES ('154','-1','system','2018-01-08 10:19:46','login','3','tech fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('155','1','groups','2018-01-08 10:27:01','setup','4','glpi adicionou o item Servicedesk');
INSERT INTO `glpi_events` VALUES ('156','2','groups','2018-01-08 10:28:16','setup','4','glpi adicionou o item Redes');
INSERT INTO `glpi_events` VALUES ('157','3','groups','2018-01-08 10:28:28','setup','4','glpi adicionou o item Sistemas');
INSERT INTO `glpi_events` VALUES ('158','1','groups','2018-01-08 10:29:46','setup','4','glpi adicionou um usuário ao grupo');
INSERT INTO `glpi_events` VALUES ('159','2','groups','2018-01-08 10:30:05','setup','4','glpi adicionou um usuário ao grupo');
INSERT INTO `glpi_events` VALUES ('160','3','groups','2018-01-08 10:30:25','setup','4','glpi adicionou um usuário ao grupo');
INSERT INTO `glpi_events` VALUES ('161','0','Entity','2018-01-08 10:38:01','setup','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('162','1','Entity','2018-01-08 10:38:23','setup','4','glpi adicionou o item ABC');
INSERT INTO `glpi_events` VALUES ('163','2','Entity','2018-01-08 10:38:33','setup','4','glpi adicionou o item XYZ');
INSERT INTO `glpi_events` VALUES ('164','3','Entity','2018-01-08 10:39:15','setup','4','glpi adicionou o item Produção');
INSERT INTO `glpi_events` VALUES ('165','4','Entity','2018-01-08 10:39:23','setup','4','glpi adicionou o item Administração');
INSERT INTO `glpi_events` VALUES ('166','5','Entity','2018-01-08 10:39:41','setup','4','glpi adicionou o item Administração');
INSERT INTO `glpi_events` VALUES ('167','6','Entity','2018-01-08 10:39:46','setup','4','glpi adicionou o item Produção');
INSERT INTO `glpi_events` VALUES ('168','4','users','2018-01-08 10:40:44','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('169','4','users','2018-01-08 10:41:00','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('170','0','users','2018-01-08 10:47:36','setup','4','glpi adicionou um usuário a uma entidade');
INSERT INTO `glpi_events` VALUES ('171','-1','system','2018-01-08 10:50:29','login','3','tech fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('172','-1','system','2018-01-08 10:52:01','login','3','tech fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('173','-1','system','2018-01-08 10:52:45','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('174','6','users','2018-01-08 10:54:12','setup','4','glpi adicionou um usuário a uma entidade');
INSERT INTO `glpi_events` VALUES ('175','6','users','2018-01-08 10:54:22','setup','4','glpi adicionou um usuário a uma entidade');
INSERT INTO `glpi_events` VALUES ('176','6','users','2018-01-08 10:54:26','setup','4','glpi adicionou um usuário a uma entidade');
INSERT INTO `glpi_events` VALUES ('177','6','users','2018-01-08 10:55:05','setup','4','glpi adicionou um usuário a uma entidade');
INSERT INTO `glpi_events` VALUES ('178','-1','system','2018-01-08 10:55:33','login','3','eduardo fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('179','-1','system','2018-01-09 10:20:32','login','3','normal fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('180','-1','system','2018-01-09 10:21:35','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('181','1','ticket','2018-01-09 07:44:32','tracking','4','glpi adicionou o item 1');
INSERT INTO `glpi_events` VALUES ('182','-1','system','2018-01-09 17:04:24','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('183','1','ticket','2018-01-09 17:05:23','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('184','1','ticket','2018-01-09 17:05:47','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('185','1','ticket','2018-01-09 17:08:46','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('186','1','ticket','2018-01-09 17:09:11','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('187','1','ticket','2018-01-09 17:12:53','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('188','1','ticket','2018-01-09 17:21:08','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('189','1','ticket','2018-01-09 17:22:33','tracking','4','glpi adicionou uma tarefa');
INSERT INTO `glpi_events` VALUES ('190','1','ticket','2018-01-09 17:23:42','tracking','4','glpi atualizou uma tarefa');
INSERT INTO `glpi_events` VALUES ('191','-1','system','2018-01-11 06:06:39','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('192','1','ITILCategory','2018-01-11 06:07:33','setup','4','glpi adicionou o item Redes');
INSERT INTO `glpi_events` VALUES ('193','2','ITILCategory','2018-01-11 06:08:21','setup','4','glpi adicionou o item Sistemas');
INSERT INTO `glpi_events` VALUES ('194','3','ITILCategory','2018-01-11 06:08:31','setup','4','glpi adicionou o item Servicedesk');
INSERT INTO `glpi_events` VALUES ('195','4','ITILCategory','2018-01-11 06:09:04','setup','4','glpi adicionou o item Internet');
INSERT INTO `glpi_events` VALUES ('196','5','ITILCategory','2018-01-11 06:09:24','setup','4','glpi adicionou o item VPN');
INSERT INTO `glpi_events` VALUES ('197','6','ITILCategory','2018-01-11 06:09:38','setup','4','glpi adicionou o item Vendas');
INSERT INTO `glpi_events` VALUES ('198','7','ITILCategory','2018-01-11 06:09:44','setup','4','glpi adicionou o item E-mail');
INSERT INTO `glpi_events` VALUES ('199','1','ticket','2018-01-11 06:10:31','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('200','1','ticket','2018-01-11 06:12:06','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('201','1','ticket','2018-01-11 06:14:22','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('202','1','ticket','2018-01-11 06:14:55','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('203','1','ticket','2018-01-11 06:15:08','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('204','1','tickettemplate','2018-01-11 06:22:10','maintain','4','glpi adicionou um campo predefinido');
INSERT INTO `glpi_events` VALUES ('205','1','tickettemplate','2018-01-11 06:23:30','maintain','4','glpi adicionou um campo predefinido');
INSERT INTO `glpi_events` VALUES ('206','2','ticket','2018-01-11 06:25:13','tracking','4','glpi adicionou o item 2');
INSERT INTO `glpi_events` VALUES ('207','1','ticket','2018-01-11 06:27:25','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('208','1','ticket','2018-01-11 06:31:08','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('209','9','rules','2018-01-11 06:40:01','setup','4','glpi adicionou o item 9');
INSERT INTO `glpi_events` VALUES ('210','2','ticket','2018-01-11 06:41:46','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('211','2','ticket','2018-01-11 06:42:06','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('212','2','ticket','2018-01-11 06:42:13','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('213','2','ticket','2018-01-11 06:42:16','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('214','10','rules','2018-01-11 06:42:49','setup','4','glpi adicionou o item 10');
INSERT INTO `glpi_events` VALUES ('215','2','ticket','2018-01-11 06:44:02','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('216','2','ticket','2018-01-11 06:44:13','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('217','2','ticket','2018-01-11 06:53:21','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('218','2','ticket','2018-01-11 06:53:44','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('219','2','ticket','2018-01-11 06:54:19','tracking','4','glpi adicionou uma aprovação');
INSERT INTO `glpi_events` VALUES ('220','2','ticket','2018-01-11 06:55:17','tracking','4','glpi atualizou uma aprovação');
INSERT INTO `glpi_events` VALUES ('221','2','ticket','2018-01-11 06:56:11','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('222','-1','system','2018-01-11 18:28:27','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('223','1','mailcollector','2018-01-11 18:34:35','setup','4','glpi adicionou o item chamados@eftech.com.br');
INSERT INTO `glpi_events` VALUES ('224','7','users','2018-01-11 18:37:03','setup','4','glpi adicionou o item Cliente 1');
INSERT INTO `glpi_events` VALUES ('225','7','users','2018-01-11 18:41:21','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('226','7','users','2018-01-11 18:49:10','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('227','7','users','2018-01-11 18:51:04','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('228','3','ticket','2018-01-11 18:52:14','tracking','4','glpi adicionou o item 3');
INSERT INTO `glpi_events` VALUES ('229','-1','system','2018-01-11 20:44:12','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('230','6','users','2018-01-13 12:55:43','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('231','4','ticket','2018-01-13 12:57:00','tracking','4','glpi adicionou o item 4');
INSERT INTO `glpi_events` VALUES ('232','4','ticket','2018-01-13 12:57:58','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('233','4','ticket','2018-01-13 13:03:00','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('234','4','ticket','2018-01-13 13:06:25','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('235','4','ticket','2018-01-13 13:08:35','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('236','1','slms','2018-01-13 13:18:26','setup','4','glpi adicionou o item Default');
INSERT INTO `glpi_events` VALUES ('237','1','slas','2018-01-13 13:19:20','setup','4','glpi adicionou o item SLA 1hora Aceitar');
INSERT INTO `glpi_events` VALUES ('238','2','slas','2018-01-13 13:20:00','setup','4','glpi adicionou o item SLA 1dia Solução');
INSERT INTO `glpi_events` VALUES ('239','1','olas','2018-01-13 13:20:47','setup','4','glpi adicionou o item OLA 30min Aceitar');
INSERT INTO `glpi_events` VALUES ('240','2','olas','2018-01-13 13:21:13','setup','4','glpi adicionou o item OLA 12h Solução');
INSERT INTO `glpi_events` VALUES ('241','1','slms','2018-01-13 13:22:01','setup','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('242','5','ticket','2018-01-13 13:23:19','tracking','4','glpi adicionou o item 5');
INSERT INTO `glpi_events` VALUES ('243','5','ticket','2018-01-13 13:23:34','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('244','3','users','2018-01-13 13:25:22','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('245','1','slas','2018-01-13 13:28:40','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('246','-1','system','2018-01-13 13:31:10','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('247','6','ticket','2018-01-13 13:31:50','tracking','4','post-only adicionou o item 6');
INSERT INTO `glpi_events` VALUES ('248','6','ticket','2018-01-13 13:32:50','tracking','4','post-only atualizou um item');
INSERT INTO `glpi_events` VALUES ('249','-1','system','2018-01-13 13:33:00','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('250','6','ticket','2018-01-13 13:33:27','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('251','6','ticket','2018-01-13 13:33:49','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('252','6','ticket','2018-01-13 13:34:13','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('253','6','ticket','2018-01-13 13:35:48','tracking','4','glpi excluiu um item');
INSERT INTO `glpi_events` VALUES ('254','6','ticket','2018-01-13 13:35:55','tracking','4','glpi apagou um item');
INSERT INTO `glpi_events` VALUES ('255','2','slas','2018-01-13 13:39:46','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('256','2','slas','2018-01-13 13:40:27','setup','4','glpi atualizou um nível de sla');
INSERT INTO `glpi_events` VALUES ('257','1','tickettemplate','2018-01-13 13:44:44','maintain','4','glpi adicionou um campo predefinido');
INSERT INTO `glpi_events` VALUES ('258','1','tickettemplate','2018-01-13 13:44:58','maintain','4','glpi adicionou um campo predefinido');
INSERT INTO `glpi_events` VALUES ('259','-1','system','2018-01-13 13:45:47','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('260','7','ticket','2018-01-13 13:46:12','tracking','4','post-only adicionou o item 7');
INSERT INTO `glpi_events` VALUES ('261','7','ticket','2018-01-13 13:47:33','tracking','4','post-only atualizou um item');
INSERT INTO `glpi_events` VALUES ('262','7','ticket','2018-01-13 13:47:51','tracking','4','post-only atualizou um item');
INSERT INTO `glpi_events` VALUES ('263','-1','system','2018-01-13 13:48:01','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('264','7','ticket','2018-01-13 13:48:23','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('265','7','ticket','2018-01-13 13:48:35','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('266','7','ticket','2018-01-13 13:48:44','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('267','7','ticket','2018-01-13 13:49:07','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('268','7','ticket','2018-01-13 13:49:26','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('269','7','ticket','2018-01-13 13:49:36','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('270','7','ticket','2018-01-13 13:49:49','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('271','7','ticket','2018-01-13 13:50:04','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('272','7','ticket','2018-01-13 13:50:23','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('273','-1','system','2018-01-13 13:50:49','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('274','-1','system','2018-01-13 13:52:23','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('275','0','Entity','2018-01-13 13:53:24','setup','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('276','0','Entity','2018-01-13 13:57:59','setup','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('277','8','ticket','2018-01-13 13:59:33','tracking','4','glpi adicionou o item 8');
INSERT INTO `glpi_events` VALUES ('278','8','ticket','2018-01-13 13:59:53','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('279','9','ticket','2018-01-13 14:02:11','tracking','4','glpi adicionou o item 9');
INSERT INTO `glpi_events` VALUES ('280','9','ticket','2018-01-13 14:02:49','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('281','9','ticket','2018-01-13 14:03:01','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('282','9','ticket','2018-01-13 14:03:14','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('283','10','ticket','2018-01-13 14:04:08','tracking','4','glpi adicionou o item 10');
INSERT INTO `glpi_events` VALUES ('284','1','slas','2018-01-13 14:08:17','setup','4','glpi atualizou um nível de sla');
INSERT INTO `glpi_events` VALUES ('285','-1','system','2018-01-13 14:08:44','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('286','11','ticket','2018-01-13 14:09:06','tracking','4','post-only adicionou o item 11');
INSERT INTO `glpi_events` VALUES ('287','-1','system','2018-01-13 14:11:22','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('288','12','ticket','2018-01-13 14:12:02','tracking','4','glpi adicionou o item 12');
INSERT INTO `glpi_events` VALUES ('289','12','ticket','2018-01-13 14:12:22','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('290','12','ticket','2018-01-13 14:12:45','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('291','12','ticket','2018-01-13 14:13:00','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('292','1','slas','2018-01-13 14:15:58','setup','4','glpi atualizou um nível de sla');
INSERT INTO `glpi_events` VALUES ('293','1','slas','2018-01-13 14:16:36','setup','4','glpi atualizou um nível de sla');
INSERT INTO `glpi_events` VALUES ('294','13','ticket','2018-01-13 14:17:11','tracking','4','glpi adicionou o item 13');
INSERT INTO `glpi_events` VALUES ('295','13','ticket','2018-01-13 14:17:22','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('296','13','ticket','2018-01-13 14:17:29','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('297','13','ticket','2018-01-13 14:17:57','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('298','13','ticket','2018-01-13 14:18:13','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('299','11','rules','2018-01-13 14:28:07','setup','4','glpi adicionou o item 11');
INSERT INTO `glpi_events` VALUES ('300','1','calendars','2018-01-13 14:32:46','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('301','1','calendars','2018-01-13 14:33:00','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('302','1','calendars','2018-01-13 14:33:31','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('303','1','calendars','2018-01-13 14:33:41','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('304','1','calendars','2018-01-13 14:33:52','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('305','1','calendars','2018-01-13 14:34:05','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('306','1','calendars','2018-01-13 14:34:17','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('307','1','calendars','2018-01-13 14:34:26','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('308','1','calendars','2018-01-13 14:34:39','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('309','1','calendars','2018-01-13 14:34:59','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('310','1','calendars','2018-01-13 14:35:37','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('311','1','calendars','2018-01-13 14:35:46','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('312','1','calendars','2018-01-13 14:35:57','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('313','1','calendars','2018-01-13 14:36:13','setup','4','glpi adicionou um relacionamento com um item');
INSERT INTO `glpi_events` VALUES ('314','14','ticket','2018-01-13 14:37:44','tracking','4','glpi adicionou o item 14');
INSERT INTO `glpi_events` VALUES ('315','14','ticket','2018-01-13 14:37:55','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('316','14','ticket','2018-01-13 14:38:06','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('317','15','ticket','2018-01-13 14:39:17','tracking','4','glpi adicionou o item 15');
INSERT INTO `glpi_events` VALUES ('318','15','ticket','2018-01-13 14:39:33','tracking','4','glpi excluiu um ator');
INSERT INTO `glpi_events` VALUES ('319','-1','system','2018-01-13 14:39:49','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('320','16','ticket','2018-01-13 14:40:03','tracking','4','post-only adicionou o item 16');
INSERT INTO `glpi_events` VALUES ('321','-1','system','2018-01-13 14:42:01','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('322','1','slas','2018-01-13 14:42:22','setup','4','glpi atualizou um nível de sla');
INSERT INTO `glpi_events` VALUES ('323','-1','system','2018-01-13 14:44:04','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('324','17','ticket','2018-01-13 14:44:20','tracking','4','post-only adicionou o item 17');
INSERT INTO `glpi_events` VALUES ('325','-1','system','2018-01-13 14:46:28','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('326','-1','system','2018-01-13 14:55:07','login','3','alda fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('327','18','ticket','2018-01-13 14:55:19','tracking','4','alda adicionou o item 18');
INSERT INTO `glpi_events` VALUES ('328','-1','system','2018-01-13 14:55:51','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('329','-1','system','2018-01-13 14:57:33','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('330','17','ticket','2018-01-13 15:02:11','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('331','-1','system','2018-01-13 15:03:27','login','3','post-only fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('332','-1','system','2018-01-13 16:38:04','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('333','-1','system','2018-01-16 23:57:52','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('334','-1','system','2018-01-18 21:22:04','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('335','6','users','2018-01-18 21:50:12','setup','5','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('336','28','notificationtemplates','2018-01-18 21:50:38','notification','4','glpi adicionou o item Novo chamado (telegram)');
INSERT INTO `glpi_events` VALUES ('337','28','notificationtemplatetranslations','2018-01-18 21:51:43','notification','4','glpi adicionou o item ');
INSERT INTO `glpi_events` VALUES ('338','70','notifications','2018-01-18 21:52:30','notification','4','glpi adicionou o item Novo chamado (Telegram)');
INSERT INTO `glpi_events` VALUES ('339','-1','system','2018-01-18 21:53:38','login','3','eduardo fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('340','19','ticket','2018-01-18 21:54:03','tracking','4','eduardo adicionou o item 19');
INSERT INTO `glpi_events` VALUES ('341','-1','system','2018-02-28 18:36:23','login','3','Login falhou para admin no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('342','-1','system','2018-02-28 18:36:40','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('343','-1','system','2018-03-10 06:54:32','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('344','-1','system','2018-03-20 07:50:34','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('345','7','ticket','2018-03-20 07:51:23','tracking','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('346','7','ticket','2018-03-20 07:52:00','tracking','4','glpi adicionou um acompanhamento');
INSERT INTO `glpi_events` VALUES ('347','-1','system','2018-03-26 21:07:09','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('348','-1','system','2018-03-27 18:22:29','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('349','-1','system','2018-04-05 14:09:53','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('350','-1','system','2018-05-14 19:08:36','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('351','-1','system','2018-05-21 07:52:53','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('352','1','BudgetType','2018-05-21 14:22:05','setup','4','glpi adicionou o item Anual');
INSERT INTO `glpi_events` VALUES ('353','2','BudgetType','2018-05-21 14:22:16','setup','4','glpi adicionou o item Projetos');
INSERT INTO `glpi_events` VALUES ('354','-1','system','2018-05-21 14:28:55','login','3','Login falhou para glpi no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('355','-1','system','2018-05-21 14:29:06','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('356','1','budget','2018-05-21 14:37:03','financial','4','glpi adicionou o item DTI 2018');
INSERT INTO `glpi_events` VALUES ('357','2','budget','2018-05-21 14:44:26','financial','4','glpi adicionou o item &lt;Departamento&gt;');
INSERT INTO `glpi_events` VALUES ('358','1','budget','2018-05-21 14:44:31','financial','4','glpi apagou um item');
INSERT INTO `glpi_events` VALUES ('359','3','budget','2018-05-21 14:47:38','financial','4','glpi adicionou o item DTI 2018');
INSERT INTO `glpi_events` VALUES ('360','73','DocumentType','2018-05-21 15:29:11','setup','4','glpi adicionou o item MP4');
INSERT INTO `glpi_events` VALUES ('361','1','DocumentCategory','2018-05-21 15:46:28','setup','4','glpi adicionou o item Contrato');
INSERT INTO `glpi_events` VALUES ('362','2','DocumentCategory','2018-05-21 15:46:41','setup','4','glpi adicionou o item Proposta');
INSERT INTO `glpi_events` VALUES ('363','1','documents','2018-05-21 16:05:17','login','4','glpi adicionou o item Contrato de manutanção');
INSERT INTO `glpi_events` VALUES ('364','3','DocumentCategory','2018-05-21 16:07:39','setup','4','glpi adicionou o item Procedimento');
INSERT INTO `glpi_events` VALUES ('365','2','documents','2018-05-21 16:08:16','login','4','glpi adicionou o item Procedimento');
INSERT INTO `glpi_events` VALUES ('366','2','documents','2018-05-21 16:09:11','document','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('367','2','documents','2018-05-21 16:09:35','document','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('368','2','documents','2018-05-21 16:10:33','document','4','glpi excluiu um item');
INSERT INTO `glpi_events` VALUES ('369','-1','system','2018-05-21 21:23:59','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('370','-1','system','2018-05-21 22:07:59','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('371','-1','system','2018-05-21 22:09:50','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('372','-1','system','2018-05-29 10:18:58','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('373','1','mailcollector','2018-05-29 10:22:00','setup','4','glpi atualizou um item');
INSERT INTO `glpi_events` VALUES ('374','-1','system','2018-07-09 21:47:10','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('375','4','groups','2018-07-09 22:05:43','setup','4','glpi adicionou o item TI-administração');
INSERT INTO `glpi_events` VALUES ('376','-1','system','2018-07-10 18:53:19','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('377','-1','system','2018-07-29 08:26:42','login','3','glpi fez login no IP 192.168.56.1');
INSERT INTO `glpi_events` VALUES ('378','14','rules','2018-07-29 08:28:20','setup','4','glpi adicionou o item 14');
INSERT INTO `glpi_events` VALUES ('379','-1','system','2018-08-13 18:19:53','login','3','glpi fez login no IP 192.168.56.1');

### Dump table glpi_fieldblacklists

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_fieldunicities

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `fields` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `action_refuse` tinyint(1) NOT NULL DEFAULT '0',
  `action_notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores field unicity criterias';


### Dump table glpi_filesystems

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_filesystems` VALUES ('1','ext',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('2','ext2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('3','ext3',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('4','ext4',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('5','FAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('6','FAT32',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('7','VFAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('8','HFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('9','HPFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('10','HTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('11','JFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('12','JFS2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('13','NFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('14','NTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('15','ReiserFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('16','SMBFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('17','UDF',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('18','UFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('19','XFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('20','ZFS',NULL,NULL,NULL);

### Dump table glpi_fqdns

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `fqdn` (`fqdn`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` text COLLATE utf8_unicode_ci,
  `ldap_group_dn` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_requester` tinyint(1) NOT NULL DEFAULT '1',
  `is_assign` tinyint(1) NOT NULL DEFAULT '1',
  `is_task` tinyint(1) NOT NULL DEFAULT '1',
  `is_notify` tinyint(1) NOT NULL DEFAULT '1',
  `is_itemgroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_usergroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `ldap_value` (`ldap_value`(200)),
  KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  KEY `groups_id` (`groups_id`),
  KEY `is_requester` (`is_requester`),
  KEY `is_assign` (`is_assign`),
  KEY `is_notify` (`is_notify`),
  KEY `is_itemgroup` (`is_itemgroup`),
  KEY `is_usergroup` (`is_usergroup`),
  KEY `is_manager` (`is_manager`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups` VALUES ('1','0','0','Servicedesk','',NULL,NULL,NULL,'2018-01-08 10:27:01','0','Servicedesk','1','[]','{\"1\":\"1\"}','1','1','0','1','1','1','1','2018-01-08 10:27:01');
INSERT INTO `glpi_groups` VALUES ('2','0','0','Redes','',NULL,NULL,NULL,'2018-01-08 10:28:16','0','Redes','1','[]',NULL,'0','1','0','1','1','1','1','2018-01-08 10:28:16');
INSERT INTO `glpi_groups` VALUES ('3','0','0','Sistemas','',NULL,NULL,NULL,'2018-01-08 10:28:28','0','Sistemas','1','[]',NULL,'0','1','0','1','1','1','1','2018-01-08 10:28:28');
INSERT INTO `glpi_groups` VALUES ('4','4','0','TI-administração','',NULL,NULL,NULL,'2018-07-09 22:05:43','0','TI-administração','1','[]',NULL,'1','1','0','1','1','1','1','2018-07-09 22:05:43');

### Dump table glpi_groups_knowbaseitems

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_problems

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_reminders

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_rssfeeds

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_tickets

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups_tickets` VALUES ('1','1','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('3','2','3','2');
INSERT INTO `glpi_groups_tickets` VALUES ('6','7','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('4','10','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('8','14','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('9','15','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('5','16','1','2');
INSERT INTO `glpi_groups_tickets` VALUES ('10','16','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('7','17','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('12','18','1','2');
INSERT INTO `glpi_groups_tickets` VALUES ('11','18','2','2');
INSERT INTO `glpi_groups_tickets` VALUES ('13','19','1','2');
INSERT INTO `glpi_groups_tickets` VALUES ('14','19','2','2');

### Dump table glpi_groups_users

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_userdelegate` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_manager` (`is_manager`),
  KEY `is_userdelegate` (`is_userdelegate`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups_users` VALUES ('1','4','1','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('2','6','2','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('3','2','3','0','0','0');

### Dump table glpi_holidays

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_perpetual` (`is_perpetual`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_infocoms

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immo_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `sink_time` int(11) NOT NULL DEFAULT '0',
  `sink_type` int(11) NOT NULL DEFAULT '0',
  `sink_coeff` float NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `bill` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `decommission_date` datetime DEFAULT NULL,
  `businesscriticities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  KEY `buy_date` (`buy_date`),
  KEY `alert` (`alert`),
  KEY `budgets_id` (`budgets_id`),
  KEY `suppliers_id` (`suppliers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `businesscriticities_id` (`businesscriticities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_infocoms` VALUES ('1','2','Computer','0','0',NULL,NULL,'0',NULL,'0',NULL,NULL,NULL,'0.0000','0.0000','0','0','0',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,'2017-11-30 10:35:24','2017-11-30 10:35:24',NULL,'0');
INSERT INTO `glpi_infocoms` VALUES ('2','9','Monitor','0','0',NULL,NULL,'0',NULL,'0',NULL,NULL,NULL,'0.0000','0.0000','0','0','0',NULL,NULL,'0','0',NULL,NULL,NULL,NULL,'2017-12-01 10:15:19','2017-12-01 10:15:19',NULL,'0');

### Dump table glpi_interfacetypes

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_interfacetypes` VALUES ('1','IDE',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('2','SATA',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('3','SCSI',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('4','USB',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('5','AGP','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('6','PCI','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('7','PCIe','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('8','PCI-X','',NULL,NULL);

### Dump table glpi_ipaddresses

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `binary_0` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_1` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_2` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `mainitems_id` int(11) NOT NULL DEFAULT '0',
  `mainitemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `textual` (`name`),
  KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ipaddresses` VALUES ('1','0','1','NetworkName','4','192.168.1.100','0','0','65535','3232235876','0','0','2','Printer');
INSERT INTO `glpi_ipaddresses` VALUES ('3','0','3','NetworkName','4','192.168.1.1','0','0','65535','3232235777','0','0','2','NetworkEquipment');
INSERT INTO `glpi_ipaddresses` VALUES ('4','0','4','NetworkName','4','192.168.25.8','0','0','65535','3232241928','0','1','9','Computer');
INSERT INTO `glpi_ipaddresses` VALUES ('5','0','4','NetworkName','6','fe80::a00:27ff:fe97:300f','4269801472','0','167782399','4271321103','0','1','9','Computer');
INSERT INTO `glpi_ipaddresses` VALUES ('6','0','5','NetworkName','4','192.168.25.53','0','0','65535','3232241973','0','1','10','Computer');
INSERT INTO `glpi_ipaddresses` VALUES ('7','0','6','NetworkName','4','192.168.25.5','0','0','65535','3232241925','0','1','12','Computer');

### Dump table glpi_ipaddresses_ipnetworks

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddresses_id` int(11) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  KEY `ipnetworks_id` (`ipnetworks_id`),
  KEY `ipaddresses_id` (`ipaddresses_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ipaddresses_ipnetworks` VALUES ('1','3','1');
INSERT INTO `glpi_ipaddresses_ipnetworks` VALUES ('2','4','2');
INSERT INTO `glpi_ipaddresses_ipnetworks` VALUES ('3','6','2');
INSERT INTO `glpi_ipaddresses_ipnetworks` VALUES ('4','7','2');

### Dump table glpi_ipnetworks

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `addressable` tinyint(1) NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_0` int(10) unsigned NOT NULL DEFAULT '0',
  `address_1` int(10) unsigned NOT NULL DEFAULT '0',
  `address_2` int(10) unsigned NOT NULL DEFAULT '0',
  `address_3` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `netmask_0` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_1` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_2` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_3` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_0` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_1` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_2` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_3` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_definition` (`entities_id`,`address`,`netmask`),
  KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ipnetworks` VALUES ('1','0','0','0','LAN-1andar','1','[]',NULL,'1','4','LAN-1andar','192.168.1.0','0','0','65535','3232235776','255.255.255.0','4294967295','4294967295','4294967295','4294967040','192.168.1.1','0','0','65535','3232235777','','2017-12-07 10:33:40','2017-12-07 10:33:40');
INSERT INTO `glpi_ipnetworks` VALUES ('2','0','0','0','192.168.25.0/255.255.255.0 - 192.168.25.1','1','[]',NULL,'1','4','192.168.25.0/255.255.255.0 - 192.168.25.1','192.168.25.0','0','0','65535','3232241920','255.255.255.0','4294967295','4294967295','4294967295','4294967040','192.168.25.1','0','0','65535','3232241921',NULL,'2018-01-17 00:11:27','2018-01-17 00:11:27');

### Dump table glpi_ipnetworks_vlans

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ipnetworks_vlans` VALUES ('1','1','2');

### Dump table glpi_items_devicebatteries

DROP TABLE IF EXISTS `glpi_items_devicebatteries`;
CREATE TABLE `glpi_items_devicebatteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicebatteries_id` int(11) NOT NULL DEFAULT '0',
  `manufacturing_date` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicebatteries_id` (`devicebatteries_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecases

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecases_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecases_id` (`devicecases_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecontrols

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecontrols_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecontrols_id` (`devicecontrols_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicecontrols` VALUES ('1','9','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('2','9','Computer','2','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('3','9','Computer','3','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('4','9','Computer','4','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('5','9','Computer','5','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('6','9','Computer','6','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('7','9','Computer','7','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('8','9','Computer','8','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('9','9','Computer','9','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('10','9','Computer','10','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('11','10','Computer','11','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('12','10','Computer','12','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('13','10','Computer','13','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('14','11','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('15','11','Computer','2','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('16','11','Computer','3','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('17','11','Computer','4','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('18','11','Computer','5','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('19','11','Computer','6','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('20','11','Computer','7','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('21','11','Computer','8','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('22','11','Computer','9','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('23','11','Computer','14','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicecontrols` VALUES ('24','11','Computer','10','0','1','0','0',NULL,NULL,NULL,'0','0');

### Dump table glpi_items_devicedrives

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicedrives_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicedrives_id` (`devicedrives_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicedrives` VALUES ('1','10','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicedrives` VALUES ('2','12','Computer','2','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicedrives` VALUES ('3','12','Computer','2','0','1','0','0',NULL,NULL,NULL,'0','0');

### Dump table glpi_items_devicefirmwares

DROP TABLE IF EXISTS `glpi_items_devicefirmwares`;
CREATE TABLE `glpi_items_devicefirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicefirmwares_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicefirmwares_id` (`devicefirmwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicefirmwares` VALUES ('1','9','Computer','1','0','1','0','0',NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicefirmwares` VALUES ('2','10','Computer','1','0','1','0','0',NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicefirmwares` VALUES ('3','11','Computer','1','0','1','0','0',NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicefirmwares` VALUES ('4','12','Computer','2','0','1','0','0',NULL,NULL,'0','0');

### Dump table glpi_items_devicegenerics

DROP TABLE IF EXISTS `glpi_items_devicegenerics`;
CREATE TABLE `glpi_items_devicegenerics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegenerics_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegenerics_id` (`devicegenerics_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegraphiccards

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegraphiccards_id` int(11) NOT NULL DEFAULT '0',
  `memory` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  KEY `specificity` (`memory`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicegraphiccards` VALUES ('1','9','Computer','1','0','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicegraphiccards` VALUES ('2','10','Computer','2','0','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicegraphiccards` VALUES ('3','12','Computer','3','0','0','1','0','0',NULL,NULL,NULL,'0','0');

### Dump table glpi_items_deviceharddrives

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceharddrives_id` int(11) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceharddrives_id` (`deviceharddrives_id`),
  KEY `specificity` (`capacity`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_deviceharddrives` VALUES ('1','10','Computer','1','25595','VBaeb144f1-4b7f5bc7','0','1','0','0',NULL,NULL,'0','0');

### Dump table glpi_items_devicememories

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicememories_id` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicememories_id` (`devicememories_id`),
  KEY `specificity` (`size`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicemotherboards

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicemotherboards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicemotherboards_id` (`devicemotherboards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicenetworkcards

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  KEY `specificity` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicenetworkcards` VALUES ('1','9','Computer','1','08:00:27:97:30:0f','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicenetworkcards` VALUES ('2','10','Computer','2','08:00:27:f7:5f:7f','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicenetworkcards` VALUES ('3','12','Computer','3','d0:22:be:4d:14:ad','0','1','0','0',NULL,NULL,NULL,'0','0');

### Dump table glpi_items_devicepcis

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepcis_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepcis_id` (`devicepcis_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepowersupplies

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceprocessors

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceprocessors_id` int(11) NOT NULL DEFAULT '0',
  `frequency` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceprocessors_id` (`deviceprocessors_id`),
  KEY `specificity` (`frequency`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `nbcores` (`nbcores`),
  KEY `nbthreads` (`nbthreads`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_deviceprocessors` VALUES ('1','2','Computer','1','2000',NULL,'0','0','2','4','0','0',NULL,NULL,'1','0');
INSERT INTO `glpi_items_deviceprocessors` VALUES ('2','9','Computer','2','0',NULL,'0','1',NULL,NULL,'0','0',NULL,NULL,'0','0');
INSERT INTO `glpi_items_deviceprocessors` VALUES ('3','10','Computer','3','1995',NULL,'0','1',NULL,NULL,'0','0',NULL,NULL,'0','0');
INSERT INTO `glpi_items_deviceprocessors` VALUES ('4','11','Computer','2','0',NULL,'0','1',NULL,NULL,'0','0',NULL,NULL,'0','0');

### Dump table glpi_items_devicesensors

DROP TABLE IF EXISTS `glpi_items_devicesensors`;
CREATE TABLE `glpi_items_devicesensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesensors_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesensors_id` (`devicesensors_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesimcards

DROP TABLE IF EXISTS `glpi_items_devicesimcards`;
CREATE TABLE `glpi_items_devicesimcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (id)',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `devicesimcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `lines_id` int(11) NOT NULL DEFAULT '0',
  `pin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pin2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `puk` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `puk2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `msin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `devicesimcards_id` (`devicesimcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `states_id` (`states_id`),
  KEY `locations_id` (`locations_id`),
  KEY `lines_id` (`lines_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesoundcards

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesoundcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesoundcards_id` (`devicesoundcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_devicesoundcards` VALUES ('1','9','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicesoundcards` VALUES ('2','9','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicesoundcards` VALUES ('3','10','Computer','2','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicesoundcards` VALUES ('4','11','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');
INSERT INTO `glpi_items_devicesoundcards` VALUES ('5','11','Computer','1','0','1','0','0',NULL,NULL,NULL,'0','0');

### Dump table glpi_items_disks

DROP TABLE IF EXISTS `glpi_items_disks`;
CREATE TABLE `glpi_items_disks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesystems_id` int(11) NOT NULL DEFAULT '0',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`),
  KEY `filesystems_id` (`filesystems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `items_id` (`items_id`),
  KEY `itemtype` (`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_disks` VALUES ('1','0','Computer','9','/','/dev/sda1','/','4','6926','3739','0','1','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_items_disks` VALUES ('2','0','Computer','10','C:',NULL,'C:','14','25247','8587','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('3','0','Computer','11','/','/dev/mapper/cl-root','/','19','6334','3843','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('4','0','Computer','11','/boot','/dev/sda1','/boot','19','1014','832','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('5','0','Computer','12','/system','/dev/block/platform/msm_sdcc.1/by-name/system','/system','4','2299','32','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('6','0','Computer','12','/data','/dev/block/platform/msm_sdcc.1/by-name/userdata','/data','4','26993','1230','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('7','0','Computer','12','/cache','/dev/block/platform/msm_sdcc.1/by-name/cache','/cache','4','295','289','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('8','0','Computer','12','/persist','/dev/block/platform/msm_sdcc.1/by-name/persist','/persist','4','7','3','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('9','0','Computer','12','/efs','/dev/block/platform/msm_sdcc.1/by-name/efs','/efs','4','13','9','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('10','0','Computer','12','/persdata/absolute','/dev/block/platform/msm_sdcc.1/by-name/persdata','/persdata/absolute','4','8','4','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_items_disks` VALUES ('11','0','Computer','12','/preload','/dev/block/platform/msm_sdcc.1/by-name/hidden','/preload','4','9','0','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_items_enclosures

DROP TABLE IF EXISTS `glpi_items_enclosures`;
CREATE TABLE `glpi_items_enclosures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enclosures_id` int(11) NOT NULL,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`),
  KEY `relation` (`enclosures_id`,`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_operatingsystems

DROP TABLE IF EXISTS `glpi_items_operatingsystems`;
CREATE TABLE `glpi_items_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemarchitectures_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemkernelversions_id` int(11) NOT NULL DEFAULT '0',
  `license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operatingsystemeditions_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`items_id`,`itemtype`,`operatingsystems_id`,`operatingsystemarchitectures_id`),
  KEY `items_id` (`items_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  KEY `operatingsystemkernelversions_id` (`operatingsystemkernelversions_id`),
  KEY `operatingsystemeditions_id` (`operatingsystemeditions_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_operatingsystems` VALUES ('1','9','Computer','4','1','1','0','0','','','0','2018-01-17 00:11:27','2018-01-17 00:11:27','0','1','0','0');
INSERT INTO `glpi_items_operatingsystems` VALUES ('2','10','Computer','5','2','0','1','0','VKTXG-GXXY3-W97QP-GP4PV-PWD3K','00261-50000-00000-AA989','0','2018-01-17 00:11:29','2018-01-17 00:11:29','0','1','0','0');
INSERT INTO `glpi_items_operatingsystems` VALUES ('3','11','Computer','6','3','2','0','0','','','0','2018-01-17 00:11:29','2018-01-17 00:11:29','0','1','0','0');
INSERT INTO `glpi_items_operatingsystems` VALUES ('4','12','Computer','7','4','3','0','0','','','0','2018-01-17 00:11:29','2018-01-17 00:11:29','0','1','0','0');

### Dump table glpi_items_problems

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_projects

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_racks

DROP TABLE IF EXISTS `glpi_items_racks`;
CREATE TABLE `glpi_items_racks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `racks_id` int(11) NOT NULL,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `orientation` tinyint(1) DEFAULT NULL,
  `bgcolor` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hpos` tinyint(1) NOT NULL DEFAULT '0',
  `is_reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`,`is_reserved`),
  KEY `relation` (`racks_id`,`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_tickets

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_items_tickets` VALUES ('1','Computer','2','1');
INSERT INTO `glpi_items_tickets` VALUES ('2','NetworkEquipment','2','1');

### Dump table glpi_itilcategories

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `tickettemplates_id_incident` int(11) NOT NULL DEFAULT '0',
  `tickettemplates_id_demand` int(11) NOT NULL DEFAULT '0',
  `is_incident` int(11) NOT NULL DEFAULT '1',
  `is_request` int(11) NOT NULL DEFAULT '1',
  `is_problem` int(11) NOT NULL DEFAULT '1',
  `is_change` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  KEY `is_incident` (`is_incident`),
  KEY `is_request` (`is_request`),
  KEY `is_problem` (`is_problem`),
  KEY `is_change` (`is_change`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_itilcategories` VALUES ('1','0','0','0','Redes','Redes','','1','0','0','0','[]','{\"1\":\"1\",\"4\":\"4\",\"5\":\"5\"}','1','0','0','1','1','1','1','2018-01-11 06:07:33','2018-01-11 06:07:33');
INSERT INTO `glpi_itilcategories` VALUES ('2','0','0','0','Sistemas','Sistemas','','1','0','0','0','[]',NULL,'1','0','0','1','1','1','1','2018-01-11 06:08:21','2018-01-11 06:08:21');
INSERT INTO `glpi_itilcategories` VALUES ('3','0','0','0','Servicedesk','Servicedesk','','1','0','0','0','[]',NULL,'1','0','0','1','1','1','1','2018-01-11 06:08:31','2018-01-11 06:08:31');
INSERT INTO `glpi_itilcategories` VALUES ('4','0','0','1','Internet','Redes > Internet',NULL,'2','0','0','0','{\"1\":\"1\"}',NULL,'1','0','0','1','1','1','1','2018-01-11 06:09:04','2018-01-11 06:09:04');
INSERT INTO `glpi_itilcategories` VALUES ('5','0','0','1','VPN','Redes > VPN','','2','0','0','0','{\"1\":\"1\"}',NULL,'1','0','0','1','1','1','1','2018-01-11 06:09:24','2018-01-11 06:09:24');
INSERT INTO `glpi_itilcategories` VALUES ('6','0','0','2','Vendas','Sistemas > Vendas',NULL,'2','0','0','0','{\"2\":\"2\"}',NULL,'1','0','0','1','1','1','1','2018-01-11 06:09:38','2018-01-11 06:09:38');
INSERT INTO `glpi_itilcategories` VALUES ('7','0','0','2','E-mail','Sistemas > E-mail',NULL,'2','0','0','0','{\"2\":\"2\"}',NULL,'1','0','0','1','1','1','1','2018-01-11 06:09:44','2018-01-11 06:09:44');

### Dump table glpi_itilsolutions

DROP TABLE IF EXISTS `glpi_itilsolutions`;
CREATE TABLE `glpi_itilsolutions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solutiontype_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_approval` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `users_id_approval` int(11) NOT NULL DEFAULT '0',
  `user_name_approval` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `ticketfollowups_id` int(11) DEFAULT NULL COMMENT 'Followup reference on reject or approve a ticket solution',
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `item_id` (`items_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `users_id_approval` (`users_id_approval`),
  KEY `status` (`status`),
  KEY `ticketfollowups_id` (`ticketfollowups_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_itilsolutions` VALUES ('1','Ticket','1','0',NULL,'&lt;p&gt;Reconectou o cabo de rede&lt;/p&gt;','2018-01-11 06:27:25',NULL,'2018-01-11 06:27:25','2',NULL,'0','0',NULL,'3',NULL);
INSERT INTO `glpi_itilsolutions` VALUES ('2','Ticket','2','0',NULL,'&lt;p&gt;Efetuar o reload do apache&lt;/p&gt;','2018-01-11 06:56:11',NULL,'2018-01-11 06:56:11','2',NULL,'0','0',NULL,'3',NULL);
INSERT INTO `glpi_itilsolutions` VALUES ('3','Ticket','7','0',NULL,'&lt;p&gt;reiniciado o computador&lt;/p&gt;',NULL,NULL,NULL,'2',NULL,'0','0',NULL,'4',NULL);

### Dump table glpi_knowbaseitemcategories

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `is_faq` (`is_faq`),
  KEY `date_mod` (`date_mod`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  FULLTEXT KEY `fulltext` (`name`,`answer`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `answer` (`answer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_comments

DROP TABLE IF EXISTS `glpi_knowbaseitems_comments`;
CREATE TABLE `glpi_knowbaseitems_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_items

DROP TABLE IF EXISTS `glpi_knowbaseitems_items`;
CREATE TABLE `glpi_knowbaseitems_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`knowbaseitems_id`),
  KEY `itemtype` (`itemtype`),
  KEY `item_id` (`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_profiles

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_revisions

DROP TABLE IF EXISTS `glpi_knowbaseitems_revisions`;
CREATE TABLE `glpi_knowbaseitems_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `revision` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`knowbaseitems_id`,`revision`,`language`),
  KEY `revision` (`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_users

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemtranslations

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item` (`knowbaseitems_id`,`language`),
  KEY `users_id` (`users_id`),
  FULLTEXT KEY `fulltext` (`name`,`answer`),
  FULLTEXT KEY `name` (`name`),
  FULLTEXT KEY `answer` (`answer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_lineoperators

DROP TABLE IF EXISTS `glpi_lineoperators`;
CREATE TABLE `glpi_lineoperators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `mcc` int(11) DEFAULT NULL,
  `mnc` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`mcc`,`mnc`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_lines

DROP TABLE IF EXISTS `glpi_lines`;
CREATE TABLE `glpi_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `caller_num` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `caller_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `lineoperators_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `linetypes_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `lineoperators_id` (`lineoperators_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_linetypes

DROP TABLE IF EXISTS `glpi_linetypes`;
CREATE TABLE `glpi_linetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `open_window` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links_itemtypes

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  KEY `links_id` (`links_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_locations

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `building` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `altitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  KEY `locations_id` (`locations_id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_locations` VALUES ('1','0','0','Fortaleza','0','Fortaleza','','1','[]','{\"1\":\"1\"}',NULL,NULL,NULL,NULL,NULL,'','','','','','2017-11-29 10:05:31','2017-11-29 10:05:31');

### Dump table glpi_logs

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `itemtype_link` (`itemtype_link`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `id_search_option` (`id_search_option`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_logs` VALUES ('1','State','1','0','20','glpi (2)','2017-11-29 10:04:37','0','','');
INSERT INTO `glpi_logs` VALUES ('2','State','2','0','20','glpi (2)','2017-11-29 10:04:46','0','','');
INSERT INTO `glpi_logs` VALUES ('3','State','3','0','20','glpi (2)','2017-11-29 10:04:55','0','','');
INSERT INTO `glpi_logs` VALUES ('4','Location','1','0','20','glpi (2)','2017-11-29 10:05:31','0','','');
INSERT INTO `glpi_logs` VALUES ('5','ComputerType','1','0','20','glpi (2)','2017-11-29 10:05:50','0','','');
INSERT INTO `glpi_logs` VALUES ('6','ComputerType','2','0','20','glpi (2)','2017-11-29 10:05:56','0','','');
INSERT INTO `glpi_logs` VALUES ('7','Manufacturer','1','0','20','glpi (2)','2017-11-29 10:06:30','0','','');
INSERT INTO `glpi_logs` VALUES ('8','ComputerModel','1','0','20','glpi (2)','2017-11-29 10:07:05','0','','');
INSERT INTO `glpi_logs` VALUES ('9','Computer','1','0','20','glpi (2)','2017-11-29 10:07:36','0','','');
INSERT INTO `glpi_logs` VALUES ('10','Computer','2','0','20','glpi (2)','2017-11-29 10:09:26','0','','');
INSERT INTO `glpi_logs` VALUES ('11','Computer','3','0','20','glpi (2)','2017-11-29 10:09:33','0','','');
INSERT INTO `glpi_logs` VALUES ('12','Computer','4','0','20','glpi (2)','2017-11-29 10:09:37','0','','');
INSERT INTO `glpi_logs` VALUES ('13','Computer','5','0','20','glpi (2)','2017-11-29 10:09:39','0','','');
INSERT INTO `glpi_logs` VALUES ('14','Computer','6','0','20','glpi (2)','2017-11-29 10:09:49','0','','');
INSERT INTO `glpi_logs` VALUES ('15','Computer','7','0','20','glpi (2)','2017-11-29 10:09:56','0','','');
INSERT INTO `glpi_logs` VALUES ('16','Computer','8','0','20','glpi (2)','2017-11-29 10:10:02','0','','');
INSERT INTO `glpi_logs` VALUES ('17','Computer','2','','0','glpi (2)','2017-11-29 10:10:28','5','','56789');
INSERT INTO `glpi_logs` VALUES ('18','Computer','3','','0','glpi (2)','2017-11-29 10:10:39','5','','34567');
INSERT INTO `glpi_logs` VALUES ('19','Computer','4','','0','glpi (2)','2017-11-29 10:10:50','5','','67890');
INSERT INTO `glpi_logs` VALUES ('20','Computer','5','','0','glpi (2)','2017-11-29 10:11:26','5','','9876');
INSERT INTO `glpi_logs` VALUES ('25','Computer','8','0','13','glpi (2)','2017-11-30 10:28:51','0','','');
INSERT INTO `glpi_logs` VALUES ('26','Computer','8','0','14','glpi (2)','2017-11-30 10:29:09','0','','');
INSERT INTO `glpi_logs` VALUES ('27','Manufacturer','2','0','20','glpi (2)','2017-11-30 10:31:35','0','','');
INSERT INTO `glpi_logs` VALUES ('28','DeviceProcessorModel','1','0','20','glpi (2)','2017-11-30 10:32:23','0','','');
INSERT INTO `glpi_logs` VALUES ('29','DeviceProcessor','1','0','20','glpi (2)','2017-11-30 10:32:31','0','','');
INSERT INTO `glpi_logs` VALUES ('30','Computer','2','DeviceProcessor','1','glpi (2)','2017-11-30 10:32:56','0','','Intel Core i7 7400 (1)');
INSERT INTO `glpi_logs` VALUES ('31','Infocom','1','0','20','glpi (2)','2017-11-30 10:35:24','0','','');
INSERT INTO `glpi_logs` VALUES ('32','MonitorType','1','0','20','glpi (2)','2017-12-01 10:09:39','0','','');
INSERT INTO `glpi_logs` VALUES ('33','MonitorModel','1','0','20','glpi (2)','2017-12-01 10:10:08','0','','');
INSERT INTO `glpi_logs` VALUES ('34','Monitor','1','0','20','glpi (2)','2017-12-01 10:10:42','0','','');
INSERT INTO `glpi_logs` VALUES ('35','Monitor','2','0','20','glpi (2)','2017-12-01 10:11:11','0','','');
INSERT INTO `glpi_logs` VALUES ('36','Monitor','3','0','20','glpi (2)','2017-12-01 10:11:17','0','','');
INSERT INTO `glpi_logs` VALUES ('37','Monitor','4','0','20','glpi (2)','2017-12-01 10:11:24','0','','');
INSERT INTO `glpi_logs` VALUES ('38','Monitor','5','0','20','glpi (2)','2017-12-01 10:11:33','0','','');
INSERT INTO `glpi_logs` VALUES ('39','Monitor','6','0','20','glpi (2)','2017-12-01 10:11:39','0','','');
INSERT INTO `glpi_logs` VALUES ('40','Monitor','7','0','20','glpi (2)','2017-12-01 10:11:45','0','','');
INSERT INTO `glpi_logs` VALUES ('41','Monitor','8','0','20','glpi (2)','2017-12-01 10:11:51','0','','');
INSERT INTO `glpi_logs` VALUES ('42','Computer','2','Monitor','15','glpi (2)','2017-12-01 10:12:41','0','','MON-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('43','Monitor','2','Computer','15','glpi (2)','2017-12-01 10:12:41','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('44','Computer','3','Monitor','15','glpi (2)','2017-12-01 10:13:00','0','','MON-2017-002 (3)');
INSERT INTO `glpi_logs` VALUES ('45','Monitor','3','Computer','15','glpi (2)','2017-12-01 10:13:00','0','','DESK-2017-002 (3)');
INSERT INTO `glpi_logs` VALUES ('46','Monitor','9','0','20','glpi (2)','2017-12-01 10:14:15','0','','');
INSERT INTO `glpi_logs` VALUES ('47','Computer','4','Monitor','15','glpi (2)','2017-12-01 10:14:37','0','','KVM01 (9)');
INSERT INTO `glpi_logs` VALUES ('48','Monitor','9','Computer','15','glpi (2)','2017-12-01 10:14:37','0','','DESK-2017-003 (4)');
INSERT INTO `glpi_logs` VALUES ('49','Computer','5','Monitor','15','glpi (2)','2017-12-01 10:14:44','0','','KVM01 (9)');
INSERT INTO `glpi_logs` VALUES ('50','Monitor','9','Computer','15','glpi (2)','2017-12-01 10:14:44','0','','DESK-2017-004 (5)');
INSERT INTO `glpi_logs` VALUES ('51','Computer','6','Monitor','15','glpi (2)','2017-12-01 10:14:49','0','','KVM01 (9)');
INSERT INTO `glpi_logs` VALUES ('52','Monitor','9','Computer','15','glpi (2)','2017-12-01 10:14:49','0','','DESK-2017-005 (6)');
INSERT INTO `glpi_logs` VALUES ('53','Infocom','2','0','20','glpi (2)','2017-12-01 10:15:19','0','','');
INSERT INTO `glpi_logs` VALUES ('65','Computer','2','SoftwareVersion','4','glpi (2)','2017-12-03 13:24:00','0','','LibreOffice - 5.4.3 (1)');
INSERT INTO `glpi_logs` VALUES ('67','Computer','2','SoftwareLicense','15','glpi (2)','2017-12-03 13:24:12','0','','LibreOffice - Mozilla Public License Version 2.0 (1)');
INSERT INTO `glpi_logs` VALUES ('69','Computer','2','SoftwareLicense','16','glpi (2)','2017-12-03 13:25:51','0','LibreOffice - Mozilla Public License Version 2.0 (1)','');
INSERT INTO `glpi_logs` VALUES ('71','Computer','2','SoftwareVersion','5','glpi (2)','2017-12-03 13:25:58','0','LibreOffice - 5.4.3 (1)','');
INSERT INTO `glpi_logs` VALUES ('74','Computer','2','SoftwareVersion','4','glpi (2)','2017-12-03 13:26:59','0','','LibreOffice - 5.4.3 (1)');
INSERT INTO `glpi_logs` VALUES ('76','Computer','2','SoftwareLicense','15','glpi (2)','2017-12-03 13:27:09','0','','LibreOffice - Mozilla Public License Version 2.0 (1)');
INSERT INTO `glpi_logs` VALUES ('78','Computer','2','SoftwareVersion','5','glpi (2)','2017-12-03 13:27:35','0','LibreOffice - 5.4.3 (1)','');
INSERT INTO `glpi_logs` VALUES ('80','Computer','2','SoftwareLicense','16','glpi (2)','2017-12-03 13:27:46','0','LibreOffice - Mozilla Public License Version 2.0 (1)','');
INSERT INTO `glpi_logs` VALUES ('82','Computer','2','SoftwareLicense','15','glpi (2)','2017-12-03 13:27:58','0','','LibreOffice - Mozilla Public License Version 2.0 (1)');
INSERT INTO `glpi_logs` VALUES ('84','Computer','2','SoftwareLicense','16','glpi (2)','2017-12-03 13:28:12','0','LibreOffice - Mozilla Public License Version 2.0 (1)','');
INSERT INTO `glpi_logs` VALUES ('86','Computer','2','SoftwareVersion','4','glpi (2)','2017-12-03 13:28:27','0','','LibreOffice - 5.4.3 (1)');
INSERT INTO `glpi_logs` VALUES ('88','Computer','2','SoftwareLicense','15','glpi (2)','2017-12-03 13:28:41','0','','LibreOffice - Mozilla Public License Version 2.0 (1)');
INSERT INTO `glpi_logs` VALUES ('90','Computer','2','SoftwareVersion','5','glpi (2)','2017-12-03 13:29:08','0','LibreOffice - 5.4.3 (1)','');
INSERT INTO `glpi_logs` VALUES ('92','Computer','2','SoftwareLicense','16','glpi (2)','2017-12-03 13:29:17','0','LibreOffice - Mozilla Public License Version 2.0 (1)','');
INSERT INTO `glpi_logs` VALUES ('97','Manufacturer','4','0','20','glpi (2)','2017-12-03 14:16:22','0','','');
INSERT INTO `glpi_logs` VALUES ('98','SoftwareCategory','4','0','20','glpi (2)','2017-12-03 14:16:46','0','','');
INSERT INTO `glpi_logs` VALUES ('99','SoftwareCategory','5','0','20','glpi (2)','2017-12-03 14:16:51','0','','');
INSERT INTO `glpi_logs` VALUES ('100','Software','2','0','20','glpi (2)','2017-12-03 14:17:33','0','','');
INSERT INTO `glpi_logs` VALUES ('101','OperatingSystem','3','0','20','glpi (2)','2017-12-03 14:18:53','0','','');
INSERT INTO `glpi_logs` VALUES ('102','Software','2','SoftwareVersion','17','glpi (2)','2017-12-03 14:19:06','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('103','SoftwareVersion','2','0','20','glpi (2)','2017-12-03 14:19:06','0','','');
INSERT INTO `glpi_logs` VALUES ('104','Manufacturer','5','0','20','glpi (2)','2017-12-03 14:21:16','0','','');
INSERT INTO `glpi_logs` VALUES ('105','SoftwareLicense','2','0','20','glpi (2)','2017-12-03 14:21:36','0','','');
INSERT INTO `glpi_logs` VALUES ('106','Computer','2','SoftwareVersion','4','glpi (2)','2017-12-03 14:22:40','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('107','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:22:40','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('108','Computer','2','SoftwareLicense','15','glpi (2)','2017-12-03 14:23:02','0','','LibreOffice - Mozilla Public License Version 2.0 (2)');
INSERT INTO `glpi_logs` VALUES ('109','SoftwareLicense','2','Computer','15','glpi (2)','2017-12-03 14:23:02','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('110','SoftwareLicense','2','','0','glpi (2)','2017-12-03 14:24:06','7','&nbsp; (0)','5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('111','SoftwareLicense','2','','0','glpi (2)','2017-12-03 14:24:06','6','&nbsp; (0)','5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('112','Computer','3','SoftwareVersion','4','glpi (2)','2017-12-03 14:24:34','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('113','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:24:34','0','','DESK-2017-002 (3)');
INSERT INTO `glpi_logs` VALUES ('114','Computer','3','SoftwareLicense','15','glpi (2)','2017-12-03 14:24:46','0','','LibreOffice - Mozilla Public License Version 2.0 (2)');
INSERT INTO `glpi_logs` VALUES ('115','SoftwareLicense','2','Computer','15','glpi (2)','2017-12-03 14:24:46','0','','DESK-2017-002 (3)');
INSERT INTO `glpi_logs` VALUES ('116','Computer','4','SoftwareVersion','4','glpi (2)','2017-12-03 14:25:41','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('117','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:25:41','0','','DESK-2017-003 (4)');
INSERT INTO `glpi_logs` VALUES ('118','Computer','5','SoftwareVersion','4','glpi (2)','2017-12-03 14:25:41','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('119','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:25:41','0','','DESK-2017-004 (5)');
INSERT INTO `glpi_logs` VALUES ('120','Computer','6','SoftwareVersion','4','glpi (2)','2017-12-03 14:25:41','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('121','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:25:41','0','','DESK-2017-005 (6)');
INSERT INTO `glpi_logs` VALUES ('122','Computer','7','SoftwareVersion','4','glpi (2)','2017-12-03 14:25:41','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('123','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:25:41','0','','DESK-2017-006 (7)');
INSERT INTO `glpi_logs` VALUES ('124','Computer','8','SoftwareVersion','4','glpi (2)','2017-12-03 14:25:41','0','','LibreOffice - 5.4.3 (2)');
INSERT INTO `glpi_logs` VALUES ('125','SoftwareVersion','2','Computer','4','glpi (2)','2017-12-03 14:25:41','0','','DESK-2017-007 (8)');
INSERT INTO `glpi_logs` VALUES ('126','PeripheralType','1','0','20','glpi (2)','2017-12-06 10:18:27','0','','');
INSERT INTO `glpi_logs` VALUES ('127','Manufacturer','6','0','20','glpi (2)','2017-12-06 10:18:40','0','','');
INSERT INTO `glpi_logs` VALUES ('128','PeripheralModel','1','0','20','glpi (2)','2017-12-06 10:18:59','0','','');
INSERT INTO `glpi_logs` VALUES ('129','Peripheral','1','0','20','glpi (2)','2017-12-06 10:19:25','0','','');
INSERT INTO `glpi_logs` VALUES ('130','Peripheral','2','0','20','glpi (2)','2017-12-06 10:19:43','0','','');
INSERT INTO `glpi_logs` VALUES ('131','Computer','2','Peripheral','15','glpi (2)','2017-12-06 10:20:03','0','','SCN-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('132','Peripheral','2','Computer','15','glpi (2)','2017-12-06 10:20:03','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('133','NetworkEquipmentType','1','0','20','glpi (2)','2017-12-06 10:26:09','0','','');
INSERT INTO `glpi_logs` VALUES ('134','NetworkEquipmentType','2','0','20','glpi (2)','2017-12-06 10:26:15','0','','');
INSERT INTO `glpi_logs` VALUES ('135','NetworkEquipmentModel','1','0','20','glpi (2)','2017-12-06 10:26:40','0','','');
INSERT INTO `glpi_logs` VALUES ('136','NetworkEquipment','1','0','20','glpi (2)','2017-12-06 10:26:57','0','','');
INSERT INTO `glpi_logs` VALUES ('137','NetworkEquipment','2','0','20','glpi (2)','2017-12-06 10:27:17','0','','');
INSERT INTO `glpi_logs` VALUES ('138','NetworkPort','1','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (1)');
INSERT INTO `glpi_logs` VALUES ('139','NetworkPort','1','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('140','NetworkPort','2','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (2)');
INSERT INTO `glpi_logs` VALUES ('141','NetworkPort','2','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('142','NetworkPort','3','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (3)');
INSERT INTO `glpi_logs` VALUES ('143','NetworkPort','3','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('144','NetworkPort','4','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (4)');
INSERT INTO `glpi_logs` VALUES ('145','NetworkPort','4','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('146','NetworkPort','5','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (5)');
INSERT INTO `glpi_logs` VALUES ('147','NetworkPort','5','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('148','NetworkPort','6','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (6)');
INSERT INTO `glpi_logs` VALUES ('149','NetworkPort','6','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('150','NetworkPort','7','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (7)');
INSERT INTO `glpi_logs` VALUES ('151','NetworkPort','7','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('152','NetworkPort','8','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (8)');
INSERT INTO `glpi_logs` VALUES ('153','NetworkPort','8','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('154','NetworkPort','9','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (9)');
INSERT INTO `glpi_logs` VALUES ('155','NetworkPort','9','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('156','NetworkPort','10','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (10)');
INSERT INTO `glpi_logs` VALUES ('157','NetworkPort','10','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('158','NetworkPort','11','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (11)');
INSERT INTO `glpi_logs` VALUES ('159','NetworkPort','11','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('160','NetworkPort','12','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (12)');
INSERT INTO `glpi_logs` VALUES ('161','NetworkPort','12','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('162','NetworkPort','13','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (13)');
INSERT INTO `glpi_logs` VALUES ('163','NetworkPort','13','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('164','NetworkPort','14','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (14)');
INSERT INTO `glpi_logs` VALUES ('165','NetworkPort','14','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('166','NetworkPort','15','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (15)');
INSERT INTO `glpi_logs` VALUES ('167','NetworkPort','15','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('168','NetworkPort','16','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (16)');
INSERT INTO `glpi_logs` VALUES ('169','NetworkPort','16','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('170','NetworkPort','17','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (17)');
INSERT INTO `glpi_logs` VALUES ('171','NetworkPort','17','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('172','NetworkPort','18','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (18)');
INSERT INTO `glpi_logs` VALUES ('173','NetworkPort','18','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('174','NetworkPort','19','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (19)');
INSERT INTO `glpi_logs` VALUES ('175','NetworkPort','19','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('176','NetworkPort','20','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (20)');
INSERT INTO `glpi_logs` VALUES ('177','NetworkPort','20','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('178','NetworkPort','21','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (21)');
INSERT INTO `glpi_logs` VALUES ('179','NetworkPort','21','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('180','NetworkPort','22','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (22)');
INSERT INTO `glpi_logs` VALUES ('181','NetworkPort','22','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('182','NetworkPort','23','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (23)');
INSERT INTO `glpi_logs` VALUES ('183','NetworkPort','23','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('184','NetworkPort','24','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:28:32','0','','N/A (24)');
INSERT INTO `glpi_logs` VALUES ('185','NetworkPort','24','0','20','glpi (2)','2017-12-06 10:28:32','0','','');
INSERT INTO `glpi_logs` VALUES ('186','NetworkPort','25','NetworkPortEthernet','17','glpi (2)','2017-12-06 10:30:23','0','','N/A (25)');
INSERT INTO `glpi_logs` VALUES ('187','NetworkPort','25','0','20','glpi (2)','2017-12-06 10:30:23','0','','');
INSERT INTO `glpi_logs` VALUES ('188','NetworkPort','25','NetworkPort','7','glpi (2)','2017-12-06 10:33:58','0','','SWT-001 - GigabitEthernet-02 (2)');
INSERT INTO `glpi_logs` VALUES ('189','NetworkPort','2','NetworkPort','7','glpi (2)','2017-12-06 10:33:58','0','','DESK-2017-001 - GigabitEthernet-01 (25)');
INSERT INTO `glpi_logs` VALUES ('190','Location','1','Netpoint','17','glpi (2)','2017-12-06 10:35:33','0','','path-6-1-10');
INSERT INTO `glpi_logs` VALUES ('191','Netpoint','1','0','20','glpi (2)','2017-12-06 10:35:33','0','','');
INSERT INTO `glpi_logs` VALUES ('192','NetworkPort','2','NetworkPortEthernet','18','glpi (2)','2017-12-06 10:35:42','0','0','1');
INSERT INTO `glpi_logs` VALUES ('193','Netpoint','2','0','20','glpi (2)','2017-12-06 10:36:42','0','','');
INSERT INTO `glpi_logs` VALUES ('194','Location','1','Netpoint','17','glpi (2)','2017-12-06 10:37:05','0','','path-10-1-6');
INSERT INTO `glpi_logs` VALUES ('195','Netpoint','3','0','20','glpi (2)','2017-12-06 10:37:05','0','','');
INSERT INTO `glpi_logs` VALUES ('196','NetworkPort','25','NetworkPortEthernet','18','glpi (2)','2017-12-06 10:37:13','0','0','3');
INSERT INTO `glpi_logs` VALUES ('197','NetworkPort','25','NetworkPortEthernet','18','glpi (2)','2017-12-06 10:37:19','0','','T');
INSERT INTO `glpi_logs` VALUES ('198','PrinterType','1','0','20','glpi (2)','2017-12-07 10:17:29','0','','');
INSERT INTO `glpi_logs` VALUES ('199','Manufacturer','7','0','20','glpi (2)','2017-12-07 10:17:40','0','','');
INSERT INTO `glpi_logs` VALUES ('200','PrinterModel','1','0','20','glpi (2)','2017-12-07 10:17:56','0','','');
INSERT INTO `glpi_logs` VALUES ('201','Printer','1','0','20','glpi (2)','2017-12-07 10:18:05','0','','');
INSERT INTO `glpi_logs` VALUES ('202','Printer','1','','0','glpi (2)','2017-12-07 10:18:34','1','&lt;IMP-/Y-###&gt;','&lt;IMP-\\Y-###&gt;');
INSERT INTO `glpi_logs` VALUES ('203','Printer','2','0','20','glpi (2)','2017-12-07 10:18:58','0','','');
INSERT INTO `glpi_logs` VALUES ('204','Location','1','Netpoint','17','glpi (2)','2017-12-07 10:19:42','0','','path-6-1-11');
INSERT INTO `glpi_logs` VALUES ('205','Netpoint','4','0','20','glpi (2)','2017-12-07 10:19:42','0','','');
INSERT INTO `glpi_logs` VALUES ('206','NetworkPort','26','NetworkPortEthernet','17','glpi (2)','2017-12-07 10:19:54','0','','N/A (26)');
INSERT INTO `glpi_logs` VALUES ('207','NetworkPort','26','0','20','glpi (2)','2017-12-07 10:19:54','0','','');
INSERT INTO `glpi_logs` VALUES ('208','NetworkPort','26','NetworkPort','7','glpi (2)','2017-12-07 10:20:25','0','','SWT-001 - GigabitEthernet-05 (5)');
INSERT INTO `glpi_logs` VALUES ('209','NetworkPort','5','NetworkPort','7','glpi (2)','2017-12-07 10:20:25','0','','IMP-2017-001 - LAN (26)');
INSERT INTO `glpi_logs` VALUES ('210','Network','1','0','20','glpi (2)','2017-12-07 10:21:45','0','','');
INSERT INTO `glpi_logs` VALUES ('211','Printer','2','','0','glpi (2)','2017-12-07 10:21:53','32','&nbsp; (0)','REDE_IMPRESSORAS (1)');
INSERT INTO `glpi_logs` VALUES ('212','Printer','2','','0','glpi (2)','2017-12-07 10:22:28','82','0','1');
INSERT INTO `glpi_logs` VALUES ('213','Computer','2','Printer','15','glpi (2)','2017-12-07 10:22:40','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('214','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:40','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('215','Computer','3','Printer','15','glpi (2)','2017-12-07 10:22:44','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('216','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:44','0','','DESK-2017-002 (3)');
INSERT INTO `glpi_logs` VALUES ('217','Computer','4','Printer','15','glpi (2)','2017-12-07 10:22:49','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('218','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:49','0','','DESK-2017-003 (4)');
INSERT INTO `glpi_logs` VALUES ('219','Computer','5','Printer','15','glpi (2)','2017-12-07 10:22:53','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('220','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:53','0','','DESK-2017-004 (5)');
INSERT INTO `glpi_logs` VALUES ('221','Computer','6','Printer','15','glpi (2)','2017-12-07 10:22:56','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('222','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:56','0','','DESK-2017-005 (6)');
INSERT INTO `glpi_logs` VALUES ('223','Computer','7','Printer','15','glpi (2)','2017-12-07 10:22:59','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('224','Printer','2','Computer','15','glpi (2)','2017-12-07 10:22:59','0','','DESK-2017-006 (7)');
INSERT INTO `glpi_logs` VALUES ('225','Computer','8','Printer','15','glpi (2)','2017-12-07 10:23:03','0','','IMP-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('226','Printer','2','Computer','15','glpi (2)','2017-12-07 10:23:03','0','','DESK-2017-007 (8)');
INSERT INTO `glpi_logs` VALUES ('227','NetworkName','1','IPAddress','17','glpi (2)','2017-12-07 10:24:00','0','','192.168.1.100 (1)');
INSERT INTO `glpi_logs` VALUES ('228','NetworkPort','26','NetworkName','17','glpi (2)','2017-12-07 10:24:00','0','','imp-1andar (1)');
INSERT INTO `glpi_logs` VALUES ('229','NetworkName','1','0','20','glpi (2)','2017-12-07 10:24:00','0','','');
INSERT INTO `glpi_logs` VALUES ('230','NetworkPort','26','NetworkPortEthernet','18','glpi (2)','2017-12-07 10:24:15','0','0','100');
INSERT INTO `glpi_logs` VALUES ('231','Vlan','1','0','20','glpi (2)','2017-12-07 10:28:13','0','','');
INSERT INTO `glpi_logs` VALUES ('232','NetworkPort','1','Vlan','15','glpi (2)','2017-12-07 10:28:50','0','','vlan200 (1)');
INSERT INTO `glpi_logs` VALUES ('233','Vlan','1','NetworkPort','15','glpi (2)','2017-12-07 10:28:50','0','','SWT-001 - GigabitEthernet-01 (1)');
INSERT INTO `glpi_logs` VALUES ('234','Vlan','2','0','20','glpi (2)','2017-12-07 10:29:35','0','','');
INSERT INTO `glpi_logs` VALUES ('235','NetworkPort','2','Vlan','15','glpi (2)','2017-12-07 10:29:45','0','','Default (2)');
INSERT INTO `glpi_logs` VALUES ('236','Vlan','2','NetworkPort','15','glpi (2)','2017-12-07 10:29:45','0','','SWT-001 - GigabitEthernet-02 (2)');
INSERT INTO `glpi_logs` VALUES ('237','NetworkPort','25','Vlan','15','glpi (2)','2017-12-07 10:30:14','0','','Default (2)');
INSERT INTO `glpi_logs` VALUES ('238','Vlan','2','NetworkPort','15','glpi (2)','2017-12-07 10:30:14','0','','DESK-2017-001 - GigabitEthernet-01 (25)');
INSERT INTO `glpi_logs` VALUES ('239','NetworkPort','1','NetworkName','17','glpi (2)','2017-12-07 10:31:27','0','','1andar (2)');
INSERT INTO `glpi_logs` VALUES ('240','NetworkName','2','0','20','glpi (2)','2017-12-07 10:31:27','0','','');
INSERT INTO `glpi_logs` VALUES ('241','NetworkName','3','IPAddress','17','glpi (2)','2017-12-07 10:32:37','0','','192.168.1.1 (2)');
INSERT INTO `glpi_logs` VALUES ('242','NetworkPort','1','NetworkName','17','glpi (2)','2017-12-07 10:32:37','0','','vlaninterface1 (3)');
INSERT INTO `glpi_logs` VALUES ('243','NetworkName','3','0','20','glpi (2)','2017-12-07 10:32:37','0','','');
INSERT INTO `glpi_logs` VALUES ('244','IPNetwork','1','0','20','glpi (2)','2017-12-07 10:33:40','0','','');
INSERT INTO `glpi_logs` VALUES ('245','NetworkName','3','IPAddress','19','glpi (2)','2017-12-07 10:34:21','0','192.168.1.1 (2)','');
INSERT INTO `glpi_logs` VALUES ('246','IPNetwork','1','IPAddress','15','glpi (2)','2017-12-07 10:34:41','0','','192.168.1.1 (3)');
INSERT INTO `glpi_logs` VALUES ('247','NetworkName','3','IPAddress','17','glpi (2)','2017-12-07 10:34:41','0','','192.168.1.1 (3)');
INSERT INTO `glpi_logs` VALUES ('248','IPNetwork','1','Vlan','15','glpi (2)','2017-12-07 10:36:01','0','','Default (2)');
INSERT INTO `glpi_logs` VALUES ('249','Vlan','2','IPNetwork','15','glpi (2)','2017-12-07 10:36:01','0','','LAN-1andar (1)');
INSERT INTO `glpi_logs` VALUES ('250','NetworkName','3','','0','glpi (2)','2017-12-07 10:38:34','21','1','0');
INSERT INTO `glpi_logs` VALUES ('251','NetworkName','3','','0','glpi (2)','2017-12-07 10:38:34','20','NetworkPort','');
INSERT INTO `glpi_logs` VALUES ('252','NetworkName','3','IPAddress','18','glpi (2)','2017-12-07 10:38:34','0','NetworkEquipment','NULL');
INSERT INTO `glpi_logs` VALUES ('253','NetworkName','3','IPAddress','18','glpi (2)','2017-12-07 10:38:34','0','2','0');
INSERT INTO `glpi_logs` VALUES ('254','NetworkPort','1','NetworkName','19','glpi (2)','2017-12-07 10:38:34','0','vlaninterface1 (3)','');
INSERT INTO `glpi_logs` VALUES ('255','NetworkName','2','','0','glpi (2)','2017-12-07 10:38:38','21','1','0');
INSERT INTO `glpi_logs` VALUES ('256','NetworkName','2','','0','glpi (2)','2017-12-07 10:38:38','20','NetworkPort','');
INSERT INTO `glpi_logs` VALUES ('257','NetworkPort','1','NetworkName','19','glpi (2)','2017-12-07 10:38:38','0','1andar (2)','');
INSERT INTO `glpi_logs` VALUES ('258','NetworkName','3','','0','glpi (2)','2017-12-07 10:38:59','21','0','2');
INSERT INTO `glpi_logs` VALUES ('259','NetworkName','3','','0','glpi (2)','2017-12-07 10:38:59','20','','NetworkPort');
INSERT INTO `glpi_logs` VALUES ('260','NetworkName','3','IPAddress','18','glpi (2)','2017-12-07 10:38:59','0','','NetworkEquipment');
INSERT INTO `glpi_logs` VALUES ('261','NetworkName','3','IPAddress','18','glpi (2)','2017-12-07 10:38:59','0','0','2');
INSERT INTO `glpi_logs` VALUES ('262','NetworkPort','2','NetworkName','17','glpi (2)','2017-12-07 10:38:59','0','','vlaninterface1 (3)');
INSERT INTO `glpi_logs` VALUES ('263','User','6','Profile','17','glpi (2)','2018-01-08 10:17:49','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('264','User','6','0','20','glpi (2)','2018-01-08 10:17:49','0','','');
INSERT INTO `glpi_logs` VALUES ('265','User','4','','0','','2018-01-08 10:19:46','15','0','1');
INSERT INTO `glpi_logs` VALUES ('266','Group','1','0','20','glpi (2)','2018-01-08 10:27:01','0','','');
INSERT INTO `glpi_logs` VALUES ('267','Group','2','0','20','glpi (2)','2018-01-08 10:28:16','0','','');
INSERT INTO `glpi_logs` VALUES ('268','Group','3','0','20','glpi (2)','2018-01-08 10:28:28','0','','');
INSERT INTO `glpi_logs` VALUES ('269','User','4','Group','15','glpi (2)','2018-01-08 10:29:46','0','','Servicedesk (1)');
INSERT INTO `glpi_logs` VALUES ('270','Group','1','User','15','glpi (2)','2018-01-08 10:29:46','0','','tech (4)');
INSERT INTO `glpi_logs` VALUES ('271','User','6','Group','15','glpi (2)','2018-01-08 10:30:05','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('272','Group','2','User','15','glpi (2)','2018-01-08 10:30:05','0','','Fraga Eduardo (6)');
INSERT INTO `glpi_logs` VALUES ('273','User','2','Group','15','glpi (2)','2018-01-08 10:30:25','0','','Sistemas (3)');
INSERT INTO `glpi_logs` VALUES ('274','Group','3','User','15','glpi (2)','2018-01-08 10:30:25','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('275','Entity','0','','0','glpi (2)','2018-01-08 10:38:01','14','Root entity','FAME Consultoria');
INSERT INTO `glpi_logs` VALUES ('276','Entity','0','','0','glpi (2)','2018-01-08 10:38:01','1','Root entity','FAME Consultoria');
INSERT INTO `glpi_logs` VALUES ('277','Entity','1','0','20','glpi (2)','2018-01-08 10:38:23','0','','');
INSERT INTO `glpi_logs` VALUES ('278','Entity','2','0','20','glpi (2)','2018-01-08 10:38:33','0','','');
INSERT INTO `glpi_logs` VALUES ('279','Entity','1','Entity','17','glpi (2)','2018-01-08 10:39:15','0','','Produção');
INSERT INTO `glpi_logs` VALUES ('280','Entity','3','0','20','glpi (2)','2018-01-08 10:39:15','0','','');
INSERT INTO `glpi_logs` VALUES ('281','Entity','1','Entity','17','glpi (2)','2018-01-08 10:39:23','0','','Administração');
INSERT INTO `glpi_logs` VALUES ('282','Entity','4','0','20','glpi (2)','2018-01-08 10:39:23','0','','');
INSERT INTO `glpi_logs` VALUES ('283','Entity','2','Entity','17','glpi (2)','2018-01-08 10:39:41','0','','Administração');
INSERT INTO `glpi_logs` VALUES ('284','Entity','5','0','20','glpi (2)','2018-01-08 10:39:41','0','','');
INSERT INTO `glpi_logs` VALUES ('285','Entity','2','Entity','17','glpi (2)','2018-01-08 10:39:46','0','','Produção');
INSERT INTO `glpi_logs` VALUES ('286','Entity','6','0','20','glpi (2)','2018-01-08 10:39:46','0','','');
INSERT INTO `glpi_logs` VALUES ('287','User','4','','0','glpi (2)','2018-01-08 10:40:44','80','FAME Consultoria (0)','FAME Consultoria > ABC (1)');
INSERT INTO `glpi_logs` VALUES ('288','User','4','','0','glpi (2)','2018-01-08 10:41:00','80','FAME Consultoria > ABC (1)','FAME Consultoria (0)');
INSERT INTO `glpi_logs` VALUES ('289','User','6','Profile','17','glpi (2)','2018-01-08 10:54:12','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('290','User','6','Profile','17','glpi (2)','2018-01-08 10:54:22','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('291','User','6','Profile','17','glpi (2)','2018-01-08 10:54:26','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('292','User','6','Profile','19','glpi (2)','2018-01-08 10:54:43','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('293','User','6','Profile','19','glpi (2)','2018-01-08 10:54:43','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('294','User','6','Profile','19','glpi (2)','2018-01-08 10:54:57','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('295','User','6','Profile','17','glpi (2)','2018-01-08 10:55:05','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('296','User','5','','0','','2018-01-09 10:20:32','15','0','1');
INSERT INTO `glpi_logs` VALUES ('297','Ticket','1','User','15','glpi (2)','2018-01-09 07:44:32','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('298','Ticket','1','','0','glpi (2)','2018-01-09 07:44:32','150','0','235');
INSERT INTO `glpi_logs` VALUES ('299','Ticket','1','User','15','glpi (2)','2018-01-09 07:44:32','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('300','Ticket','1','0','20','glpi (2)','2018-01-09 07:44:32','0','','');
INSERT INTO `glpi_logs` VALUES ('301','Ticket','1','User','16','glpi (2)','2018-01-09 17:05:23','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('302','Ticket','1','User','15','glpi (2)','2018-01-09 17:05:47','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('303','Ticket','1','','0','glpi (2)','2018-01-09 17:08:46','12','2','1');
INSERT INTO `glpi_logs` VALUES ('304','Ticket','1','User','16','glpi (2)','2018-01-09 17:08:46','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('305','Ticket','1','User','15','glpi (2)','2018-01-09 17:09:11','0','','normal (5)');
INSERT INTO `glpi_logs` VALUES ('306','Ticket','1','Group','15','glpi (2)','2018-01-09 17:09:11','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('307','Ticket','1','','0','glpi (2)','2018-01-09 17:09:11','12','1','2');
INSERT INTO `glpi_logs` VALUES ('308','Ticket','1','','0','glpi (2)','2018-01-09 17:12:53','83','&nbsp; (0)','Fortaleza (1)');
INSERT INTO `glpi_logs` VALUES ('309','Ticket','1','Computer','15','glpi (2)','2018-01-09 17:12:53','0','','DESK-2017-001 (2)');
INSERT INTO `glpi_logs` VALUES ('310','Computer','2','Ticket','15','glpi (2)','2018-01-09 17:12:53','0','','Não consigo acessar a Internet (1)');
INSERT INTO `glpi_logs` VALUES ('311','Ticket','1','NetworkEquipment','15','glpi (2)','2018-01-09 17:12:53','0','','SWT-001 (2)');
INSERT INTO `glpi_logs` VALUES ('312','NetworkEquipment','2','Ticket','15','glpi (2)','2018-01-09 17:12:53','0','','Não consigo acessar a Internet (1)');
INSERT INTO `glpi_logs` VALUES ('313','Ticket','1','TicketFollowup','17','glpi (2)','2018-01-09 17:21:08','0','','1');
INSERT INTO `glpi_logs` VALUES ('314','Ticket','1','TicketTask','17','glpi (2)','2018-01-09 17:22:33','0','','1');
INSERT INTO `glpi_logs` VALUES ('315','Ticket','1','TicketTask','18','glpi (2)','2018-01-09 17:22:40','0','','1');
INSERT INTO `glpi_logs` VALUES ('316','Ticket','1','TicketTask','18','glpi (2)','2018-01-09 17:22:42','0','','1');
INSERT INTO `glpi_logs` VALUES ('317','Ticket','1','TicketTask','18','glpi (2)','2018-01-09 17:23:42','0','','1');
INSERT INTO `glpi_logs` VALUES ('318','Ticket','1','TicketTask','18','glpi (2)','2018-01-09 17:23:44','0','','1');
INSERT INTO `glpi_logs` VALUES ('319','Ticket','1','TicketTask','18','glpi (2)','2018-01-09 17:24:22','0','','1');
INSERT INTO `glpi_logs` VALUES ('320','ITILCategory','1','0','20','glpi (2)','2018-01-11 06:07:33','0','','');
INSERT INTO `glpi_logs` VALUES ('321','ITILCategory','2','0','20','glpi (2)','2018-01-11 06:08:21','0','','');
INSERT INTO `glpi_logs` VALUES ('322','ITILCategory','3','0','20','glpi (2)','2018-01-11 06:08:31','0','','');
INSERT INTO `glpi_logs` VALUES ('323','ITILCategory','1','ITILCategory','17','glpi (2)','2018-01-11 06:09:04','0','','Internet');
INSERT INTO `glpi_logs` VALUES ('324','ITILCategory','4','0','20','glpi (2)','2018-01-11 06:09:04','0','','');
INSERT INTO `glpi_logs` VALUES ('325','ITILCategory','1','ITILCategory','17','glpi (2)','2018-01-11 06:09:24','0','','VPN');
INSERT INTO `glpi_logs` VALUES ('326','ITILCategory','5','0','20','glpi (2)','2018-01-11 06:09:24','0','','');
INSERT INTO `glpi_logs` VALUES ('327','ITILCategory','2','ITILCategory','17','glpi (2)','2018-01-11 06:09:38','0','','Vendas');
INSERT INTO `glpi_logs` VALUES ('328','ITILCategory','6','0','20','glpi (2)','2018-01-11 06:09:38','0','','');
INSERT INTO `glpi_logs` VALUES ('329','ITILCategory','2','ITILCategory','17','glpi (2)','2018-01-11 06:09:44','0','','E-mail');
INSERT INTO `glpi_logs` VALUES ('330','ITILCategory','7','0','20','glpi (2)','2018-01-11 06:09:44','0','','');
INSERT INTO `glpi_logs` VALUES ('331','Ticket','1','','0','glpi (2)','2018-01-11 06:10:31','7','&nbsp; (0)','Redes > Internet (4)');
INSERT INTO `glpi_logs` VALUES ('332','Ticket','1','TicketFollowup','17','glpi (2)','2018-01-11 06:12:06','0','','2');
INSERT INTO `glpi_logs` VALUES ('333','Ticket','1','TicketTask','18','glpi (2)','2018-01-11 06:12:13','0','','1');
INSERT INTO `glpi_logs` VALUES ('334','Ticket','1','','0','glpi (2)','2018-01-11 06:14:22','52','1','2');
INSERT INTO `glpi_logs` VALUES ('335','Ticket','1','','0','glpi (2)','2018-01-11 06:14:22','51','0','50');
INSERT INTO `glpi_logs` VALUES ('336','Ticket','1','','0','glpi (2)','2018-01-11 06:14:55','51','50','0');
INSERT INTO `glpi_logs` VALUES ('337','Ticket','1','','0','glpi (2)','2018-01-11 06:15:08','52','2','1');
INSERT INTO `glpi_logs` VALUES ('338','TicketTemplate','1','TicketTemplatePredefinedField','17','glpi (2)','2018-01-11 06:22:10','0','','Tempo para solução (1)');
INSERT INTO `glpi_logs` VALUES ('340','TicketTemplate','1','TicketTemplatePredefinedField','17','glpi (2)','2018-01-11 06:23:30','0','','Tempo para aceitar (2)');
INSERT INTO `glpi_logs` VALUES ('342','Ticket','2','User','15','glpi (2)','2018-01-11 06:25:13','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('343','Ticket','2','','0','glpi (2)','2018-01-11 06:25:13','150','0','58');
INSERT INTO `glpi_logs` VALUES ('344','Ticket','2','User','15','glpi (2)','2018-01-11 06:25:13','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('345','Ticket','2','0','20','glpi (2)','2018-01-11 06:25:13','0','','');
INSERT INTO `glpi_logs` VALUES ('346','Ticket','1','','0','glpi (2)','2018-01-11 06:27:25','24','','&lt;p&gt;Reconectou o cabo de rede&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('347','Ticket','1','','0','glpi (2)','2018-01-11 06:27:25','12','2','6');
INSERT INTO `glpi_logs` VALUES ('348','Ticket','1','','0','glpi (2)','2018-01-11 06:27:25','16','','2018-01-11 06:27:25');
INSERT INTO `glpi_logs` VALUES ('349','Ticket','1','','0','glpi (2)','2018-01-11 06:27:25','17','','2018-01-11 06:27:25');
INSERT INTO `glpi_logs` VALUES ('350','Ticket','1','TicketFollowup','17','glpi (2)','2018-01-11 06:32:01','0','','3');
INSERT INTO `glpi_logs` VALUES ('351','RuleTicket','9','0','20','glpi (2)','2018-01-11 06:40:01','0','','');
INSERT INTO `glpi_logs` VALUES ('352','RuleTicket','9','RuleCriteria','17','glpi (2)','2018-01-11 06:40:25','0','','Categoriainiciando comRedes (14)');
INSERT INTO `glpi_logs` VALUES ('353','RuleTicket','9','','0','glpi (2)','2018-01-11 06:40:25','19','2018-01-11 06:40:01','2018-01-11 06:40:25');
INSERT INTO `glpi_logs` VALUES ('354','RuleCriteria','14','0','20','glpi (2)','2018-01-11 06:40:25','0','','');
INSERT INTO `glpi_logs` VALUES ('355','RuleTicket','9','RuleAction','17','glpi (2)','2018-01-11 06:40:53','0','','Grupo técnicoAtribuirRedes (9)');
INSERT INTO `glpi_logs` VALUES ('356','RuleTicket','9','','0','glpi (2)','2018-01-11 06:40:53','19','2018-01-11 06:40:25','2018-01-11 06:40:53');
INSERT INTO `glpi_logs` VALUES ('357','RuleAction','9','0','20','glpi (2)','2018-01-11 06:40:53','0','','');
INSERT INTO `glpi_logs` VALUES ('358','Ticket','2','Group','15','glpi (2)','2018-01-11 06:41:46','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('359','Ticket','2','','0','glpi (2)','2018-01-11 06:41:46','7','&nbsp; (0)','Redes (1)');
INSERT INTO `glpi_logs` VALUES ('360','Ticket','2','','0','glpi (2)','2018-01-11 06:42:06','7','Redes (1)','Sistemas > Vendas (6)');
INSERT INTO `glpi_logs` VALUES ('361','Ticket','2','Group','16','glpi (2)','2018-01-11 06:42:13','0','Redes (2)','');
INSERT INTO `glpi_logs` VALUES ('362','Ticket','2','','0','glpi (2)','2018-01-11 06:42:16','12','2','1');
INSERT INTO `glpi_logs` VALUES ('363','Ticket','2','User','16','glpi (2)','2018-01-11 06:42:16','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('364','RuleTicket','10','0','20','glpi (2)','2018-01-11 06:42:49','0','','');
INSERT INTO `glpi_logs` VALUES ('365','RuleTicket','10','RuleCriteria','17','glpi (2)','2018-01-11 06:43:10','0','','Categoriainiciando comSistemas (15)');
INSERT INTO `glpi_logs` VALUES ('366','RuleTicket','10','','0','glpi (2)','2018-01-11 06:43:10','19','2018-01-11 06:42:49','2018-01-11 06:43:10');
INSERT INTO `glpi_logs` VALUES ('367','RuleCriteria','15','0','20','glpi (2)','2018-01-11 06:43:10','0','','');
INSERT INTO `glpi_logs` VALUES ('368','RuleTicket','10','RuleAction','17','glpi (2)','2018-01-11 06:43:37','0','','Grupo técnicoAtribuirSistemas (10)');
INSERT INTO `glpi_logs` VALUES ('369','RuleTicket','10','','0','glpi (2)','2018-01-11 06:43:37','19','2018-01-11 06:43:10','2018-01-11 06:43:37');
INSERT INTO `glpi_logs` VALUES ('370','RuleAction','10','0','20','glpi (2)','2018-01-11 06:43:37','0','','');
INSERT INTO `glpi_logs` VALUES ('371','Ticket','2','Group','15','glpi (2)','2018-01-11 06:44:02','0','','Sistemas (3)');
INSERT INTO `glpi_logs` VALUES ('372','Ticket','2','','0','glpi (2)','2018-01-11 06:44:02','7','Sistemas > Vendas (6)','Sistemas (2)');
INSERT INTO `glpi_logs` VALUES ('373','Ticket','2','','0','glpi (2)','2018-01-11 06:44:13','7','Sistemas (2)','Sistemas > Vendas (6)');
INSERT INTO `glpi_logs` VALUES ('374','Ticket','2','TicketFollowup','17','glpi (2)','2018-01-11 06:53:21','0','','4');
INSERT INTO `glpi_logs` VALUES ('375','Ticket','2','','0','glpi (2)','2018-01-11 06:53:44','52','1','2');
INSERT INTO `glpi_logs` VALUES ('376','Ticket','2','','0','glpi (2)','2018-01-11 06:53:44','51','0','100');
INSERT INTO `glpi_logs` VALUES ('377','Ticket','2','TicketValidation','12','glpi (2)','2018-01-11 06:54:19','0','','Envio de solicitação de aprovação a glpi');
INSERT INTO `glpi_logs` VALUES ('378','Ticket','2','','0','glpi (2)','2018-01-11 06:55:17','52','2','3');
INSERT INTO `glpi_logs` VALUES ('379','Ticket','2','TicketValidation','12','glpi (2)','2018-01-11 06:55:17','0','','Aprovação concedida por glpi');
INSERT INTO `glpi_logs` VALUES ('380','Ticket','2','','0','glpi (2)','2018-01-11 06:56:11','24','','&lt;p&gt;Efetuar o reload do apache&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('381','Ticket','2','','0','glpi (2)','2018-01-11 06:56:11','12','1','6');
INSERT INTO `glpi_logs` VALUES ('382','Ticket','2','','0','glpi (2)','2018-01-11 06:56:11','16','','2018-01-11 06:56:11');
INSERT INTO `glpi_logs` VALUES ('383','Ticket','2','','0','glpi (2)','2018-01-11 06:56:11','17','','2018-01-11 06:56:11');
INSERT INTO `glpi_logs` VALUES ('384','MailCollector','1','0','20','glpi (2)','2018-01-11 18:34:35','0','','');
INSERT INTO `glpi_logs` VALUES ('385','User','7','UserEmail','17','glpi (2)','2018-01-11 18:37:03','0','','zjpswqlt@sharklasers.com (1)');
INSERT INTO `glpi_logs` VALUES ('386','UserEmail','1','0','20','glpi (2)','2018-01-11 18:37:03','0','','');
INSERT INTO `glpi_logs` VALUES ('387','User','7','Profile','17','glpi (2)','2018-01-11 18:37:03','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('388','User','7','0','20','glpi (2)','2018-01-11 18:37:03','0','','');
INSERT INTO `glpi_logs` VALUES ('389','CronTask','9','','0','','2018-01-11 18:39:07','6','600','60');
INSERT INTO `glpi_logs` VALUES ('390','User','7','','0','glpi (2)','2018-01-11 18:41:21','20','&nbsp; (0)','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('391','RuleMailCollector','3','','0','glpi (2)','2018-01-11 18:44:05','3','3','2');
INSERT INTO `glpi_logs` VALUES ('392','RuleMailCollector','5','','0','glpi (2)','2018-01-11 18:44:05','3','2','3');
INSERT INTO `glpi_logs` VALUES ('393','RuleMailCollector','3','','0','glpi (2)','2018-01-11 18:44:07','3','2','1');
INSERT INTO `glpi_logs` VALUES ('394','RuleMailCollector','4','','0','glpi (2)','2018-01-11 18:44:07','3','1','2');
INSERT INTO `glpi_logs` VALUES ('395','RuleMailCollector','3','','0','glpi (2)','2018-01-11 18:46:56','3','1','2');
INSERT INTO `glpi_logs` VALUES ('396','RuleMailCollector','4','','0','glpi (2)','2018-01-11 18:46:56','3','2','1');
INSERT INTO `glpi_logs` VALUES ('397','RuleMailCollector','3','','0','glpi (2)','2018-01-11 18:46:58','3','2','3');
INSERT INTO `glpi_logs` VALUES ('398','RuleMailCollector','5','','0','glpi (2)','2018-01-11 18:46:58','3','3','2');
INSERT INTO `glpi_logs` VALUES ('399','User','7','UserEmail','18','glpi (2)','2018-01-11 18:49:10','0','zjpswqlt@sharklasers.com','9if1hr+3vas8i1bhxkck@guerrillamail.com');
INSERT INTO `glpi_logs` VALUES ('400','Ticket','3','User','15','cron_mailgate','2018-01-11 18:52:14','0','','Cliente 1 (7)');
INSERT INTO `glpi_logs` VALUES ('401','Ticket','3','0','20','cron_mailgate','2018-01-11 18:52:14','0','','');
INSERT INTO `glpi_logs` VALUES ('402','User','6','UserEmail','17','glpi (2)','2018-01-13 12:55:43','0','','eduardo@eftech.com.br (2)');
INSERT INTO `glpi_logs` VALUES ('403','UserEmail','2','0','20','glpi (2)','2018-01-13 12:55:43','0','','');
INSERT INTO `glpi_logs` VALUES ('404','Ticket','4','User','15','cron_mailgate','2018-01-13 12:57:00','0','','Fraga Eduardo (6)');
INSERT INTO `glpi_logs` VALUES ('405','Ticket','4','0','20','cron_mailgate','2018-01-13 12:57:00','0','','');
INSERT INTO `glpi_logs` VALUES ('406','Ticket','4','','0','glpi (2)','2018-01-13 12:57:58','150','0','58');
INSERT INTO `glpi_logs` VALUES ('407','Ticket','4','','0','glpi (2)','2018-01-13 12:57:58','64','&nbsp; (0)','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('408','Ticket','4','','0','glpi (2)','2018-01-13 12:57:58','12','1','4');
INSERT INTO `glpi_logs` VALUES ('409','Ticket','4','TicketFollowup','17','glpi (2)','2018-01-13 12:57:58','0','','5');
INSERT INTO `glpi_logs` VALUES ('410','Ticket','4','','0','cron_mailgate','2018-01-13 13:02:05','12','4','1');
INSERT INTO `glpi_logs` VALUES ('411','Ticket','4','TicketFollowup','17','cron_mailgate','2018-01-13 13:02:05','0','','6');
INSERT INTO `glpi_logs` VALUES ('412','Ticket','4','','0','glpi (2)','2018-01-13 13:03:00','12','1','6');
INSERT INTO `glpi_logs` VALUES ('413','Ticket','4','','0','glpi (2)','2018-01-13 13:03:00','16','','2018-01-13 13:03:00');
INSERT INTO `glpi_logs` VALUES ('414','Ticket','4','','0','glpi (2)','2018-01-13 13:03:00','17','','2018-01-13 13:03:00');
INSERT INTO `glpi_logs` VALUES ('415','Ticket','4','TicketFollowup','17','glpi (2)','2018-01-13 13:03:00','0','','7');
INSERT INTO `glpi_logs` VALUES ('416','Ticket','4','','0','glpi (2)','2018-01-13 13:06:25','12','6','1');
INSERT INTO `glpi_logs` VALUES ('417','Ticket','4','','0','glpi (2)','2018-01-13 13:06:25','17','2018-01-13 13:03:00','NULL');
INSERT INTO `glpi_logs` VALUES ('418','Ticket','4','','0','glpi (2)','2018-01-13 13:06:25','16','2018-01-13 13:03:00','NULL');
INSERT INTO `glpi_logs` VALUES ('419','Ticket','4','TicketFollowup','17','glpi (2)','2018-01-13 13:06:25','0','','8');
INSERT INTO `glpi_logs` VALUES ('420','Ticket','4','TicketFollowup','17','cron_mailgate','2018-01-13 13:07:45','0','','9');
INSERT INTO `glpi_logs` VALUES ('421','CronTask','9','','0','','2018-01-13 13:07:58','6','60','300');
INSERT INTO `glpi_logs` VALUES ('422','Ticket','4','','0','glpi (2)','2018-01-13 13:08:35','12','1','6');
INSERT INTO `glpi_logs` VALUES ('423','Ticket','4','','0','glpi (2)','2018-01-13 13:08:35','16','','2018-01-13 13:08:35');
INSERT INTO `glpi_logs` VALUES ('424','Ticket','4','','0','glpi (2)','2018-01-13 13:08:35','17','','2018-01-13 13:08:35');
INSERT INTO `glpi_logs` VALUES ('425','Ticket','4','TicketFollowup','17','glpi (2)','2018-01-13 13:08:35','0','','10');
INSERT INTO `glpi_logs` VALUES ('426','SLM','1','0','20','glpi (2)','2018-01-13 13:18:26','0','','');
INSERT INTO `glpi_logs` VALUES ('427','SLM','1','SLA','17','glpi (2)','2018-01-13 13:19:20','0','','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('428','SLA','1','0','20','glpi (2)','2018-01-13 13:19:20','0','','');
INSERT INTO `glpi_logs` VALUES ('429','SLM','1','SLA','17','glpi (2)','2018-01-13 13:20:00','0','','SLA 1dia Solução (2)');
INSERT INTO `glpi_logs` VALUES ('430','SLA','2','0','20','glpi (2)','2018-01-13 13:20:00','0','','');
INSERT INTO `glpi_logs` VALUES ('431','SLM','1','OLA','17','glpi (2)','2018-01-13 13:20:47','0','','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('432','OLA','1','0','20','glpi (2)','2018-01-13 13:20:47','0','','');
INSERT INTO `glpi_logs` VALUES ('433','SLM','1','OLA','17','glpi (2)','2018-01-13 13:21:13','0','','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('434','OLA','2','0','20','glpi (2)','2018-01-13 13:21:13','0','','');
INSERT INTO `glpi_logs` VALUES ('435','Ticket','5','User','15','glpi (2)','2018-01-13 13:23:19','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('436','Ticket','5','','0','glpi (2)','2018-01-13 13:23:19','150','0','41');
INSERT INTO `glpi_logs` VALUES ('437','Ticket','5','User','15','glpi (2)','2018-01-13 13:23:19','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('438','Ticket','5','0','20','glpi (2)','2018-01-13 13:23:19','0','','');
INSERT INTO `glpi_logs` VALUES ('439','Ticket','5','','0','glpi (2)','2018-01-13 13:23:34','12','2','1');
INSERT INTO `glpi_logs` VALUES ('440','SlaLevel','1','0','20','glpi (2)','2018-01-13 13:28:40','0','','');
INSERT INTO `glpi_logs` VALUES ('441','SlaLevel','1','SlaLevelCriteria','17','glpi (2)','2018-01-13 13:29:04','0','','StatuséNovo (1)');
INSERT INTO `glpi_logs` VALUES ('442','SlaLevelCriteria','1','0','20','glpi (2)','2018-01-13 13:29:04','0','','');
INSERT INTO `glpi_logs` VALUES ('443','SlaLevel','1','SlaLevelAction','17','glpi (2)','2018-01-13 13:29:36','0','','Grupo técnicoAdicionarServicedesk (1)');
INSERT INTO `glpi_logs` VALUES ('444','SlaLevelAction','1','0','20','glpi (2)','2018-01-13 13:29:36','0','','');
INSERT INTO `glpi_logs` VALUES ('445','SlaLevel','1','SlaLevelAction','17','glpi (2)','2018-01-13 13:29:54','0','','StatusAtribuirProcessando (atribuído) (2)');
INSERT INTO `glpi_logs` VALUES ('447','User','3','','0','','2018-01-13 13:31:10','15','0','1');
INSERT INTO `glpi_logs` VALUES ('460','SlaLevel','2','0','20','glpi (2)','2018-01-13 13:39:46','0','','');
INSERT INTO `glpi_logs` VALUES ('461','SlaLevel','2','SlaLevelCriteria','17','glpi (2)','2018-01-13 13:40:20','0','','Statusnão éFechado (2)');
INSERT INTO `glpi_logs` VALUES ('462','SlaLevelCriteria','2','0','20','glpi (2)','2018-01-13 13:40:20','0','','');
INSERT INTO `glpi_logs` VALUES ('463','SlaLevel','2','','0','glpi (2)','2018-01-13 13:40:27','5','AND','OR');
INSERT INTO `glpi_logs` VALUES ('464','SlaLevel','2','SlaLevelCriteria','17','glpi (2)','2018-01-13 13:40:43','0','','StatuséSolucionado (3)');
INSERT INTO `glpi_logs` VALUES ('465','SlaLevelCriteria','3','0','20','glpi (2)','2018-01-13 13:40:43','0','','');
INSERT INTO `glpi_logs` VALUES ('466','SlaLevelCriteria','3','','0','glpi (2)','2018-01-13 13:40:56','2','0','1');
INSERT INTO `glpi_logs` VALUES ('467','SlaLevelCriteria','3','','0','glpi (2)','2018-01-13 13:40:56','3','5','1');
INSERT INTO `glpi_logs` VALUES ('468','SlaLevel','2','SlaLevelCriteria','18','glpi (2)','2018-01-13 13:40:56','0','0','1');
INSERT INTO `glpi_logs` VALUES ('469','SlaLevel','2','SlaLevelCriteria','18','glpi (2)','2018-01-13 13:40:56','0','5','1');
INSERT INTO `glpi_logs` VALUES ('470','SlaLevelCriteria','3','','0','glpi (2)','2018-01-13 13:41:10','3','1','5');
INSERT INTO `glpi_logs` VALUES ('471','SlaLevel','2','SlaLevelCriteria','18','glpi (2)','2018-01-13 13:41:10','0','1','5');
INSERT INTO `glpi_logs` VALUES ('472','SlaLevel','2','SlaLevelAction','17','glpi (2)','2018-01-13 13:42:40','0','','Grupo técnicoAdicionarRedes (3)');
INSERT INTO `glpi_logs` VALUES ('473','SlaLevelAction','3','0','20','glpi (2)','2018-01-13 13:42:40','0','','');
INSERT INTO `glpi_logs` VALUES ('474','SlaLevel','2','SlaLevelAction','17','glpi (2)','2018-01-13 13:43:08','0','','OLA Tempo para aceitarAtribuirOLA 30min Aceitar (4)');
INSERT INTO `glpi_logs` VALUES ('475','SlaLevelAction','4','0','20','glpi (2)','2018-01-13 13:43:08','0','','');
INSERT INTO `glpi_logs` VALUES ('476','SlaLevel','2','SlaLevelAction','17','glpi (2)','2018-01-13 13:43:23','0','','OLA Tempo para soluçãoAtribuirOLA 12h Solução (5)');
INSERT INTO `glpi_logs` VALUES ('477','SlaLevelAction','5','0','20','glpi (2)','2018-01-13 13:43:23','0','','');
INSERT INTO `glpi_logs` VALUES ('478','TicketTemplate','1','TicketTemplatePredefinedField','19','glpi (2)','2018-01-13 13:44:33','0','Tempo para solução (1)','');
INSERT INTO `glpi_logs` VALUES ('479','TicketTemplate','1','TicketTemplatePredefinedField','19','glpi (2)','2018-01-13 13:44:33','0','Tempo para aceitar (2)','');
INSERT INTO `glpi_logs` VALUES ('480','TicketTemplate','1','TicketTemplatePredefinedField','17','glpi (2)','2018-01-13 13:44:44','0','','SLAs&nbsp;Tempo para aceitar (3)');
INSERT INTO `glpi_logs` VALUES ('481','TicketTemplatePredefinedField','3','0','20','glpi (2)','2018-01-13 13:44:44','0','','');
INSERT INTO `glpi_logs` VALUES ('482','TicketTemplate','1','TicketTemplatePredefinedField','17','glpi (2)','2018-01-13 13:44:58','0','','SLAs&nbsp;Tempo para solução (4)');
INSERT INTO `glpi_logs` VALUES ('483','TicketTemplatePredefinedField','4','0','20','glpi (2)','2018-01-13 13:44:58','0','','');
INSERT INTO `glpi_logs` VALUES ('484','Ticket','7','User','15','post-only (3)','2018-01-13 13:46:12','0','','post-only (3)');
INSERT INTO `glpi_logs` VALUES ('485','Ticket','7','0','20','post-only (3)','2018-01-13 13:46:12','0','','');
INSERT INTO `glpi_logs` VALUES ('486','Ticket','7','','0','post-only (3)','2018-01-13 13:47:33','21','Qualquer coisa 

ldkjdkdj

','Qualquer coisa rnrnldkjdkdjrnrn');
INSERT INTO `glpi_logs` VALUES ('487','Ticket','7','','0','glpi (2)','2018-01-13 13:48:23','15','2018-01-13 13:46:12','2018-01-13 12:46');
INSERT INTO `glpi_logs` VALUES ('488','Ticket','7','','0','glpi (2)','2018-01-13 13:48:23','64','post-only (3)','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('489','Ticket','7','','0','glpi (2)','2018-01-13 13:48:35','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('490','Ticket','7','','0','glpi (2)','2018-01-13 13:48:35','155','2018-01-13 14:46:12','NULL');
INSERT INTO `glpi_logs` VALUES ('491','Ticket','7','','0','glpi (2)','2018-01-13 13:48:44','155','','2018-01-13 13:46:00');
INSERT INTO `glpi_logs` VALUES ('492','Ticket','7','','0','glpi (2)','2018-01-13 13:48:44','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('493','Ticket','7','','0','glpi (2)','2018-01-13 13:49:07','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('494','Ticket','7','','0','glpi (2)','2018-01-13 13:49:07','155','2018-01-13 13:46:00','NULL');
INSERT INTO `glpi_logs` VALUES ('495','Ticket','7','','0','glpi (2)','2018-01-13 13:49:26','15','2018-01-13 12:46:00','2018-01-13 12:05');
INSERT INTO `glpi_logs` VALUES ('496','Ticket','7','','0','glpi (2)','2018-01-13 13:49:26','155','','2018-01-13 13:05:00');
INSERT INTO `glpi_logs` VALUES ('497','Ticket','7','','0','glpi (2)','2018-01-13 13:49:26','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('498','Ticket','7','','0','glpi (2)','2018-01-13 13:49:36','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('499','Ticket','7','','0','glpi (2)','2018-01-13 13:49:36','155','2018-01-13 13:05:00','NULL');
INSERT INTO `glpi_logs` VALUES ('500','Ticket','7','','0','glpi (2)','2018-01-13 13:49:49','155','','2018-01-13 13:05:00');
INSERT INTO `glpi_logs` VALUES ('501','Ticket','7','','0','glpi (2)','2018-01-13 13:49:49','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('502','Ticket','7','','0','glpi (2)','2018-01-13 13:50:04','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('503','Ticket','7','','0','glpi (2)','2018-01-13 13:50:04','155','2018-01-13 13:05:00','NULL');
INSERT INTO `glpi_logs` VALUES ('504','Ticket','7','','0','glpi (2)','2018-01-13 13:50:23','15','2018-01-13 12:05:00','2018-01-13 12:51');
INSERT INTO `glpi_logs` VALUES ('505','Ticket','7','','0','glpi (2)','2018-01-13 13:50:23','155','','2018-01-13 13:51:00');
INSERT INTO `glpi_logs` VALUES ('506','Ticket','7','','0','glpi (2)','2018-01-13 13:50:23','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('507','Entity','0','','0','glpi (2)','2018-01-13 13:53:24','35','-10','2');
INSERT INTO `glpi_logs` VALUES ('508','SlaLevel','1','SlaLevelAction','17','glpi (2)','2018-01-13 13:55:49','0','','CategoriaAtribuirServicedesk (6)');
INSERT INTO `glpi_logs` VALUES ('510','Entity','0','','0','glpi (2)','2018-01-13 13:57:59','35','2','-10');
INSERT INTO `glpi_logs` VALUES ('511','Ticket','8','User','15','glpi (2)','2018-01-13 13:59:33','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('512','Ticket','8','','0','glpi (2)','2018-01-13 13:59:33','150','0','3573');
INSERT INTO `glpi_logs` VALUES ('513','Ticket','8','User','15','glpi (2)','2018-01-13 13:59:33','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('514','Ticket','8','0','20','glpi (2)','2018-01-13 13:59:33','0','','');
INSERT INTO `glpi_logs` VALUES ('515','Ticket','8','','0','glpi (2)','2018-01-13 13:59:53','12','2','1');
INSERT INTO `glpi_logs` VALUES ('516','Ticket','8','User','16','glpi (2)','2018-01-13 13:59:53','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('517','Ticket','9','User','15','glpi (2)','2018-01-13 14:02:11','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('518','Ticket','9','','0','glpi (2)','2018-01-13 14:02:11','150','0','71');
INSERT INTO `glpi_logs` VALUES ('519','Ticket','9','User','15','glpi (2)','2018-01-13 14:02:11','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('520','Ticket','9','0','20','glpi (2)','2018-01-13 14:02:11','0','','');
INSERT INTO `glpi_logs` VALUES ('521','Ticket','9','','0','glpi (2)','2018-01-13 14:02:49','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('522','Ticket','9','','0','glpi (2)','2018-01-13 14:02:49','155','2018-01-13 15:01:00','NULL');
INSERT INTO `glpi_logs` VALUES ('523','Ticket','9','','0','glpi (2)','2018-01-13 14:03:01','12','2','1');
INSERT INTO `glpi_logs` VALUES ('524','Ticket','9','User','16','glpi (2)','2018-01-13 14:03:01','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('525','Ticket','9','','0','glpi (2)','2018-01-13 14:03:14','155','','2018-01-13 15:01:00');
INSERT INTO `glpi_logs` VALUES ('526','Ticket','9','','0','glpi (2)','2018-01-13 14:03:14','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('527','Ticket','10','','0','glpi (2)','2018-01-13 14:04:08','150','0','86288');
INSERT INTO `glpi_logs` VALUES ('528','Ticket','10','Group','15','glpi (2)','2018-01-13 14:04:08','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('529','Ticket','10','','0','glpi (2)','2018-01-13 14:04:08','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('530','Ticket','10','','0','glpi (2)','2018-01-13 14:04:08','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('531','Ticket','10','','0','glpi (2)','2018-01-13 14:04:08','180','','2018-01-14 02:04:09');
INSERT INTO `glpi_logs` VALUES ('532','Ticket','10','','0','glpi (2)','2018-01-13 14:04:08','185','','2018-01-13 14:34:09');
INSERT INTO `glpi_logs` VALUES ('533','Ticket','10','User','15','glpi (2)','2018-01-13 14:04:08','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('534','Ticket','10','User','15','glpi (2)','2018-01-13 14:04:08','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('535','Ticket','10','0','20','glpi (2)','2018-01-13 14:04:08','0','','');
INSERT INTO `glpi_logs` VALUES ('536','SlaLevel','1','','0','glpi (2)','2018-01-13 14:08:17','4','-1800','-3000');
INSERT INTO `glpi_logs` VALUES ('537','Ticket','11','User','15','post-only (3)','2018-01-13 14:09:06','0','','post-only (3)');
INSERT INTO `glpi_logs` VALUES ('538','Ticket','11','0','20','post-only (3)','2018-01-13 14:09:06','0','','');
INSERT INTO `glpi_logs` VALUES ('539','Ticket','12','User','15','glpi (2)','2018-01-13 14:12:02','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('540','Ticket','12','','0','glpi (2)','2018-01-13 14:12:02','150','0','62');
INSERT INTO `glpi_logs` VALUES ('541','Ticket','12','User','15','glpi (2)','2018-01-13 14:12:02','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('542','Ticket','12','0','20','glpi (2)','2018-01-13 14:12:02','0','','');
INSERT INTO `glpi_logs` VALUES ('543','Ticket','12','','0','glpi (2)','2018-01-13 14:12:22','15','2018-01-13 14:11:00','2018-01-13 00:00');
INSERT INTO `glpi_logs` VALUES ('544','Ticket','12','','0','glpi (2)','2018-01-13 14:12:45','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('545','Ticket','12','','0','glpi (2)','2018-01-13 14:12:45','155','2018-01-13 15:11:00','NULL');
INSERT INTO `glpi_logs` VALUES ('546','Ticket','12','','0','glpi (2)','2018-01-13 14:13:00','155','','2018-01-13 01:00:00');
INSERT INTO `glpi_logs` VALUES ('547','Ticket','12','','0','glpi (2)','2018-01-13 14:13:00','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('548','Ticket','12','','0','glpi (2)','2018-01-13 14:13:00','12','2','1');
INSERT INTO `glpi_logs` VALUES ('549','SlaLevel','1','SlaLevelCriteria','17','glpi (2)','2018-01-13 14:16:29','0','','StatuséProcessando (atribuído) (4)');
INSERT INTO `glpi_logs` VALUES ('551','SlaLevel','1','','0','glpi (2)','2018-01-13 14:16:36','5','AND','OR');
INSERT INTO `glpi_logs` VALUES ('552','Ticket','13','User','15','glpi (2)','2018-01-13 14:17:11','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('553','Ticket','13','','0','glpi (2)','2018-01-13 14:17:11','150','0','71');
INSERT INTO `glpi_logs` VALUES ('554','Ticket','13','User','15','glpi (2)','2018-01-13 14:17:11','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('555','Ticket','13','0','20','glpi (2)','2018-01-13 14:17:11','0','','');
INSERT INTO `glpi_logs` VALUES ('556','Ticket','13','','0','glpi (2)','2018-01-13 14:17:22','12','2','1');
INSERT INTO `glpi_logs` VALUES ('557','Ticket','13','User','16','glpi (2)','2018-01-13 14:17:22','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('558','Ticket','13','','0','glpi (2)','2018-01-13 14:17:57','37','SLA 1hora Aceitar (1)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('559','Ticket','13','','0','glpi (2)','2018-01-13 14:17:57','155','2018-01-13 15:16:00','NULL');
INSERT INTO `glpi_logs` VALUES ('560','Ticket','13','','0','glpi (2)','2018-01-13 14:18:13','15','2018-01-13 14:16:00','2018-01-13 13:16');
INSERT INTO `glpi_logs` VALUES ('561','Ticket','13','','0','glpi (2)','2018-01-13 14:18:13','155','','2018-01-13 14:16:00');
INSERT INTO `glpi_logs` VALUES ('562','Ticket','13','','0','glpi (2)','2018-01-13 14:18:13','37','&nbsp; (0)','SLA 1hora Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('563','SlaLevel','1','SlaLevelCriteria','19','glpi (2)','2018-01-13 14:20:37','0','StatuséProcessando (atribuído) (4)','');
INSERT INTO `glpi_logs` VALUES ('564','SlaLevel','1','SlaLevelAction','19','glpi (2)','2018-01-13 14:20:55','0','StatusAtribuirProcessando (atribuído) (2)','');
INSERT INTO `glpi_logs` VALUES ('565','SlaLevel','1','SlaLevelAction','19','glpi (2)','2018-01-13 14:21:08','0','CategoriaAtribuirServicedesk (6)','');
INSERT INTO `glpi_logs` VALUES ('572','Ticket','8','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('573','Ticket','9','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('574','Ticket','10','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('575','Ticket','11','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('576','Ticket','12','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('577','Ticket','13','0','13','glpi (2)','2018-01-13 14:31:29','0','','');
INSERT INTO `glpi_logs` VALUES ('578','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:32:46','0','','N/A (6)');
INSERT INTO `glpi_logs` VALUES ('580','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:33:00','0','','N/A (7)');
INSERT INTO `glpi_logs` VALUES ('582','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (1)','');
INSERT INTO `glpi_logs` VALUES ('583','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (2)','');
INSERT INTO `glpi_logs` VALUES ('584','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (3)','');
INSERT INTO `glpi_logs` VALUES ('585','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (4)','');
INSERT INTO `glpi_logs` VALUES ('586','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (5)','');
INSERT INTO `glpi_logs` VALUES ('587','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (6)','');
INSERT INTO `glpi_logs` VALUES ('588','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:33:21','0','N/A (7)','');
INSERT INTO `glpi_logs` VALUES ('589','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:33:31','0','','N/A (8)');
INSERT INTO `glpi_logs` VALUES ('590','CalendarSegment','8','0','20','glpi (2)','2018-01-13 14:33:31','0','','');
INSERT INTO `glpi_logs` VALUES ('591','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:33:41','0','','N/A (9)');
INSERT INTO `glpi_logs` VALUES ('592','CalendarSegment','9','0','20','glpi (2)','2018-01-13 14:33:41','0','','');
INSERT INTO `glpi_logs` VALUES ('593','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:33:52','0','','N/A (10)');
INSERT INTO `glpi_logs` VALUES ('595','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:34:05','0','','N/A (11)');
INSERT INTO `glpi_logs` VALUES ('597','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:34:17','0','','N/A (12)');
INSERT INTO `glpi_logs` VALUES ('599','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:34:26','0','','N/A (13)');
INSERT INTO `glpi_logs` VALUES ('601','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:34:39','0','','N/A (14)');
INSERT INTO `glpi_logs` VALUES ('603','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:34:59','0','','N/A (15)');
INSERT INTO `glpi_logs` VALUES ('604','CalendarSegment','15','0','20','glpi (2)','2018-01-13 14:34:59','0','','');
INSERT INTO `glpi_logs` VALUES ('605','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:35:07','0','N/A (12)','');
INSERT INTO `glpi_logs` VALUES ('606','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:35:20','0','N/A (10)','');
INSERT INTO `glpi_logs` VALUES ('607','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:35:20','0','N/A (11)','');
INSERT INTO `glpi_logs` VALUES ('608','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:35:20','0','N/A (13)','');
INSERT INTO `glpi_logs` VALUES ('609','Calendar','1','CalendarSegment','19','glpi (2)','2018-01-13 14:35:20','0','N/A (14)','');
INSERT INTO `glpi_logs` VALUES ('610','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:35:37','0','','N/A (16)');
INSERT INTO `glpi_logs` VALUES ('611','CalendarSegment','16','0','20','glpi (2)','2018-01-13 14:35:37','0','','');
INSERT INTO `glpi_logs` VALUES ('612','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:35:46','0','','N/A (17)');
INSERT INTO `glpi_logs` VALUES ('613','CalendarSegment','17','0','20','glpi (2)','2018-01-13 14:35:46','0','','');
INSERT INTO `glpi_logs` VALUES ('614','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:35:57','0','','N/A (18)');
INSERT INTO `glpi_logs` VALUES ('615','CalendarSegment','18','0','20','glpi (2)','2018-01-13 14:35:57','0','','');
INSERT INTO `glpi_logs` VALUES ('616','Calendar','1','CalendarSegment','17','glpi (2)','2018-01-13 14:36:13','0','','N/A (19)');
INSERT INTO `glpi_logs` VALUES ('617','CalendarSegment','19','0','20','glpi (2)','2018-01-13 14:36:13','0','','');
INSERT INTO `glpi_logs` VALUES ('618','Ticket','14','User','15','glpi (2)','2018-01-13 14:37:44','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('619','Ticket','14','','0','glpi (2)','2018-01-13 14:37:44','150','0','2264');
INSERT INTO `glpi_logs` VALUES ('620','Ticket','14','User','15','glpi (2)','2018-01-13 14:37:44','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('621','Ticket','14','0','20','glpi (2)','2018-01-13 14:37:44','0','','');
INSERT INTO `glpi_logs` VALUES ('622','Ticket','14','','0','glpi (2)','2018-01-13 14:37:55','12','2','1');
INSERT INTO `glpi_logs` VALUES ('623','Ticket','14','User','16','glpi (2)','2018-01-13 14:37:55','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('624','Ticket','15','User','15','glpi (2)','2018-01-13 14:39:17','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('625','Ticket','15','','0','glpi (2)','2018-01-13 14:39:17','150','0','2297');
INSERT INTO `glpi_logs` VALUES ('626','Ticket','15','User','15','glpi (2)','2018-01-13 14:39:17','0','','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('627','Ticket','15','0','20','glpi (2)','2018-01-13 14:39:17','0','','');
INSERT INTO `glpi_logs` VALUES ('628','Ticket','15','','0','glpi (2)','2018-01-13 14:39:33','12','2','1');
INSERT INTO `glpi_logs` VALUES ('629','Ticket','15','User','16','glpi (2)','2018-01-13 14:39:33','0','glpi (2)','');
INSERT INTO `glpi_logs` VALUES ('630','Ticket','16','User','15','post-only (3)','2018-01-13 14:40:03','0','','post-only (3)');
INSERT INTO `glpi_logs` VALUES ('631','Ticket','16','0','20','post-only (3)','2018-01-13 14:40:03','0','','');
INSERT INTO `glpi_logs` VALUES ('632','SlaLevel','1','','0','glpi (2)','2018-01-13 14:42:22','5','OR','AND');
INSERT INTO `glpi_logs` VALUES ('633','SlaLevel','1','SlaLevelAction','17','glpi (2)','2018-01-13 14:43:03','0','','StatusAtribuirProcessando (atribuído) (7)');
INSERT INTO `glpi_logs` VALUES ('635','Ticket','17','User','15','post-only (3)','2018-01-13 14:44:20','0','','post-only (3)');
INSERT INTO `glpi_logs` VALUES ('636','Ticket','17','0','20','post-only (3)','2018-01-13 14:44:20','0','','');
INSERT INTO `glpi_logs` VALUES ('637','AuthLDAP','1','0','20','glpi (2)','2018-01-13 14:53:05','0','','');
INSERT INTO `glpi_logs` VALUES ('638','User','8','Profile','17','glpi (2)','2018-01-13 14:54:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('639','User','8','0','20','glpi (2)','2018-01-13 14:54:35','0','','');
INSERT INTO `glpi_logs` VALUES ('640','User','9','Profile','17','glpi (2)','2018-01-13 14:54:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('641','User','9','0','20','glpi (2)','2018-01-13 14:54:35','0','','');
INSERT INTO `glpi_logs` VALUES ('642','User','10','Profile','17','glpi (2)','2018-01-13 14:54:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('643','User','10','0','20','glpi (2)','2018-01-13 14:54:35','0','','');
INSERT INTO `glpi_logs` VALUES ('644','User','11','Profile','17','glpi (2)','2018-01-13 14:54:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('645','User','11','0','20','glpi (2)','2018-01-13 14:54:35','0','','');
INSERT INTO `glpi_logs` VALUES ('646','User','12','Profile','17','glpi (2)','2018-01-13 14:54:35','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('647','User','12','0','20','glpi (2)','2018-01-13 14:54:35','0','','');
INSERT INTO `glpi_logs` VALUES ('648','Ticket','18','User','15','Nolasco Alda (12)','2018-01-13 14:55:19','0','','Nolasco Alda (12)');
INSERT INTO `glpi_logs` VALUES ('649','Ticket','18','0','20','Nolasco Alda (12)','2018-01-13 14:55:19','0','','');
INSERT INTO `glpi_logs` VALUES ('650','SlaLevel','1','SlaLevelAction','19','glpi (2)','2018-01-13 15:00:41','0','StatusAtribuirProcessando (atribuído) (7)','');
INSERT INTO `glpi_logs` VALUES ('651','Ticket','17','','0','glpi (2)','2018-01-13 15:02:11','7','&nbsp; (0)','Servicedesk (3)');
INSERT INTO `glpi_logs` VALUES ('652','Ticket','17','','0','glpi (2)','2018-01-13 15:02:11','64','post-only (3)','glpi (2)');
INSERT INTO `glpi_logs` VALUES ('653','Ticket','16','','0','cron_slaticket','2018-01-13 15:02:37','150','0','1354');
INSERT INTO `glpi_logs` VALUES ('654','Ticket','16','Group','15','cron_slaticket','2018-01-13 15:02:37','0','','Servicedesk (1)');
INSERT INTO `glpi_logs` VALUES ('655','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng (864)','');
INSERT INTO `glpi_logs` VALUES ('656','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng (917)');
INSERT INTO `glpi_logs` VALUES ('657','ProfileRight','917','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('658','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_sync (872)','');
INSERT INTO `glpi_logs` VALUES ('659','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_sync (918)');
INSERT INTO `glpi_logs` VALUES ('660','ProfileRight','918','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('661','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_view (880)','');
INSERT INTO `glpi_logs` VALUES ('662','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_view (919)');
INSERT INTO `glpi_logs` VALUES ('663','ProfileRight','919','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('664','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_import (896)','');
INSERT INTO `glpi_logs` VALUES ('665','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_import (920)');
INSERT INTO `glpi_logs` VALUES ('666','ProfileRight','920','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('667','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_link (904)','');
INSERT INTO `glpi_logs` VALUES ('668','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_link (921)');
INSERT INTO `glpi_logs` VALUES ('669','ProfileRight','921','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('670','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_clean (888)','');
INSERT INTO `glpi_logs` VALUES ('671','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_clean (922)');
INSERT INTO `glpi_logs` VALUES ('672','ProfileRight','922','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('673','Profile','4','ProfileRight','19','glpi (2)','2018-01-17 00:09:15','0','plugin_ocsinventoryng_rule (912)','');
INSERT INTO `glpi_logs` VALUES ('674','Profile','4','ProfileRight','17','glpi (2)','2018-01-17 00:09:15','0','','plugin_ocsinventoryng_rule (923)');
INSERT INTO `glpi_logs` VALUES ('675','ProfileRight','923','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('676','CronTask','33','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('677','CronTask','34','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('678','CronTask','35','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('679','CronTask','36','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('680','CronTask','37','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('681','CronTask','38','0','20','glpi (2)','2018-01-17 00:09:15','0','','');
INSERT INTO `glpi_logs` VALUES ('682','PluginOcsinventoryngOcsServer','1','0','20','glpi (2)','2018-01-17 00:10:15','0','','');
INSERT INTO `glpi_logs` VALUES ('683','Computer','9','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('684','Computer','9','PluginOcsinventoryngOcslink','1008','glpi (2)','2018-01-17 00:11:27','0','','7');
INSERT INTO `glpi_logs` VALUES ('685','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','7','','root');
INSERT INTO `glpi_logs` VALUES ('686','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','16','x86_64/00-00-00 00:23:50
x86_64/00-00-00 00:23:50
 Trocar: 1021','x86_64/00-00-00 00:23:50
Trocar: 1021');
INSERT INTO `glpi_logs` VALUES ('687','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','47','','BC245795-8083-462C-A8E5-C82B1457EAB3');
INSERT INTO `glpi_logs` VALUES ('688','OperatingSystem','4','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('689','OperatingSystemVersion','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('690','OperatingSystemServicePack','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('691','ComputerModel','2','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('692','Manufacturer','8','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('693','ComputerType','3','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('694','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','40','&nbsp; (0)','VirtualBox (2)');
INSERT INTO `glpi_logs` VALUES ('695','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','23','&nbsp; (0)','innotek GmbH (8)');
INSERT INTO `glpi_logs` VALUES ('696','Computer','9','','0','glpi (2)','2018-01-17 00:11:27','4','&nbsp; (0)','Other (3)');
INSERT INTO `glpi_logs` VALUES ('697','DeviceFirmwareModel','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('698','DeviceFirmwareType','4','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('699','DeviceFirmware','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('700','Computer','9','DeviceFirmware','1','glpi (2)','2018-01-17 00:11:27','0','','VirtualBox (1)');
INSERT INTO `glpi_logs` VALUES ('701','DeviceProcessor','2','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('702','Computer','9','DeviceProcessor','1','glpi (2)','2018-01-17 00:11:27','0','','Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz (2)');
INSERT INTO `glpi_logs` VALUES ('703','DeviceGraphicCard','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('704','Computer','9','DeviceGraphicCard','1','glpi (2)','2018-01-17 00:11:27','0','','InnoTek Systemberatung GmbH VirtualBox Graphics Adapter (1)');
INSERT INTO `glpi_logs` VALUES ('705','Manufacturer','9','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('706','DeviceControl','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('707','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','Host bridge [0600] (1)');
INSERT INTO `glpi_logs` VALUES ('708','Manufacturer','10','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('709','DeviceControl','2','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('710','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','ISA bridge [0601] (2)');
INSERT INTO `glpi_logs` VALUES ('711','Manufacturer','11','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('712','DeviceControl','3','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('713','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','IDE interface [0101] (3)');
INSERT INTO `glpi_logs` VALUES ('714','Manufacturer','12','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('715','DeviceControl','4','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('716','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','VGA compatible controller [0300] (4)');
INSERT INTO `glpi_logs` VALUES ('717','Manufacturer','13','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('718','DeviceControl','5','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('719','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','Ethernet controller [0200] (5)');
INSERT INTO `glpi_logs` VALUES ('720','Manufacturer','14','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('721','DeviceControl','6','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('722','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','System peripheral [0880] (6)');
INSERT INTO `glpi_logs` VALUES ('723','Manufacturer','15','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('724','DeviceControl','7','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('725','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','Multimedia audio controller [0401] (7)');
INSERT INTO `glpi_logs` VALUES ('726','Manufacturer','16','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('727','DeviceControl','8','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('728','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','USB controller [0c03] (8)');
INSERT INTO `glpi_logs` VALUES ('729','Manufacturer','17','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('730','DeviceControl','9','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('731','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','Bridge [0680] (9)');
INSERT INTO `glpi_logs` VALUES ('732','Manufacturer','18','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('733','DeviceControl','10','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('734','Computer','9','DeviceControl','1','glpi (2)','2018-01-17 00:11:27','0','','SATA controller [0106] (10)');
INSERT INTO `glpi_logs` VALUES ('735','DeviceSoundCard','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('736','Computer','9','DeviceSoundCard','1','glpi (2)','2018-01-17 00:11:27','0','','Multimedia audio controller (1)');
INSERT INTO `glpi_logs` VALUES ('737','Computer','9','DeviceSoundCard','1','glpi (2)','2018-01-17 00:11:27','0','','Multimedia audio controller (1)');
INSERT INTO `glpi_logs` VALUES ('738','DeviceNetworkCard','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('739','Computer','9','DeviceNetworkCard','1','glpi (2)','2018-01-17 00:11:27','0','','eth0 (1)');
INSERT INTO `glpi_logs` VALUES ('740','NetworkPort','27','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('741','NetworkPort','27','NetworkName','17','glpi (2)','2018-01-17 00:11:27','0','','ocs-inventory-ng (4)');
INSERT INTO `glpi_logs` VALUES ('742','NetworkName','4','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('743','IPNetwork','2','IPAddress','15','glpi (2)','2018-01-17 00:11:27','0','','192.168.25.8 (4)');
INSERT INTO `glpi_logs` VALUES ('744','NetworkName','4','IPAddress','17','glpi (2)','2018-01-17 00:11:27','0','','192.168.25.8 (4)');
INSERT INTO `glpi_logs` VALUES ('745','NetworkName','4','IPAddress','17','glpi (2)','2018-01-17 00:11:27','0','','fe80::a00:27ff:fe97:300f (5)');
INSERT INTO `glpi_logs` VALUES ('746','Computer','9','ComputerDisk','17','glpi (2)','2018-01-17 00:11:27','0','','/ (1)');
INSERT INTO `glpi_logs` VALUES ('747','ComputerDisk','1','0','20','glpi (2)','2018-01-17 00:11:27','0','','');
INSERT INTO `glpi_logs` VALUES ('748','Computer','10','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('749','Computer','10','PluginOcsinventoryngOcslink','1008','glpi (2)','2018-01-17 00:11:29','0','','6');
INSERT INTO `glpi_logs` VALUES ('750','Domain','1','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('751','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','33','&nbsp; (0)','WORKGROUP (1)');
INSERT INTO `glpi_logs` VALUES ('752','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','16','','Trocar: 4089');
INSERT INTO `glpi_logs` VALUES ('753','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','47','','014C18CD-DAE1-464E-BC44-88C444F48E07');
INSERT INTO `glpi_logs` VALUES ('754','OperatingSystem','5','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('755','OperatingSystemVersion','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('756','OperatingSystemArchitecture','1','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('757','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','40','&nbsp; (0)','VirtualBox (2)');
INSERT INTO `glpi_logs` VALUES ('758','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','23','&nbsp; (0)','innotek GmbH (8)');
INSERT INTO `glpi_logs` VALUES ('759','Computer','10','','0','glpi (2)','2018-01-17 00:11:29','4','&nbsp; (0)','Other (3)');
INSERT INTO `glpi_logs` VALUES ('760','Computer','10','DeviceFirmware','1','glpi (2)','2018-01-17 00:11:29','0','','VirtualBox (1)');
INSERT INTO `glpi_logs` VALUES ('761','DeviceHardDrive','1','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('762','Computer','10','DeviceHardDrive','1','glpi (2)','2018-01-17 00:11:29','0','','VBOX HARDDISK (1)');
INSERT INTO `glpi_logs` VALUES ('763','DeviceDrive','1','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('764','Computer','10','DeviceDrive','1','glpi (2)','2018-01-17 00:11:29','0','','VBOX CD-ROM (1)');
INSERT INTO `glpi_logs` VALUES ('765','Manufacturer','19','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('766','DeviceProcessor','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('767','Computer','10','DeviceProcessor','1','glpi (2)','2018-01-17 00:11:29','0','','Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz (3)');
INSERT INTO `glpi_logs` VALUES ('768','DeviceGraphicCard','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('769','Computer','10','DeviceGraphicCard','1','glpi (2)','2018-01-17 00:11:29','0','','VirtualBox Graphics Adapter for Windows 8 (2)');
INSERT INTO `glpi_logs` VALUES ('770','Manufacturer','20','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('771','DeviceControl','11','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('772','Computer','10','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Standard SATA AHCI Controller (11)');
INSERT INTO `glpi_logs` VALUES ('773','Manufacturer','21','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('774','DeviceControl','12','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('775','Computer','10','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Microsoft Storage Spaces Controller (12)');
INSERT INTO `glpi_logs` VALUES ('776','Manufacturer','22','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('777','DeviceControl','13','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('778','Computer','10','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Standard OpenHCD USB Host Controller (13)');
INSERT INTO `glpi_logs` VALUES ('779','DeviceSoundCard','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('780','Computer','10','DeviceSoundCard','1','glpi (2)','2018-01-17 00:11:29','0','','Dispositivo de High Definition Audio (2)');
INSERT INTO `glpi_logs` VALUES ('781','DeviceNetworkCard','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('782','Computer','10','DeviceNetworkCard','1','glpi (2)','2018-01-17 00:11:29','0','','Intel(R) PRO/1000 MT Desktop Adapter (2)');
INSERT INTO `glpi_logs` VALUES ('783','NetworkPort','28','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('784','NetworkPort','28','NetworkName','17','glpi (2)','2018-01-17 00:11:29','0','','ocs-inventory-ng (5)');
INSERT INTO `glpi_logs` VALUES ('785','NetworkName','5','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('786','IPNetwork','2','IPAddress','15','glpi (2)','2018-01-17 00:11:29','0','','192.168.25.53 (6)');
INSERT INTO `glpi_logs` VALUES ('787','NetworkName','5','IPAddress','17','glpi (2)','2018-01-17 00:11:29','0','','192.168.25.53 (6)');
INSERT INTO `glpi_logs` VALUES ('788','Computer','10','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','C: (2)');
INSERT INTO `glpi_logs` VALUES ('789','ComputerDisk','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('790','Computer','11','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('791','Computer','11','PluginOcsinventoryngOcslink','1008','glpi (2)','2018-01-17 00:11:29','0','','5');
INSERT INTO `glpi_logs` VALUES ('792','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','7','','root');
INSERT INTO `glpi_logs` VALUES ('793','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','16','x86_64/00-00-00 00:09:37
x86_64/00-00-00 00:09:37
 Trocar: 819','x86_64/00-00-00 00:09:37
Trocar: 819');
INSERT INTO `glpi_logs` VALUES ('794','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','47','','B5024166-731C-4D79-8BD5-A7C6675EB681');
INSERT INTO `glpi_logs` VALUES ('795','OperatingSystem','6','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('796','OperatingSystemVersion','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('797','OperatingSystemServicePack','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('798','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','40','&nbsp; (0)','VirtualBox (2)');
INSERT INTO `glpi_logs` VALUES ('799','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','23','&nbsp; (0)','innotek GmbH (8)');
INSERT INTO `glpi_logs` VALUES ('800','Computer','11','','0','glpi (2)','2018-01-17 00:11:29','4','&nbsp; (0)','Other (3)');
INSERT INTO `glpi_logs` VALUES ('801','Computer','11','DeviceFirmware','1','glpi (2)','2018-01-17 00:11:29','0','','VirtualBox (1)');
INSERT INTO `glpi_logs` VALUES ('802','Computer','11','DeviceProcessor','1','glpi (2)','2018-01-17 00:11:29','0','','Intel(R) Core(TM) i7-2630QM CPU @ 2.00GHz (2)');
INSERT INTO `glpi_logs` VALUES ('803','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Host bridge [0600] (1)');
INSERT INTO `glpi_logs` VALUES ('804','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','ISA bridge [0601] (2)');
INSERT INTO `glpi_logs` VALUES ('805','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','IDE interface [0101] (3)');
INSERT INTO `glpi_logs` VALUES ('806','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','VGA compatible controller [0300] (4)');
INSERT INTO `glpi_logs` VALUES ('807','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Ethernet controller [0200] (5)');
INSERT INTO `glpi_logs` VALUES ('808','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','System peripheral [0880] (6)');
INSERT INTO `glpi_logs` VALUES ('809','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Multimedia audio controller [0401] (7)');
INSERT INTO `glpi_logs` VALUES ('810','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','USB controller [0c03] (8)');
INSERT INTO `glpi_logs` VALUES ('811','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','Bridge [0680] (9)');
INSERT INTO `glpi_logs` VALUES ('812','Manufacturer','23','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('813','DeviceControl','14','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('814','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','USB controller [0c03] (14)');
INSERT INTO `glpi_logs` VALUES ('815','Computer','11','DeviceControl','1','glpi (2)','2018-01-17 00:11:29','0','','SATA controller [0106] (10)');
INSERT INTO `glpi_logs` VALUES ('816','Computer','11','DeviceSoundCard','1','glpi (2)','2018-01-17 00:11:29','0','','Multimedia audio controller (1)');
INSERT INTO `glpi_logs` VALUES ('817','Computer','11','DeviceSoundCard','1','glpi (2)','2018-01-17 00:11:29','0','','Multimedia audio controller (1)');
INSERT INTO `glpi_logs` VALUES ('818','Computer','11','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/ (3)');
INSERT INTO `glpi_logs` VALUES ('819','ComputerDisk','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('820','Computer','11','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/boot (4)');
INSERT INTO `glpi_logs` VALUES ('821','ComputerDisk','4','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('822','Computer','12','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('823','Computer','12','PluginOcsinventoryngOcslink','1008','glpi (2)','2018-01-17 00:11:29','0','','8');
INSERT INTO `glpi_logs` VALUES ('824','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','33','&nbsp; (0)','WORKGROUP (1)');
INSERT INTO `glpi_logs` VALUES ('825','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','7','','dpi');
INSERT INTO `glpi_logs` VALUES ('826','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','16','','Trocar: 1023');
INSERT INTO `glpi_logs` VALUES ('827','OperatingSystem','7','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('828','OperatingSystemVersion','4','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('829','OperatingSystemServicePack','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('830','ComputerModel','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('831','Manufacturer','24','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('832','ComputerType','4','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('833','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','40','&nbsp; (0)','SM-N9005 (3)');
INSERT INTO `glpi_logs` VALUES ('834','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','23','&nbsp; (0)','samsung (24)');
INSERT INTO `glpi_logs` VALUES ('835','Computer','12','','0','glpi (2)','2018-01-17 00:11:29','4','&nbsp; (0)','Mobile (4)');
INSERT INTO `glpi_logs` VALUES ('836','DeviceFirmwareModel','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('837','DeviceFirmwareType','5','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('838','DeviceFirmware','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('839','Computer','12','DeviceFirmware','1','glpi (2)','2018-01-17 00:11:29','0','','N9005VJUGBPB1 (2)');
INSERT INTO `glpi_logs` VALUES ('840','DeviceDrive','2','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('841','Computer','12','DeviceDrive','1','glpi (2)','2018-01-17 00:11:29','0','','Unknown (2)');
INSERT INTO `glpi_logs` VALUES ('842','Computer','12','DeviceDrive','1','glpi (2)','2018-01-17 00:11:29','0','','Unknown (2)');
INSERT INTO `glpi_logs` VALUES ('843','DeviceGraphicCard','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('844','Computer','12','DeviceGraphicCard','1','glpi (2)','2018-01-17 00:11:29','0','','Embedded display (3)');
INSERT INTO `glpi_logs` VALUES ('845','DeviceNetworkCard','3','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('846','Computer','12','DeviceNetworkCard','1','glpi (2)','2018-01-17 00:11:29','0','','Wifi/3G interface (3)');
INSERT INTO `glpi_logs` VALUES ('847','NetworkPort','29','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('848','NetworkPort','29','NetworkName','17','glpi (2)','2018-01-17 00:11:29','0','','ocs-inventory-ng (6)');
INSERT INTO `glpi_logs` VALUES ('849','NetworkName','6','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('850','IPNetwork','2','IPAddress','15','glpi (2)','2018-01-17 00:11:29','0','','192.168.25.5 (7)');
INSERT INTO `glpi_logs` VALUES ('851','NetworkName','6','IPAddress','17','glpi (2)','2018-01-17 00:11:29','0','','192.168.25.5 (7)');
INSERT INTO `glpi_logs` VALUES ('852','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/system (5)');
INSERT INTO `glpi_logs` VALUES ('853','ComputerDisk','5','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('854','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/data (6)');
INSERT INTO `glpi_logs` VALUES ('855','ComputerDisk','6','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('856','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/cache (7)');
INSERT INTO `glpi_logs` VALUES ('857','ComputerDisk','7','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('858','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/persist (8)');
INSERT INTO `glpi_logs` VALUES ('859','ComputerDisk','8','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('860','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/efs (9)');
INSERT INTO `glpi_logs` VALUES ('861','ComputerDisk','9','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('862','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/persdata/absolute (10)');
INSERT INTO `glpi_logs` VALUES ('863','ComputerDisk','10','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('864','Computer','12','ComputerDisk','17','glpi (2)','2018-01-17 00:11:29','0','','/preload (11)');
INSERT INTO `glpi_logs` VALUES ('865','ComputerDisk','11','0','20','glpi (2)','2018-01-17 00:11:29','0','','');
INSERT INTO `glpi_logs` VALUES ('866','Ticket','7','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('867','Ticket','7','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('868','Ticket','7','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('869','Ticket','7','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('870','Ticket','7','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('871','Ticket','17','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('872','Ticket','17','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('873','Ticket','17','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('874','Ticket','17','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('875','Ticket','17','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('876','Ticket','14','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('877','Ticket','14','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('878','Ticket','14','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('879','Ticket','14','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('880','Ticket','14','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('881','Ticket','15','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('882','Ticket','15','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('883','Ticket','15','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('884','Ticket','15','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('885','Ticket','15','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('886','Ticket','16','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('887','Ticket','16','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('888','Ticket','16','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('889','Ticket','16','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('890','Ticket','16','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('891','Ticket','18','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('892','Ticket','18','','0','cron_slaticket','2018-01-18 21:21:59','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('893','Ticket','18','','0','cron_slaticket','2018-01-18 21:21:59','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('894','Ticket','18','','0','cron_slaticket','2018-01-18 21:21:59','180','','2018-01-19 09:22:00');
INSERT INTO `glpi_logs` VALUES ('895','Ticket','18','','0','cron_slaticket','2018-01-18 21:21:59','185','','2018-01-18 21:52:00');
INSERT INTO `glpi_logs` VALUES ('896','Ticket','18','Group','15','cron_slaticket','2018-01-18 21:21:59','0','','Servicedesk (1)');
INSERT INTO `glpi_logs` VALUES ('897','CronTask','39','0','20','glpi (2)','2018-01-18 21:45:28','0','','');
INSERT INTO `glpi_logs` VALUES ('898','NotificationTemplate','28','0','20','glpi (2)','2018-01-18 21:50:38','0','','');
INSERT INTO `glpi_logs` VALUES ('899','NotificationTemplate','28','NotificationTemplateTranslation','17','glpi (2)','2018-01-18 21:51:43','0','','Tradução de modelo (28)');
INSERT INTO `glpi_logs` VALUES ('900','NotificationTemplateTranslation','28','0','20','glpi (2)','2018-01-18 21:51:43','0','','');
INSERT INTO `glpi_logs` VALUES ('901','Notification','70','0','20','glpi (2)','2018-01-18 21:52:30','0','','');
INSERT INTO `glpi_logs` VALUES ('902','Notification','70','Notification_NotificationTemplate','17','glpi (2)','2018-01-18 21:52:50','0','','70 (70)');
INSERT INTO `glpi_logs` VALUES ('903','Notification','70','NotificationTargetTicket','17','glpi (2)','2018-01-18 21:53:22','0','','Administrador (132)');
INSERT INTO `glpi_logs` VALUES ('904','NotificationTargetTicket','132','0','20','glpi (2)','2018-01-18 21:53:22','0','','');
INSERT INTO `glpi_logs` VALUES ('905','Notification','70','NotificationTargetTicket','17','glpi (2)','2018-01-18 21:53:22','0','','Requerente (133)');
INSERT INTO `glpi_logs` VALUES ('906','NotificationTargetTicket','133','0','20','glpi (2)','2018-01-18 21:53:22','0','','');
INSERT INTO `glpi_logs` VALUES ('907','Ticket','19','User','15','Fraga Eduardo (6)','2018-01-18 21:54:03','0','','Fraga Eduardo (6)');
INSERT INTO `glpi_logs` VALUES ('908','Ticket','19','0','20','Fraga Eduardo (6)','2018-01-18 21:54:03','0','','');
INSERT INTO `glpi_logs` VALUES ('909','Ticket','7','','0','glpi (2)','2018-03-20 07:51:23','24','','&lt;p&gt;reiniciado o computador&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('910','Ticket','7','','0','glpi (2)','2018-03-20 07:51:23','12','1','6');
INSERT INTO `glpi_logs` VALUES ('911','Ticket','7','','0','glpi (2)','2018-03-20 07:51:23','16','','2018-03-20 07:51:23');
INSERT INTO `glpi_logs` VALUES ('912','Ticket','7','','0','glpi (2)','2018-03-20 07:51:23','17','','2018-03-20 07:51:23');
INSERT INTO `glpi_logs` VALUES ('913','Ticket','7','','0','glpi (2)','2018-03-20 07:52:00','12','6','4');
INSERT INTO `glpi_logs` VALUES ('914','Ticket','7','','0','glpi (2)','2018-03-20 07:52:00','17','2018-03-20 07:51:23','NULL');
INSERT INTO `glpi_logs` VALUES ('915','Ticket','7','','0','glpi (2)','2018-03-20 07:52:00','16','2018-03-20 07:51:23','NULL');
INSERT INTO `glpi_logs` VALUES ('916','Ticket','7','TicketFollowup','17','glpi (2)','2018-03-20 07:52:00','0','','11');
INSERT INTO `glpi_logs` VALUES ('917','MailCollector','1','','0','cron_mailgate','2018-05-14 19:08:25','22','0','1');
INSERT INTO `glpi_logs` VALUES ('918','Ticket','19','','0','cron_slaticket','2018-05-21 07:59:31','150','0','10577128');
INSERT INTO `glpi_logs` VALUES ('919','Ticket','19','Group','15','cron_slaticket','2018-05-21 07:59:31','0','','Servicedesk (1)');
INSERT INTO `glpi_logs` VALUES ('920','Ticket','19','Group','15','cron_slaticket','2018-05-21 07:59:31','0','','Redes (2)');
INSERT INTO `glpi_logs` VALUES ('921','Ticket','19','','0','cron_slaticket','2018-05-21 07:59:31','190','&nbsp; (0)','OLA 30min Aceitar (1)');
INSERT INTO `glpi_logs` VALUES ('922','Ticket','19','','0','cron_slaticket','2018-05-21 07:59:31','191','&nbsp; (0)','OLA 12h Solução (2)');
INSERT INTO `glpi_logs` VALUES ('923','Ticket','19','','0','cron_slaticket','2018-05-21 07:59:31','180','','2018-05-21 19:59:31');
INSERT INTO `glpi_logs` VALUES ('924','Ticket','19','','0','cron_slaticket','2018-05-21 07:59:31','185','','2018-05-21 08:29:31');
INSERT INTO `glpi_logs` VALUES ('925','BudgetType','1','0','20','glpi (2)','2018-05-21 14:22:05','0','','');
INSERT INTO `glpi_logs` VALUES ('926','BudgetType','2','0','20','glpi (2)','2018-05-21 14:22:16','0','','');
INSERT INTO `glpi_logs` VALUES ('928','Budget','2','0','20','glpi (2)','2018-05-21 14:44:26','0','','');
INSERT INTO `glpi_logs` VALUES ('929','Budget','3','0','20','glpi (2)','2018-05-21 14:47:38','0','','');
INSERT INTO `glpi_logs` VALUES ('930','DocumentType','73','0','20','glpi (2)','2018-05-21 15:29:11','0','','');
INSERT INTO `glpi_logs` VALUES ('931','DocumentCategory','1','0','20','glpi (2)','2018-05-21 15:46:28','0','','');
INSERT INTO `glpi_logs` VALUES ('932','DocumentCategory','2','0','20','glpi (2)','2018-05-21 15:46:41','0','','');
INSERT INTO `glpi_logs` VALUES ('933','Document','1','0','20','glpi (2)','2018-05-21 16:05:17','0','','');
INSERT INTO `glpi_logs` VALUES ('934','DocumentCategory','3','0','20','glpi (2)','2018-05-21 16:07:39','0','','');
INSERT INTO `glpi_logs` VALUES ('935','Document','2','0','20','glpi (2)','2018-05-21 16:08:16','0','','');
INSERT INTO `glpi_logs` VALUES ('936','Document','2','','0','glpi (2)','2018-05-21 16:09:11','4','ftp://10.0.0.150/PFSense/Como%20Instalar%20Fisicamente%20PFSense%20Firewall.docx','ftp\\://10.0.0.150/PFSense/Como%20Instalar%20Fisicamente%20PFSense%20Firewall.docx');
INSERT INTO `glpi_logs` VALUES ('937','Document','2','','0','glpi (2)','2018-05-21 16:09:35','4','ftp\\://10.0.0.150/PFSense/Como%20Instalar%20Fisicamente%20PFSense%20Firewall.docx','ftp://10.0.0.150/PFSense/Como%20Instalar%20Fisicamente%20PFSense%20Firewall.docx');
INSERT INTO `glpi_logs` VALUES ('938','Document','2','0','13','glpi (2)','2018-05-21 16:10:33','0','','');
INSERT INTO `glpi_logs` VALUES ('939','MailCollector','1','','0','cron_mailgate','2018-05-21 16:19:37','22','1','2');
INSERT INTO `glpi_logs` VALUES ('940','MailCollector','1','','0','cron_mailgate','2018-05-21 22:09:39','22','2','3');
INSERT INTO `glpi_logs` VALUES ('941','Group','4','0','20','glpi (2)','2018-07-09 22:05:43','0','','');
INSERT INTO `glpi_logs` VALUES ('942','MailCollector','1','','0','cron_mailgate','2018-07-09 23:09:55','22','3','4');
INSERT INTO `glpi_logs` VALUES ('943','RuleRight','14','0','20','glpi (2)','2018-07-29 08:28:20','0','','');
INSERT INTO `glpi_logs` VALUES ('944','CronTask','40','0','20','glpi (2)','2018-08-13 18:39:19','0','','');
INSERT INTO `glpi_logs` VALUES ('945','CronTask','30','','0','glpi (2)','2018-08-13 18:39:19','7','2018-05-21 14:25:00',NULL);

### Dump table glpi_mailcollectors

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refused` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_kerberos` tinyint(1) NOT NULL DEFAULT '0',
  `errors` int(11) NOT NULL DEFAULT '0',
  `use_mail_date` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_mailcollectors` VALUES ('1','chamados@eftech.com.br','{imap.gmail.com:993/imap/ssl}','chamados@eftech.com.br','2097152','1','2018-07-09 23:09:55','','Iai9gXc6FuBZ','','','0','4','0','2018-01-11 18:34:35');

### Dump table glpi_manufacturers

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_manufacturers` VALUES ('1','Dell','','2017-11-29 10:06:30','2017-11-29 10:06:30');
INSERT INTO `glpi_manufacturers` VALUES ('2','Intel','','2017-11-30 10:31:35','2017-11-30 10:31:35');
INSERT INTO `glpi_manufacturers` VALUES ('4','libreoffice.org','','2017-12-03 14:16:22','2017-12-03 14:16:22');
INSERT INTO `glpi_manufacturers` VALUES ('5','Mozilla Foundation','','2017-12-03 14:21:16','2017-12-03 14:21:16');
INSERT INTO `glpi_manufacturers` VALUES ('6','HP','','2017-12-06 10:18:40','2017-12-06 10:18:40');
INSERT INTO `glpi_manufacturers` VALUES ('7','Kyoceara','','2017-12-07 10:17:40','2017-12-07 10:17:40');
INSERT INTO `glpi_manufacturers` VALUES ('8','innotek GmbH','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('9','Intel Corporation 440FX - 82441FX PMC [Natoma]','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('10','Intel Corporation 82371SB PIIX3 ISA [Natoma/Triton II]','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('11','Intel Corporation 82371AB/EB/MB PIIX4 IDE [8086:7111] (prog-if 8a [Master SecP PriP])','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('12','InnoTek Systemberatung GmbH VirtualBox Graphics Adapter','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('13','Intel Corporation 82540EM Gigabit Ethernet Controller','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('14','InnoTek Systemberatung GmbH VirtualBox Guest Service','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('15','Intel Corporation 82801AA AC\'97 Audio Controller','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('16','Apple Inc. KeyLargo/Intrepid USB','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('17','Intel Corporation 82371AB/EB/MB PIIX4 ACPI','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('18','Intel Corporation 82801HM/HEM (ICH8M/ICH8M-E) SATA Controller [AHCI mode]','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_manufacturers` VALUES ('19','GenuineIntel','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_manufacturers` VALUES ('20','Standard SATA AHCI Controller','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_manufacturers` VALUES ('21','Microsoft','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_manufacturers` VALUES ('22','(Standard USB Host Controller)','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_manufacturers` VALUES ('23','Intel Corporation 82801FB/FBM/FR/FW/FRW (ICH6 Family) USB2 EHCI Controller','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_manufacturers` VALUES ('24','samsung','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_monitormodels

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `power_consumption` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_monitormodels` VALUES ('1','L21','','22221','0','1','1','0','0','0',NULL,NULL,'2017-12-01 10:10:08','2017-12-01 10:10:08');

### Dump table glpi_monitors

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` decimal(5,2) NOT NULL DEFAULT '0.00',
  `have_micro` tinyint(1) NOT NULL DEFAULT '0',
  `have_speaker` tinyint(1) NOT NULL DEFAULT '0',
  `have_subd` tinyint(1) NOT NULL DEFAULT '0',
  `have_bnc` tinyint(1) NOT NULL DEFAULT '0',
  `have_dvi` tinyint(1) NOT NULL DEFAULT '0',
  `have_pivot` tinyint(1) NOT NULL DEFAULT '0',
  `have_hdmi` tinyint(1) NOT NULL DEFAULT '0',
  `have_displayport` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `monitortypes_id` int(11) NOT NULL DEFAULT '0',
  `monitormodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `monitormodels_id` (`monitormodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `monitortypes_id` (`monitortypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_monitors` VALUES ('1','0','&lt;MON-\\Y-###&gt;','2017-12-01 10:10:42','','','4','0','','','&lt;MON-\\Y-###&gt;','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','1','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:10:42','0');
INSERT INTO `glpi_monitors` VALUES ('2','0','MON-2017-001','2017-12-01 10:11:11','','','4','0','','1234','MON-2017-001','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:11','0');
INSERT INTO `glpi_monitors` VALUES ('3','0','MON-2017-002','2017-12-01 10:11:17','','','4','0','','2345','MON-2017-002','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:17','0');
INSERT INTO `glpi_monitors` VALUES ('4','0','MON-2017-003','2017-12-01 10:11:24','','','4','0','','3456','MON-2017-003','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:24','0');
INSERT INTO `glpi_monitors` VALUES ('5','0','MON-2017-004','2017-12-01 10:11:33','','','4','0','','4567','MON-2017-004','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:33','0');
INSERT INTO `glpi_monitors` VALUES ('6','0','MON-2017-005','2017-12-01 10:11:39','','','4','0','','9876','MON-2017-005','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:39','0');
INSERT INTO `glpi_monitors` VALUES ('7','0','MON-2017-006','2017-12-01 10:11:45','','','4','0','','6543','MON-2017-006','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:45','0');
INSERT INTO `glpi_monitors` VALUES ('8','0','MON-2017-007','2017-12-01 10:11:51','','','4','0','','4321','MON-2017-007','21.00','0','0','0','0','0','1','1','0','1','1','1','1','0','0','0','Monitor Exemplo','0','0','1','0.0000','0','2017-12-01 10:11:51','0');
INSERT INTO `glpi_monitors` VALUES ('9','0','KVM01','2017-12-01 10:14:15','','','4','0','','','2222','14.00','0','0','0','0','0','0','0','0','1','1','1','1','1','0','0',NULL,'0','0','1','0.0000','0','2017-12-01 10:14:15','0');

### Dump table glpi_monitortypes

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_monitortypes` VALUES ('1','LCD','','2017-12-01 10:09:39','2017-12-01 10:09:39');

### Dump table glpi_netpoints

DROP TABLE IF EXISTS `glpi_netpoints`;
CREATE TABLE `glpi_netpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `complete` (`entities_id`,`locations_id`,`name`),
  KEY `location_name` (`locations_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_netpoints` VALUES ('1','0','1','path-6-1-10','','2017-12-06 10:35:33','2017-12-06 10:35:33');
INSERT INTO `glpi_netpoints` VALUES ('2','0','0','path-10-1-6','','2017-12-06 10:36:42','2017-12-06 10:36:42');
INSERT INTO `glpi_netpoints` VALUES ('3','0','1','path-10-1-6','','2017-12-06 10:37:05','2017-12-06 10:37:05');
INSERT INTO `glpi_netpoints` VALUES ('4','0','1','path-6-1-11','','2017-12-07 10:19:42','2017-12-07 10:19:42');

### Dump table glpi_networkaliases

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `networknames_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `networknames_id` (`networknames_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentmodels

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `power_consumption` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkequipmentmodels` VALUES ('1','HP-5500','','5501','0','1','1','0','0','0',NULL,NULL,'2017-12-06 10:26:40','2017-12-06 10:26:40');

### Dump table glpi_networkequipments

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmenttypes_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentmodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkequipments` VALUES ('1','0','0','&lt;SWT-###&gt;','256','','&lt;SWT-###&gt;','','','4','0','2017-12-06 10:26:57','','1','0','0','1','1','6','0','1','Switch HP 5500','0','0','1','0.0000','0','2017-12-06 10:26:57');
INSERT INTO `glpi_networkequipments` VALUES ('2','0','0','SWT-001','256','3456','SWT-001','','','4','0','2017-12-06 10:27:17','','1','0','0','1','1','6','0','0','Switch HP 5500','0','0','1','0.0000','0','2017-12-06 10:27:17');

### Dump table glpi_networkequipmenttypes

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkequipmenttypes` VALUES ('1','Switch','','2017-12-06 10:26:09','2017-12-06 10:26:09');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('2','Router','','2017-12-06 10:26:15','2017-12-06 10:26:15');

### Dump table glpi_networkinterfaces

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networknames

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `FQDN` (`name`,`fqdns_id`),
  KEY `name` (`name`),
  KEY `fqdns_id` (`fqdns_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networknames` VALUES ('1','0','26','NetworkPort','imp-1andar',NULL,'0','0','0','2017-12-07 10:24:00','2017-12-07 10:24:00');
INSERT INTO `glpi_networknames` VALUES ('2','0','0','','1andar','','0','0','0','2017-12-07 10:38:38','2017-12-07 10:31:27');
INSERT INTO `glpi_networknames` VALUES ('3','0','2','NetworkPort','vlaninterface1','','0','0','0','2017-12-07 10:38:59','2017-12-07 10:32:37');
INSERT INTO `glpi_networknames` VALUES ('4','0','27','NetworkPort','ocs-inventory-ng',NULL,'0','0','1','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_networknames` VALUES ('5','0','28','NetworkPort','ocs-inventory-ng',NULL,'0','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_networknames` VALUES ('6','0','29','NetworkPort','ocs-inventory-ng',NULL,'0','0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_networkportaggregates

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_list` text COLLATE utf8_unicode_ci COMMENT 'array of associated networkports_id',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaliases

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_alias` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `networkports_id_alias` (`networkports_id_alias`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportdialups

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportethernets

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `type` (`type`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkportethernets` VALUES ('1','1','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('2','2','0','1','','1000','2017-12-06 10:35:42','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('3','3','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('4','4','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('5','5','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('6','6','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('7','7','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('8','8','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('9','9','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('10','10','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('11','11','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('12','12','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('13','13','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('14','14','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('15','15','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('16','16','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('17','17','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('18','18','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('19','19','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('20','20','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('21','21','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('22','22','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('23','23','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('24','24','0','0','','1000','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkportethernets` VALUES ('25','25','0','3','T','0','2017-12-06 10:37:19','2017-12-06 10:30:23');
INSERT INTO `glpi_networkportethernets` VALUES ('26','26','0','4','T','100','2017-12-07 10:24:15','2017-12-07 10:19:54');

### Dump table glpi_networkportfiberchannels

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `wwn` varchar(16) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `wwn` (`wwn`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportlocals

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `on_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `mac` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkports` VALUES ('1','2','NetworkEquipment','0','0','1','GigabitEthernet-01','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('2','2','NetworkEquipment','0','0','2','GigabitEthernet-02','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('3','2','NetworkEquipment','0','0','3','GigabitEthernet-03','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('4','2','NetworkEquipment','0','0','4','GigabitEthernet-04','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('5','2','NetworkEquipment','0','0','5','GigabitEthernet-05','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('6','2','NetworkEquipment','0','0','6','GigabitEthernet-06','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('7','2','NetworkEquipment','0','0','7','GigabitEthernet-07','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('8','2','NetworkEquipment','0','0','8','GigabitEthernet-08','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('9','2','NetworkEquipment','0','0','9','GigabitEthernet-09','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('10','2','NetworkEquipment','0','0','10','GigabitEthernet-10','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('11','2','NetworkEquipment','0','0','11','GigabitEthernet-11','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('12','2','NetworkEquipment','0','0','12','GigabitEthernet-12','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('13','2','NetworkEquipment','0','0','13','GigabitEthernet-13','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('14','2','NetworkEquipment','0','0','14','GigabitEthernet-14','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('15','2','NetworkEquipment','0','0','15','GigabitEthernet-15','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('16','2','NetworkEquipment','0','0','16','GigabitEthernet-16','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('17','2','NetworkEquipment','0','0','17','GigabitEthernet-17','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('18','2','NetworkEquipment','0','0','18','GigabitEthernet-18','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('19','2','NetworkEquipment','0','0','19','GigabitEthernet-19','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('20','2','NetworkEquipment','0','0','20','GigabitEthernet-20','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('21','2','NetworkEquipment','0','0','21','GigabitEthernet-21','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('22','2','NetworkEquipment','0','0','22','GigabitEthernet-22','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('23','2','NetworkEquipment','0','0','23','GigabitEthernet-23','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('24','2','NetworkEquipment','0','0','24','GigabitEthernet-24','NetworkPortEthernet','','','0','0','2017-12-06 10:28:32','2017-12-06 10:28:32');
INSERT INTO `glpi_networkports` VALUES ('25','2','Computer','0','0','1','GigabitEthernet-01','NetworkPortEthernet','','','0','0','2017-12-06 10:30:23','2017-12-06 10:30:23');
INSERT INTO `glpi_networkports` VALUES ('26','2','Printer','0','0','1','LAN','NetworkPortEthernet','','','0','0','2017-12-07 10:19:54','2017-12-07 10:19:54');
INSERT INTO `glpi_networkports` VALUES ('27','9','Computer','0','0','0','eth0','NetworkPortEthernet','08:00:27:97:30:0f',NULL,'0','1','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_networkports` VALUES ('28','10','Computer','0','0','0','Intel(R) PRO/1000 MT Desktop Adapter','NetworkPortEthernet','08:00:27:f7:5f:7f',NULL,'0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_networkports` VALUES ('29','12','Computer','0','0','0','Wifi/3G interface','NetworkPortWifi','d0:22:be:4d:14:ad',NULL,'0','1','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_networkports_networkports

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id_1` int(11) NOT NULL DEFAULT '0',
  `networkports_id_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  KEY `networkports_id_2` (`networkports_id_2`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkports_networkports` VALUES ('1','25','2');
INSERT INTO `glpi_networkports_networkports` VALUES ('2','26','5');

### Dump table glpi_networkports_vlans

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  `tagged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  KEY `vlans_id` (`vlans_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkports_vlans` VALUES ('1','1','1','1');
INSERT INTO `glpi_networkports_vlans` VALUES ('2','2','2','0');
INSERT INTO `glpi_networkports_vlans` VALUES ('3','25','2','0');

### Dump table glpi_networkportwifis

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `wifinetworks_id` int(11) NOT NULL DEFAULT '0',
  `networkportwifis_id` int(11) NOT NULL DEFAULT '0' COMMENT 'only useful in case of Managed node',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `essid` (`wifinetworks_id`),
  KEY `version` (`version`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networks

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networks` VALUES ('1','REDE_IMPRESSORAS','','2017-12-07 10:21:45','2017-12-07 10:21:45');

### Dump table glpi_notepads

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date` (`date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notifications

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications` VALUES ('1','Alert Tickets not closed','0','Ticket','alertnotclosed','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('2','New Ticket','0','Ticket','new','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('3','Update Ticket','0','Ticket','update','','1','0','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('4','Close Ticket','0','Ticket','closed','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('5','Add Followup','0','Ticket','add_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('6','Add Task','0','Ticket','add_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('7','Update Followup','0','Ticket','update_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('8','Update Task','0','Ticket','update_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('9','Delete Followup','0','Ticket','delete_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('10','Delete Task','0','Ticket','delete_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('11','Resolve ticket','0','Ticket','solved','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('12','Ticket Validation','0','Ticket','validation','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('13','New Reservation','0','Reservation','new','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('14','Update Reservation','0','Reservation','update','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('15','Delete Reservation','0','Reservation','delete','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('16','Alert Reservation','0','Reservation','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('17','Contract Notice','0','Contract','notice','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('18','Contract End','0','Contract','end','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('19','MySQL Synchronization','0','DBConnection','desynchronization','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('20','Cartridges','0','CartridgeItem','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('21','Consumables','0','ConsumableItem','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('22','Infocoms','0','Infocom','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('23','Software Licenses','0','SoftwareLicense','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('24','Ticket Recall','0','Ticket','recall','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('25','Password Forget','0','User','passwordforget','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('26','Ticket Satisfaction','0','Ticket','satisfaction','','1','1','2011-03-04 11:35:15',NULL);
INSERT INTO `glpi_notifications` VALUES ('27','Item not unique','0','FieldUnicity','refuse','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('28','Crontask Watcher','0','Crontask','alert','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('29','New Problem','0','Problem','new','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('30','Update Problem','0','Problem','update','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('31','Resolve Problem','0','Problem','solved','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('32','Add Task','0','Problem','add_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('33','Update Task','0','Problem','update_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('34','Delete Task','0','Problem','delete_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('35','Close Problem','0','Problem','closed','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('36','Delete Problem','0','Problem','delete','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('37','Ticket Validation Answer','0','Ticket','validation_answer','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('38','Contract End Periodicity','0','Contract','periodicity','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('39','Contract Notice Periodicity','0','Contract','periodicitynotice','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('40','Planning recall','0','PlanningRecall','planningrecall','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('41','Delete Ticket','0','Ticket','delete','','1','1','2014-01-15 14:35:26',NULL);
INSERT INTO `glpi_notifications` VALUES ('42','New Change','0','Change','new','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('43','Update Change','0','Change','update','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('44','Resolve Change','0','Change','solved','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('45','Add Task','0','Change','add_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('46','Update Task','0','Change','update_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('47','Delete Task','0','Change','delete_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('48','Close Change','0','Change','closed','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('49','Delete Change','0','Change','delete','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('50','Ticket Satisfaction Answer','0','Ticket','replysatisfaction','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('51','Receiver errors','0','MailCollector','error','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('52','New Project','0','Project','new','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('53','Update Project','0','Project','update','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('54','Delete Project','0','Project','delete','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('55','New Project Task','0','ProjectTask','new','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('56','Update Project Task','0','ProjectTask','update','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('57','Delete Project Task','0','ProjectTask','delete','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('58','Request Unlock Items','0','ObjectLock','unlock','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('59','New user in requesters','0','Ticket','requester_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('60','New group in requesters','0','Ticket','requester_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('61','New user in observers','0','Ticket','observer_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('62','New group in observers','0','Ticket','observer_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('63','New user in assignees','0','Ticket','assign_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('64','New group in assignees','0','Ticket','assign_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('65','New supplier in assignees','0','Ticket','assign_supplier','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('66','Saved searches','0','SavedSearch_Alert','alert','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('67','Certificates','0','Certificate','alert','','1','1',NULL,NULL);
INSERT INTO `glpi_notifications` VALUES ('68','Computers not imported','0','PluginOcsinventoryngNotimportedcomputer','not_imported',NULL,'1','1',NULL,NULL);
INSERT INTO `glpi_notifications` VALUES ('69','Check rule import entity','0','PluginOcsinventoryngRuleImportEntity','checkruleimportentity',NULL,'1','1',NULL,NULL);
INSERT INTO `glpi_notifications` VALUES ('70','Novo chamado (Telegram)','0','Ticket','new','','0','1','2018-01-18 21:52:30','2018-01-18 21:52:30');

### Dump table glpi_notifications_notificationtemplates

DROP TABLE IF EXISTS `glpi_notifications_notificationtemplates`;
CREATE TABLE `glpi_notifications_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notifications_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`notifications_id`,`mode`,`notificationtemplates_id`),
  KEY `notifications_id` (`notifications_id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`),
  KEY `mode` (`mode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('1','1','mailing','6');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('10','10','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('11','11','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('12','12','mailing','7');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('13','13','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('14','14','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('15','15','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('16','16','mailing','3');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('17','17','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('18','18','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('19','19','mailing','1');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('2','2','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('20','20','mailing','8');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('21','21','mailing','9');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('22','22','mailing','10');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('23','23','mailing','11');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('24','24','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('25','25','mailing','13');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('26','26','mailing','14');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('27','27','mailing','15');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('28','28','mailing','16');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('29','29','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('3','3','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('30','30','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('31','31','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('32','32','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('33','33','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('34','34','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('35','35','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('36','36','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('37','37','mailing','7');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('38','38','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('39','39','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('4','4','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('40','40','mailing','18');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('41','41','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('42','42','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('43','43','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('44','44','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('45','45','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('46','46','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('47','47','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('48','48','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('49','49','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('5','5','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('50','50','mailing','14');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('51','51','mailing','20');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('52','52','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('53','53','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('54','54','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('55','55','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('56','56','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('57','57','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('58','58','mailing','23');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('59','59','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('6','6','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('60','60','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('61','61','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('62','62','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('63','63','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('64','64','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('65','65','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('66','66','mailing','24');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('67','67','mailing','25');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('68','68','mailing','26');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('69','69','mailing','27');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('7','7','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('70','70','websocket','28');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('8','8','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('9','9','mailing','4');

### Dump table glpi_notificationtargets

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `notifications_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `items` (`type`,`items_id`),
  KEY `notifications_id` (`notifications_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtargets` VALUES ('1','3','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('2','1','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('3','3','2','2');
INSERT INTO `glpi_notificationtargets` VALUES ('4','1','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('5','1','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('6','1','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('7','1','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('8','2','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('9','4','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('10','3','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('11','3','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('12','3','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('13','3','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('14','1','1','19');
INSERT INTO `glpi_notificationtargets` VALUES ('15','14','1','12');
INSERT INTO `glpi_notificationtargets` VALUES ('16','3','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('17','1','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('18','3','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('19','1','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('20','1','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('21','3','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('22','1','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('23','3','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('24','1','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('25','3','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('26','1','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('27','3','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('28','1','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('29','3','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('30','1','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('31','3','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('32','19','1','25');
INSERT INTO `glpi_notificationtargets` VALUES ('33','3','1','26');
INSERT INTO `glpi_notificationtargets` VALUES ('34','21','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('35','21','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('36','21','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('37','21','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('38','21','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('39','21','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('40','21','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('41','21','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('42','21','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('43','21','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('46','1','1','28');
INSERT INTO `glpi_notificationtargets` VALUES ('47','3','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('48','1','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('49','21','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('50','2','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('51','4','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('52','3','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('53','1','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('54','21','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('55','3','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('56','1','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('57','21','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('58','3','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('59','1','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('60','21','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('61','3','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('62','1','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('63','21','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('64','3','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('65','1','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('66','21','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('67','3','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('68','1','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('69','21','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('70','3','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('71','1','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('72','21','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('73','14','1','37');
INSERT INTO `glpi_notificationtargets` VALUES ('74','3','1','40');
INSERT INTO `glpi_notificationtargets` VALUES ('75','1','1','41');
INSERT INTO `glpi_notificationtargets` VALUES ('76','3','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('77','1','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('78','21','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('79','2','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('80','4','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('81','3','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('82','1','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('83','21','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('84','3','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('85','1','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('86','21','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('87','3','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('88','1','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('89','21','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('90','3','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('91','1','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('92','21','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('93','3','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('94','1','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('95','21','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('96','3','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('97','1','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('98','21','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('99','3','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('100','1','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('101','21','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('102','3','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('103','2','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('104','1','1','51');
INSERT INTO `glpi_notificationtargets` VALUES ('105','27','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('106','1','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('107','28','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('108','27','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('109','1','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('110','28','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('111','27','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('112','1','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('113','28','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('114','31','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('115','1','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('116','32','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('117','31','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('118','1','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('119','32','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('120','31','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('121','1','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('122','32','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('123','19','1','58');
INSERT INTO `glpi_notificationtargets` VALUES ('124','3','1','59');
INSERT INTO `glpi_notificationtargets` VALUES ('125','13','1','60');
INSERT INTO `glpi_notificationtargets` VALUES ('126','21','1','61');
INSERT INTO `glpi_notificationtargets` VALUES ('127','20','1','62');
INSERT INTO `glpi_notificationtargets` VALUES ('128','2','1','63');
INSERT INTO `glpi_notificationtargets` VALUES ('129','23','1','64');
INSERT INTO `glpi_notificationtargets` VALUES ('130','8','1','65');
INSERT INTO `glpi_notificationtargets` VALUES ('131','19','1','66');
INSERT INTO `glpi_notificationtargets` VALUES ('132','1','1','70');
INSERT INTO `glpi_notificationtargets` VALUES ('133','3','1','70');

### Dump table glpi_notificationtemplates

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplates` VALUES ('1','MySQL Synchronization','DBConnection','2010-02-01 15:51:46','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('2','Reservations','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('3','Alert Reservation','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('4','Tickets','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('5','Tickets (Simple)','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('6','Alert Tickets not closed','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('7','Tickets Validation','Ticket','2010-02-26 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('8','Cartridges','CartridgeItem','2010-02-16 13:17:24','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('9','Consumables','ConsumableItem','2010-02-16 13:17:38','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('10','Infocoms','Infocom','2010-02-16 13:17:55','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('11','Licenses','SoftwareLicense','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('12','Contracts','Contract','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('13','Password Forget','User','2011-03-04 11:35:13',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('14','Ticket Satisfaction','Ticket','2011-03-04 11:35:15',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('15','Item not unique','FieldUnicity','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('16','Crontask','Crontask','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('17','Problems','Problem','2011-12-06 09:48:33',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('18','Planning recall','PlanningRecall','2014-01-15 14:35:24',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('19','Changes','Change','2014-06-18 08:02:07',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('20','Receiver errors','MailCollector','2014-06-18 08:02:08',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('21','Projects','Project','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('22','Project Tasks','ProjectTask','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('23','Unlock Item request','ObjectLock','2016-02-08 16:57:46',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('24','Saved searches alerts','SavedSearch_Alert','0000-00-00 00:00:00',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('25','Certificates','Certificate',NULL,'',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('26','Computers not imported','PluginOcsinventoryngNotimportedcomputer','2018-01-17 00:09:16','',NULL,'2018-01-17 00:09:16');
INSERT INTO `glpi_notificationtemplates` VALUES ('27','Check rule import entity','PluginOcsinventoryngRuleImportEntity',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('28','Novo chamado (telegram)','Ticket','2018-01-18 21:50:38','','','2018-01-18 21:50:38');

### Dump table glpi_notificationtemplatetranslations

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `language` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_text` text COLLATE utf8_unicode_ci,
  `content_html` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('1','1','','##lang.dbconnection.title##','##lang.dbconnection.delay## : ##dbconnection.delay##
','&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('2','2','','##reservation.action##','======================================================================
##lang.reservation.user##: ##reservation.user##
##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##
##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##
##lang.reservation.begin##: ##reservation.begin##
##lang.reservation.end##: ##reservation.end##
##lang.reservation.comment##: ##reservation.comment##
======================================================================
','&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('3','3','','##reservation.action##  ##reservation.entity##','##lang.reservation.entity## : ##reservation.entity##


##FOREACHreservations##
##lang.reservation.itemtype## : ##reservation.itemtype##

 ##lang.reservation.item## : ##reservation.item##

 ##reservation.url##

 ##ENDFOREACHreservations##','&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;
##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;
 ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;
 &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;
 ##ENDFOREACHreservations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('4','4','','##ticket.action## ##ticket.title##',' ##IFticket.storestatus=5##
 ##lang.ticket.url## : ##ticket.urlapprove##
 ##lang.ticket.autoclosewarning##
 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##
 ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##

 ##lang.ticket.description##

 ##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##
 ##lang.ticket.creationdate## : ##ticket.creationdate##
 ##lang.ticket.closedate## : ##ticket.closedate##
 ##lang.ticket.requesttype## : ##ticket.requesttype##
##lang.ticket.item.name## :

##FOREACHitems##

 ##IFticket.itemtype##
  ##ticket.itemtype## - ##ticket.item.name##
  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##
  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##
  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##
 ##ENDIFticket.itemtype##

##ENDFOREACHitems##
##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##
 ##lang.ticket.status## : ##ticket.status##
##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##
 ##lang.ticket.urgency## : ##ticket.urgency##
 ##lang.ticket.impact## : ##ticket.impact##
 ##lang.ticket.priority## : ##ticket.priority##
##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##
##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
 ##lang.ticket.content## : ##ticket.content##
 ##IFticket.storestatus=6##

 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description##
 ##ENDIFticket.storestatus##
 ##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##

##FOREACHfollowups##

 [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##
 ##lang.followup.author## ##followup.author##
 ##lang.followup.description## ##followup.description##
 ##lang.followup.date## ##followup.date##
 ##lang.followup.requesttype## ##followup.requesttype##

##ENDFOREACHfollowups##
 ##lang.ticket.numberoftasks## : ##ticket.numberoftasks##

##FOREACHtasks##

 [##task.date##] ##lang.task.isprivate## : ##task.isprivate##
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##','<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div>##IFticket.storestatus=5##</div>
<div>##lang.ticket.url## : <a href=\"##ticket.urlapprove##\">##ticket.urlapprove##</a> <strong>&#160;</strong></div>
<div><strong>##lang.ticket.autoclosewarning##</strong></div>
<div><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.type##</strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description## ##ENDIFticket.storestatus##</div>
<div>##ELSEticket.storestatus## ##lang.ticket.url## : <a href=\"##ticket.url##\">##ticket.url##</a> ##ENDELSEticket.storestatus##</div>
<p class=\"description b\"><strong>##lang.ticket.description##</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.title##</span>&#160;:##ticket.title## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.authors##</span>&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.creationdate##</span>&#160;:##ticket.creationdate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.closedate##</span>&#160;:##ticket.closedate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.requesttype##</span>&#160;:##ticket.requesttype##<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.item.name##</span>&#160;:
<p>##FOREACHitems##</p>
<div class=\"description b\">##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## </div><br />
<p>##ENDFOREACHitems##</p>
##IFticket.assigntousers## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntousers##</span>&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.status## </span>&#160;: ##ticket.status##<br /> ##IFticket.assigntogroups## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntogroups##</span>&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.urgency##</span>&#160;: ##ticket.urgency##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.impact##</span>&#160;: ##ticket.impact##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.priority##</span>&#160;: ##ticket.priority## <br /> ##IFticket.user.email##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.user.email##</span>&#160;: ##ticket.user.email ##ENDIFticket.user.email##    <br /> ##IFticket.category##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.category## </span>&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.content##</span>&#160;: ##ticket.content##</p>
<br />##IFticket.storestatus=6##<br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solution.type##</span></strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description##<br />##ENDIFticket.storestatus##</p>
<div class=\"description b\">##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##</div>
<p>##FOREACHfollowups##</p>
<div class=\"description b\"><br /> <strong> [##followup.date##] <em>##lang.followup.isprivate## : ##followup.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.author## </span> ##followup.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.description## </span> ##followup.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.date## </span> ##followup.date##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.requesttype## </span> ##followup.requesttype##</div>
<p>##ENDFOREACHfollowups##</p>
<div class=\"description b\">##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##</div>
<p>##FOREACHtasks##</p>
<div class=\"description b\"><br /> <strong> [##task.date##] <em>##lang.task.isprivate## : ##task.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.author##</span> ##task.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.description##</span> ##task.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.time##</span> ##task.time##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.category##</span> ##task.category##</div>
<p>##ENDFOREACHtasks##</p>');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('5','12','','##contract.action##  ##contract.entity##','##lang.contract.entity## : ##contract.entity##

##FOREACHcontracts##
##lang.contract.name## : ##contract.name##
##lang.contract.number## : ##contract.number##
##lang.contract.time## : ##contract.time##
##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##
##contract.url##
##ENDFOREACHcontracts##','&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;
&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :
##contract.name##&lt;br /&gt;
##lang.contract.number## : ##contract.number##&lt;br /&gt;
##lang.contract.time## : ##contract.time##&lt;br /&gt;
##IFcontract.type####lang.contract.type## : ##contract.type##
##ENDIFcontract.type##&lt;br /&gt;
&lt;a href=\"##contract.url##\"&gt;
##contract.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcontracts##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('6','5','','##ticket.action## ##ticket.title##','##lang.ticket.url## : ##ticket.url##

##lang.ticket.description##


##lang.ticket.title##  :##ticket.title##

##lang.ticket.authors##  :##IFticket.authors##
##ticket.authors## ##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##

##IFticket.category## ##lang.ticket.category##  :##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##

##lang.ticket.content##  : ##ticket.content##
##IFticket.itemtype##
##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##','&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;
##ticket.url##&lt;/a&gt;&lt;/div&gt;
&lt;div class=\"description b\"&gt;
##lang.ticket.description##&lt;/div&gt;
&lt;p&gt;&lt;span
style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.authors##&lt;/span&gt;
##IFticket.authors## ##ticket.authors##
##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;&#160
;&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;
##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.content##&lt;/span&gt;&#160;:
##ticket.content##&lt;br /&gt;##IFticket.itemtype##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.item.name##&lt;/span&gt;&#160;:
##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('7','7','','##ticket.action## ##ticket.title##','##FOREACHvalidations##

##IFvalidation.storestatus=2##
##validation.submission.title##
##lang.validation.commentsubmission## : ##validation.commentsubmission##
##ENDIFvalidation.storestatus##
##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##

##lang.ticket.url## : ##ticket.urlvalidation##

##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
##IFvalidation.commentvalidation##
##lang.validation.commentvalidation## : ##validation.commentvalidation##
##ENDIFvalidation.commentvalidation##
##ENDFOREACHvalidations##','&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;
&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;
&lt;div&gt;##validation.submission.title##&lt;/div&gt;
&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;
&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;&lt;/div&gt;
&lt;div&gt;
&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :
&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##
&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('8','6','','##ticket.action## ##ticket.entity##','##lang.ticket.entity## : ##ticket.entity##

##FOREACHtickets##

##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.status## : ##ticket.status##

 ##ticket.url##
 ##ENDFOREACHtickets##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHtickets##
&lt;tr&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHtickets##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('9','9','','##consumable.action##  ##consumable.entity##','##lang.consumable.entity## : ##consumable.entity##


##FOREACHconsumables##
##lang.consumable.item## : ##consumable.item##


##lang.consumable.reference## : ##consumable.reference##

##lang.consumable.remaining## : ##consumable.remaining##

##consumable.url##

##ENDFOREACHconsumables##','&lt;p&gt;
##lang.consumable.entity## : ##consumable.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##
&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;
&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;
##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;
&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;
   ##ENDFOREACHconsumables##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('10','8','','##cartridge.action##  ##cartridge.entity##','##lang.cartridge.entity## : ##cartridge.entity##


##FOREACHcartridges##
##lang.cartridge.item## : ##cartridge.item##


##lang.cartridge.reference## : ##cartridge.reference##

##lang.cartridge.remaining## : ##cartridge.remaining##

##cartridge.url##
 ##ENDFOREACHcartridges##','&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##
&lt;br /&gt;##lang.cartridge.item## :
##cartridge.item##&lt;br /&gt; &lt;br /&gt;
##lang.cartridge.reference## :
##cartridge.reference##&lt;br /&gt;
##lang.cartridge.remaining## :
##cartridge.remaining##&lt;br /&gt;
&lt;a href=\"##cartridge.url##\"&gt;
##cartridge.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcartridges##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('11','10','','##infocom.action##  ##infocom.entity##','##lang.infocom.entity## : ##infocom.entity##


##FOREACHinfocoms##

##lang.infocom.itemtype## : ##infocom.itemtype##

##lang.infocom.item## : ##infocom.item##


##lang.infocom.expirationdate## : ##infocom.expirationdate##

##infocom.url##
 ##ENDFOREACHinfocoms##','&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##
&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;
##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;
##lang.infocom.expirationdate## : ##infocom.expirationdate##
&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;
##infocom.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHinfocoms##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('12','11','','##license.action##  ##license.entity##','##lang.license.entity## : ##license.entity##

##FOREACHlicenses##

##lang.license.item## : ##license.item##

##lang.license.serial## : ##license.serial##

##lang.license.expirationdate## : ##license.expirationdate##

##license.url##
 ##ENDFOREACHlicenses##','&lt;p&gt;
##lang.license.entity## : ##license.entity##&lt;br /&gt;
##FOREACHlicenses##
&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;
##lang.license.serial## : ##license.serial##&lt;br /&gt;
##lang.license.expirationdate## : ##license.expirationdate##
&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('13','13','','##user.action##','##user.realname## ##user.firstname##

##lang.passwordforget.information##

##lang.passwordforget.link## ##user.passwordforgeturl##','&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('14','14','','##ticket.action## ##ticket.title##','##lang.ticket.title## : ##ticket.title##

##lang.ticket.closedate## : ##ticket.closedate##

##lang.satisfaction.text## ##ticket.urlsatisfaction##','&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;
&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;
&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('15','15','','##lang.unicity.action##','##lang.unicity.entity## : ##unicity.entity##

##lang.unicity.itemtype## : ##unicity.itemtype##

##lang.unicity.message## : ##unicity.message##

##lang.unicity.action_user## : ##unicity.action_user##

##lang.unicity.action_type## : ##unicity.action_type##

##lang.unicity.date## : ##unicity.date##','&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;
&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;
&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;
&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('16','16','','##crontask.action##','##lang.crontask.warning##

##FOREACHcrontasks##
 ##crontask.name## : ##crontask.description##

##ENDFOREACHcrontasks##','&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;
&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('17','17','','##problem.action## ##problem.title##','##IFproblem.storestatus=5##
 ##lang.problem.url## : ##problem.urlapprove##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##
 ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##

 ##lang.problem.description##

 ##lang.problem.title##  :##problem.title##
 ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##
 ##lang.problem.creationdate##  :##problem.creationdate##
 ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##
 ##lang.problem.status##  : ##problem.status##
 ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##
 ##lang.problem.urgency##  : ##problem.urgency##
 ##lang.problem.impact##  : ##problem.impact##
 ##lang.problem.priority## : ##problem.priority##
##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##
 ##lang.problem.content##  : ##problem.content##

##IFproblem.storestatus=6##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description##
##ENDIFproblem.storestatus##
 ##lang.problem.numberoftickets## : ##problem.numberoftickets##

##FOREACHtickets##
 [##ticket.date##] ##lang.problem.title## : ##ticket.title##
 ##lang.problem.content## ##ticket.content##

##ENDFOREACHtickets##
 ##lang.problem.numberoftasks## : ##problem.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;
&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;
&lt;p&gt;##FOREACHtickets##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##
&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('18','18','','##recall.action##: ##recall.item.name##','##recall.action##: ##recall.item.name##

##recall.item.content##

##lang.recall.planning.begin##: ##recall.planning.begin##
##lang.recall.planning.end##: ##recall.planning.end##
##lang.recall.planning.state##: ##recall.planning.state##
##lang.recall.item.private##: ##recall.item.private##','&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;##recall.item.content##&lt;/p&gt;
&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('19','19','','##change.action## ##change.title##','##IFchange.storestatus=5##
 ##lang.change.url## : ##change.urlapprove##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##
 ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##

 ##lang.change.description##

 ##lang.change.title##  :##change.title##
 ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##
 ##lang.change.creationdate##  :##change.creationdate##
 ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##
 ##lang.change.status##  : ##change.status##
 ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##
 ##lang.change.urgency##  : ##change.urgency##
 ##lang.change.impact##  : ##change.impact##
 ##lang.change.priority## : ##change.priority##
##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##
 ##lang.change.content##  : ##change.content##

##IFchange.storestatus=6##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description##
##ENDIFchange.storestatus##
 ##lang.change.numberofproblems## : ##change.numberofproblems##

##FOREACHproblems##
 [##problem.date##] ##lang.change.title## : ##problem.title##
 ##lang.change.content## ##problem.content##

##ENDFOREACHproblems##
 ##lang.change.numberoftasks## : ##change.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;
&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;
&lt;p&gt;##FOREACHproblems##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##
&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('20','20','','##mailcollector.action##','##FOREACHmailcollectors##
##lang.mailcollector.name## : ##mailcollector.name##
##lang.mailcollector.errors## : ##mailcollector.errors##
##mailcollector.url##
##ENDFOREACHmailcollectors##','&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('21','21','','##project.action## ##project.name## ##project.code##','##lang.project.url## : ##project.url##

##lang.project.description##

##lang.project.name## : ##project.name##
##lang.project.code## : ##project.code##
##lang.project.manager## : ##project.manager##
##lang.project.managergroup## : ##project.managergroup##
##lang.project.creationdate## : ##project.creationdate##
##lang.project.priority## : ##project.priority##
##lang.project.state## : ##project.state##
##lang.project.type## : ##project.type##
##lang.project.description## : ##project.description##

##lang.project.numberoftasks## : ##project.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;
&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('22','22','','##projecttask.action## ##projecttask.name##','##lang.projecttask.url## : ##projecttask.url##

##lang.projecttask.description##

##lang.projecttask.name## : ##projecttask.name##
##lang.projecttask.project## : ##projecttask.project##
##lang.projecttask.creationdate## : ##projecttask.creationdate##
##lang.projecttask.state## : ##projecttask.state##
##lang.projecttask.type## : ##projecttask.type##
##lang.projecttask.description## : ##projecttask.description##

##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;
&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('23','23','','##objectlock.action##','##objectlock.type## ###objectlock.id## - ##objectlock.name##

      ##lang.objectlock.url##
      ##objectlock.url##

      ##lang.objectlock.date_mod##
      ##objectlock.date_mod##

      Hello ##objectlock.lockedby.firstname##,
      Could go to this item and unlock it for me?
      Thank you,
      Regards,
      ##objectlock.requester.firstname##','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;
      &lt;td&gt;##objectlock.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;
      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('24','24','','##savedsearch.action## ##savedsearch.name##','##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##

      ##savedsearch.message##

      ##lang.savedsearch.url##
      ##savedsearch.url##

      Regards,','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;&lt;td colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.message##&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.savedsearch.url##&lt;/td&gt;
      &lt;td&gt;##savedsearch.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello &lt;br /&gt;Regards,&lt;/span&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('25','25','','##certificate.action##  ##certificate.entity##','##lang.certificate.entity## : ##certificate.entity##

##FOREACHcertificates##

##lang.certificate.serial## : ##certificate.serial##

##lang.certificate.expirationdate## : ##certificate.expirationdate##

##certificate.url##
 ##ENDFOREACHcertificates##','&lt;p&gt;
##lang.certificate.entity## : ##certificate.entity##&lt;br /&gt;
##FOREACHcertificates##
&lt;br /&gt;##lang.certificate.name## : ##certificate.name##&lt;br /&gt;
##lang.certificate.serial## : ##certificate.serial##&lt;br /&gt;
##lang.certificate.expirationdate## : ##certificate.expirationdate##
&lt;br /&gt; &lt;a href=\"##certificate.url##\"&gt; ##certificate.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHcertificates##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('26','26','','##lang.notimported.action## : ##notimported.entity##','

##lang.notimported.action## :&#160;##notimported.entity##

##FOREACHnotimported##&#160;
##lang.notimported.reason## : ##notimported.reason##
##lang.notimported.name## : ##notimported.name##
##lang.notimported.deviceid## : ##notimported.deviceid##
##lang.notimported.tag## : ##notimported.tag##
##lang.notimported.serial## : ##notimported.serial## 

 ##notimported.url## 
##ENDFOREACHnotimported## 
','&lt;p&gt;##lang.notimported.action## :&#160;##notimported.entity##&lt;br /&gt;&lt;br /&gt;##FOREACHnotimported##&#160;&lt;br /&gt;##lang.notimported.reason## : ##notimported.reason##&lt;br /&gt;##lang.notimported.name## : ##notimported.name##&lt;br /&gt;##lang.notimported.deviceid## : ##notimported.deviceid##&lt;br /&gt;##lang.notimported.tag## : ##notimported.tag##&lt;br /&gt;##lang.notimported.serial## : ##notimported.serial##&lt;/p&gt;
&lt;p&gt;&lt;a href=\"##notimported.url##\"&gt;##notimported.url##&lt;/a&gt;&lt;br /&gt;##ENDFOREACHnotimported##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('27','27','','[##checkruleimportentity.date##] ##checkruleimportentity.title## : ##checkruleimportentity.entity##','##FOREACHcheckruleimportentityitems##
##lang.checkruleimportentity.entity## : ##checkruleimportentity.entity##
##lang.checkruleimportentity.computer## : ##checkruleimportentity.computer##
##lang.checkruleimportentity.location## : ##checkruleimportentity.location##
##lang.checkruleimportentity.error## : ##checkruleimportentity.error##
##lang.checkruleimportentity.dataerror## : ##checkruleimportentity.dataerror##
##lang.checkruleimportentity.name_rule## ##checkruleimportentity.name_rule##
##ENDFOREACHcheckruleimportentityitems##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.entity##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.computer##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.location##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.error##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.dataerror##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##lang.checkruleimportentity.name_rule##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHcheckruleimportentityitems##
&lt;tr&gt;
&lt;td&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.entity##&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;a href=\"##checkruleimportentity.url##\" target=\"_blank\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.computer##&lt;/span&gt;&lt;/a&gt;&lt;/td&gt;
&lt;td&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.location##&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.error##&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.dataerror##&lt;/span&gt;&lt;/td&gt;
&lt;td&gt;&lt;a href=\"##checkruleimportentity.url_rule##\" target=\"_blank\"&gt;&lt;span style=\"font-family: Verdana; font-size: 11px; text-align: left;\"&gt;##checkruleimportentity.name_rule##&lt;/span&gt;&lt;/a&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHcheckruleimportentityitems##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('28','28','','Olá','Novo chamado
ID: ##ticket.id##
Título: ##ticket.title##

','');

### Dump table glpi_notimportedemails

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `subject` text,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `mailcollectors_id` (`mailcollectors_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


### Dump table glpi_objectlocks

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Type of locked object',
  `items_id` int(11) NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(11) NOT NULL COMMENT 'id of the locker',
  `date_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the lock',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevelactions

DROP TABLE IF EXISTS `glpi_olalevelactions`;
CREATE TABLE `glpi_olalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `olalevels_id` (`olalevels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevelcriterias

DROP TABLE IF EXISTS `glpi_olalevelcriterias`;
CREATE TABLE `glpi_olalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `olalevels_id` (`olalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevels

DROP TABLE IF EXISTS `glpi_olalevels`;
CREATE TABLE `glpi_olalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `olas_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `olas_id` (`olas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevels_tickets

DROP TABLE IF EXISTS `glpi_olalevels_tickets`;
CREATE TABLE `glpi_olalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`olalevels_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `olalevels_id` (`olalevels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olas

DROP TABLE IF EXISTS `glpi_olas`;
CREATE TABLE `glpi_olas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slms_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `calendars_id` (`calendars_id`),
  KEY `slms_id` (`slms_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_olas` VALUES ('1','OLA 30min Aceitar','0','1','1','','30','0','2018-01-13 13:22:01','minute','0','2018-01-13 13:20:47','1');
INSERT INTO `glpi_olas` VALUES ('2','OLA 12h Solução','0','1','0','','12','0','2018-01-13 13:22:01','hour','0','2018-01-13 13:21:13','1');

### Dump table glpi_operatingsystemarchitectures

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystemarchitectures` VALUES ('1','x86 64 bit','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_operatingsystemeditions

DROP TABLE IF EXISTS `glpi_operatingsystemeditions`;
CREATE TABLE `glpi_operatingsystemeditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemkernels

DROP TABLE IF EXISTS `glpi_operatingsystemkernels`;
CREATE TABLE `glpi_operatingsystemkernels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemkernelversions

DROP TABLE IF EXISTS `glpi_operatingsystemkernelversions`;
CREATE TABLE `glpi_operatingsystemkernelversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operatingsystemkernels_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `operatingsystemkernels_id` (`operatingsystemkernels_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystems

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystems` VALUES ('3','Windows','','2017-12-03 14:18:53','2017-12-03 14:18:53');
INSERT INTO `glpi_operatingsystems` VALUES ('4','Ubuntu','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_operatingsystems` VALUES ('5','Microsoft Windows 8.1 Pro','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_operatingsystems` VALUES ('6','CentOS Linux release 7.3.1611 (Core)','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_operatingsystems` VALUES ('7','Android linux 5.0','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_operatingsystemservicepacks

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystemservicepacks` VALUES ('1','#26~14.04.1-Ubuntu SMP Fri Jul 24 21:16:20 UTC 2015','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_operatingsystemservicepacks` VALUES ('2','#1 SMP Wed Jan 18 13:06:36 UTC 2017','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_operatingsystemservicepacks` VALUES ('3','Kernel version : 3.4.0-6549282','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_operatingsystemversions

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystemversions` VALUES ('1','14.04','','2018-01-17 00:11:27','2018-01-17 00:11:27');
INSERT INTO `glpi_operatingsystemversions` VALUES ('2','6.3.9600','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_operatingsystemversions` VALUES ('3','3.10.0-514.6.1.el7.x86_64','','2018-01-17 00:11:29','2018-01-17 00:11:29');
INSERT INTO `glpi_operatingsystemversions` VALUES ('4','5.0','','2018-01-17 00:11:29','2018-01-17 00:11:29');

### Dump table glpi_pdumodels

DROP TABLE IF EXISTS `glpi_pdumodels`;
CREATE TABLE `glpi_pdumodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `max_power` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `is_rackable` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_rackable` (`is_rackable`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_pdus

DROP TABLE IF EXISTS `glpi_pdus`;
CREATE TABLE `glpi_pdus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pdumodels_id` int(11) DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to states (id)',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `pdutypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `pdumodels_id` (`pdumodels_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `group_id_tech` (`groups_id_tech`),
  KEY `is_template` (`is_template`),
  KEY `is_deleted` (`is_deleted`),
  KEY `states_id` (`states_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `pdutypes_id` (`pdutypes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_pdus_plugs

DROP TABLE IF EXISTS `glpi_pdus_plugs`;
CREATE TABLE `glpi_pdus_plugs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugs_id` int(11) NOT NULL DEFAULT '0',
  `pdus_id` int(11) NOT NULL DEFAULT '0',
  `number_plugs` int(11) DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plugs_id` (`plugs_id`),
  KEY `pdus_id` (`pdus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_pdus_racks

DROP TABLE IF EXISTS `glpi_pdus_racks`;
CREATE TABLE `glpi_pdus_racks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `racks_id` int(11) NOT NULL DEFAULT '0',
  `pdus_id` int(11) NOT NULL DEFAULT '0',
  `side` int(11) DEFAULT '0',
  `position` int(11) NOT NULL,
  `bgcolor` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `racks_id` (`racks_id`),
  KEY `pdus_id` (`pdus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_pdutypes

DROP TABLE IF EXISTS `glpi_pdutypes`;
CREATE TABLE `glpi_pdutypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheralmodels

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `required_units` int(11) NOT NULL DEFAULT '1',
  `depth` float NOT NULL DEFAULT '1',
  `power_connections` int(11) NOT NULL DEFAULT '0',
  `power_consumption` int(11) NOT NULL DEFAULT '0',
  `is_half_rack` tinyint(1) NOT NULL DEFAULT '0',
  `picture_front` text COLLATE utf8_unicode_ci,
  `picture_rear` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_peripheralmodels` VALUES ('1','USB001','','1234','0','1','1','0','0','0',NULL,NULL,'2017-12-06 10:18:59','2017-12-06 10:18:59');

### Dump table glpi_peripherals

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `peripheraltypes_id` int(11) NOT NULL DEFAULT '0',
  `peripheralmodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `peripheralmodels_id` (`peripheralmodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `peripheraltypes_id` (`peripheraltypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_peripherals` VALUES ('1','0','&lt;SCN-\\Y-###&gt;','2017-12-06 10:19:25','','','5','0','','','&lt;###&gt;','1','1','1','HP','6','0','0','1','Scanner USB','0','0','2','0.0000','0','2017-12-06 10:19:25','0');
INSERT INTO `glpi_peripherals` VALUES ('2','0','SCN-2017-001','2017-12-06 10:19:43','','','5','0','','','001','1','1','1','HP','6','0','0','0','Scanner USB','0','0','2','0.0000','0','2017-12-06 10:19:43','0');

### Dump table glpi_peripheraltypes

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_peripheraltypes` VALUES ('1','Scanner','','2017-12-06 10:18:27','2017-12-06 10:18:27');

### Dump table glpi_phonemodels

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonepowersupplies

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phones

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `phonetypes_id` int(11) NOT NULL DEFAULT '0',
  `phonemodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_headset` tinyint(1) NOT NULL DEFAULT '0',
  `have_hp` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `phonemodels_id` (`phonemodels_id`),
  KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `phonetypes_id` (`phonetypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonetypes

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_planningrecalls

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `before_time` int(11) NOT NULL DEFAULT '-10',
  `when` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  KEY `users_id` (`users_id`),
  KEY `before_time` (`before_time`),
  KEY `when` (`when`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_configs

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_configs`;
CREATE TABLE `glpi_plugin_ocsinventoryng_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_log_frequency` int(11) NOT NULL DEFAULT '10',
  `is_displayempty` int(1) NOT NULL DEFAULT '1',
  `import_limit` int(11) NOT NULL DEFAULT '0',
  `delay_refresh` int(11) NOT NULL DEFAULT '0',
  `allow_ocs_update` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_ocsinventoryng_configs` VALUES ('1','2','1','0','0','0',NULL);

### Dump table glpi_plugin_ocsinventoryng_details

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_details`;
CREATE TABLE `glpi_plugin_ocsinventoryng_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `plugin_ocsinventoryng_threads_id` int(11) NOT NULL DEFAULT '0',
  `rules_id` text COLLATE utf8_unicode_ci,
  `threadid` int(11) NOT NULL DEFAULT '0',
  `ocsid` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `action` int(11) NOT NULL DEFAULT '0',
  `process_time` datetime DEFAULT NULL,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `end_time` (`process_time`),
  KEY `process_thread` (`plugin_ocsinventoryng_threads_id`,`threadid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_ipdiscoverocslinks

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ipdiscoverocslinks`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ipdiscoverocslinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `macaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` datetime DEFAULT NULL,
  `subnet` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `macaddress` (`macaddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_items_devicebiosdatas

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_items_devicebiosdatas`;
CREATE TABLE `glpi_plugin_ocsinventoryng_items_devicebiosdatas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plugin_ocsinventoryng_devicebiosdatas_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `plugin_ocsinventoryng_devicebiosdatas_id` (`plugin_ocsinventoryng_devicebiosdatas_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_networkports

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_networkports`;
CREATE TABLE `glpi_plugin_ocsinventoryng_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TYPEMIB` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT '10mb/s',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `TYPE` (`TYPE`),
  KEY `TYPEMIB` (`TYPEMIB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_networkporttypes

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_networkporttypes`;
CREATE TABLE `glpi_plugin_ocsinventoryng_networkporttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OCS_TYPE` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `OCS_TYPEMIB` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `OCS_TYPE` (`OCS_TYPE`),
  KEY `OCS_TYPEMIB` (`OCS_TYPEMIB`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_ocsinventoryng_networkporttypes` VALUES ('1','Unkown port','*','*','PluginOcsinventoryngNetworkPort',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_networkporttypes` VALUES ('2','Ethernet port','Ethernet','*','NetworkPortEthernet','T','10',NULL,NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_networkporttypes` VALUES ('3','Wifi port','Wifi','*','NetworkPortWifi',NULL,NULL,'a',NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_networkporttypes` VALUES ('4','Loopback port','Local','*','NetworkPortLocal',NULL,NULL,NULL,NULL);

### Dump table glpi_plugin_ocsinventoryng_networkshares

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_networkshares`;
CREATE TABLE `glpi_plugin_ocsinventoryng_networkshares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `drive` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `freespace` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quota` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_notimportedcomputers

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_notimportedcomputers`;
CREATE TABLE `glpi_plugin_ocsinventoryng_notimportedcomputers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `rules_id` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `ocsid` int(11) NOT NULL DEFAULT '0',
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL,
  `ocs_deviceid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `useragent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ipaddr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_inventory` datetime DEFAULT NULL,
  `reason` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ocs_id` (`plugin_ocsinventoryng_ocsservers_id`,`ocsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_ocsadmininfoslinks

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ocsadmininfoslinks`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ocsadmininfoslinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `glpi_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `plugin_ocsinventoryng_ocsservers_id` (`plugin_ocsinventoryng_ocsservers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_ocslinks

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ocslinks`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ocslinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `ocsid` int(11) NOT NULL DEFAULT '0',
  `ocs_deviceid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_auto_update` tinyint(1) NOT NULL DEFAULT '1',
  `last_update` datetime DEFAULT NULL,
  `last_ocs_update` datetime DEFAULT NULL,
  `last_ocs_conn` datetime DEFAULT NULL,
  `ip_src` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `computer_update` longtext COLLATE utf8_unicode_ci,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  `ocs_agent_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uptime` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`plugin_ocsinventoryng_ocsservers_id`,`ocsid`),
  KEY `last_update` (`last_update`),
  KEY `ocs_deviceid` (`ocs_deviceid`),
  KEY `last_ocs_update` (`plugin_ocsinventoryng_ocsservers_id`,`last_ocs_update`),
  KEY `computers_id` (`computers_id`),
  KEY `use_auto_update` (`use_auto_update`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_ocsinventoryng_ocslinks` VALUES ('1','9','7','otrs-fame-2017-02-28-22-38-06 ','1','2018-01-17 00:11:27','2017-02-26 11:44:30','2017-02-26 11:44:30','192.168.25.8 ',NULL,'1','OCS-NG_unified_unix_agent_v2.3 ','0','NA',NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_ocslinks` VALUES ('2','10','6','MUZZIO-WIN8-2017-02-19-21-47-34 ','1','2018-01-17 00:11:29','2017-02-26 11:06:20','2017-02-26 11:06:20','192.168.25.53 ',NULL,'1','OCS-NG_WINDOWS_AGENT_v2.3.0.0 ','0','NA',NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_ocslinks` VALUES ('3','11','5','localhost-2017-02-26-10-58-07 ','1','2018-01-17 00:11:29','2017-02-26 10:36:21','2017-02-26 10:36:21','192.168.25.51 ',NULL,'1','OCS-NG_unified_unix_agent_v2.3 ','0','Teste',NULL);
INSERT INTO `glpi_plugin_ocsinventoryng_ocslinks` VALUES ('4','12','8','android-3a90c8d173014a1d-2017-03-01-22-06-18 ','1','2018-01-17 00:11:29','2017-03-03 22:15:18','2017-03-03 22:15:18','192.168.25.5 ',NULL,'1','OCS-NG_Android_agent_v2.3 ','0','Mobile',NULL);

### Dump table glpi_plugin_ocsinventoryng_ocsservers

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ocsservers`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ocsservers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_db_utf8` tinyint(1) NOT NULL DEFAULT '0',
  `checksum` int(11) NOT NULL DEFAULT '0',
  `import_periph` tinyint(1) NOT NULL DEFAULT '0',
  `import_monitor` tinyint(1) NOT NULL DEFAULT '0',
  `import_software` tinyint(1) NOT NULL DEFAULT '0',
  `import_printer` tinyint(1) NOT NULL DEFAULT '0',
  `import_general_name` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_os` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_serial` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_model` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_manufacturer` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_type` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_domain` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_contact` tinyint(1) NOT NULL DEFAULT '1',
  `import_user` tinyint(1) NOT NULL DEFAULT '1',
  `import_user_location` tinyint(1) NOT NULL DEFAULT '1',
  `import_user_group` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_comment` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_processor` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_memory` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_hdd` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_iface` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_gfxcard` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_sound` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_drive` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_port` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_modem` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_bios` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_motherboard` tinyint(1) NOT NULL DEFAULT '1',
  `import_registry` tinyint(1) NOT NULL DEFAULT '1',
  `import_antivirus` tinyint(1) NOT NULL DEFAULT '0',
  `import_officepack` tinyint(1) NOT NULL DEFAULT '0',
  `import_winupdatestate` tinyint(1) NOT NULL DEFAULT '0',
  `import_proxysetting` tinyint(1) NOT NULL DEFAULT '0',
  `import_winusers` tinyint(1) NOT NULL DEFAULT '0',
  `import_teamviewer` tinyint(1) NOT NULL DEFAULT '0',
  `import_osinstall` tinyint(1) NOT NULL DEFAULT '0',
  `import_networkshare` tinyint(1) NOT NULL DEFAULT '0',
  `import_os_serial` tinyint(1) NOT NULL DEFAULT '1',
  `import_ip` tinyint(1) NOT NULL DEFAULT '1',
  `import_disk` tinyint(1) NOT NULL DEFAULT '1',
  `import_monitor_comment` tinyint(1) NOT NULL DEFAULT '0',
  `states_id_default` int(11) NOT NULL DEFAULT '0',
  `tag_limit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag_exclude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_soft_dict` tinyint(1) NOT NULL DEFAULT '0',
  `cron_sync_number` int(11) DEFAULT '1',
  `deconnection_behavior` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `use_massimport` tinyint(1) NOT NULL DEFAULT '0',
  `use_locks` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_behavior` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `import_vms` tinyint(1) NOT NULL DEFAULT '1',
  `import_general_uuid` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_controller` tinyint(1) NOT NULL DEFAULT '1',
  `import_device_slot` tinyint(1) NOT NULL DEFAULT '1',
  `ocs_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conn_type` tinyint(1) NOT NULL DEFAULT '0',
  `use_cleancron` tinyint(1) NOT NULL DEFAULT '0',
  `action_cleancron` tinyint(1) NOT NULL DEFAULT '0',
  `use_restorationcron` tinyint(1) NOT NULL DEFAULT '0',
  `delay_restorationcron` int(11) NOT NULL DEFAULT '0',
  `use_checkruleimportentity` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_name` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_serial` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_comment` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_contact` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_location` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_domain` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_manufacturer` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_createport` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_last_pages_counter` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_firmware` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_power` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_fan` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_printermemory` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_computernetworkcards` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_computermemory` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_computerprocessors` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_computersoftwares` tinyint(1) NOT NULL DEFAULT '0',
  `importsnmp_computervm` tinyint(1) NOT NULL DEFAULT '0',
  `import_uptime` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_name` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_serial` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_comment` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_contact` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_location` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_domain` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_manufacturer` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_createport` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_last_pages_counter` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_firmware` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_power` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_fan` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_printermemory` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_computernetworkcards` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_computermemory` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_computerprocessors` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_computersoftwares` tinyint(1) NOT NULL DEFAULT '0',
  `linksnmp_computervm` tinyint(1) NOT NULL DEFAULT '0',
  `dohistory` tinyint(1) NOT NULL DEFAULT '1',
  `history_hardware` tinyint(1) NOT NULL DEFAULT '1',
  `history_bios` tinyint(1) NOT NULL DEFAULT '1',
  `history_drives` tinyint(1) NOT NULL DEFAULT '1',
  `history_network` tinyint(1) NOT NULL DEFAULT '1',
  `history_devices` tinyint(1) NOT NULL DEFAULT '1',
  `history_monitor` tinyint(1) NOT NULL DEFAULT '1',
  `history_printer` tinyint(1) NOT NULL DEFAULT '1',
  `history_peripheral` tinyint(1) NOT NULL DEFAULT '1',
  `history_software` tinyint(1) NOT NULL DEFAULT '1',
  `history_vm` tinyint(1) NOT NULL DEFAULT '1',
  `history_admininfos` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`),
  KEY `use_massimport` (`use_massimport`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_ocsinventoryng_ocsservers` VALUES ('1','OCS','ocs','123456','192.168.56.80','ocsweb','1','449471','0','0','0','0','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','0','0','0','0','0','0','0','0','1','1','1','0','0',NULL,NULL,'0','1',NULL,'https://192.168.56.80/ocsreports/','2018-01-17 00:11:00','','1','0','1','1','1','1','1','1','7010','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','1','1','1','1','1','1','1','1','1','1','1','1');

### Dump table glpi_plugin_ocsinventoryng_ocsservers_profiles

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ocsservers_profiles`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ocsservers_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `plugin_ocsinventoryng_ocsservers_id` (`plugin_ocsinventoryng_ocsservers_id`),
  KEY `profiles_id` (`profiles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_ocsinventoryng_ocsservers_profiles` VALUES ('1','1','4');

### Dump table glpi_plugin_ocsinventoryng_osinstalls

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_osinstalls`;
CREATE TABLE `glpi_plugin_ocsinventoryng_osinstalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `build_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `install_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codeset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countrycode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oslanguage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `curtimezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_proxysettings

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_proxysettings`;
CREATE TABLE `glpi_plugin_ocsinventoryng_proxysettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0',
  `autoconfigurl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `override` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_registrykeys

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_registrykeys`;
CREATE TABLE `glpi_plugin_ocsinventoryng_registrykeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `hive` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ocs_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_ruleimportentities

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_ruleimportentities`;
CREATE TABLE `glpi_plugin_ocsinventoryng_ruleimportentities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_servers

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_servers`;
CREATE TABLE `glpi_plugin_ocsinventoryng_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  `max_ocsid` int(11) DEFAULT NULL,
  `max_glpidate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugin_ocsinventoryng_ocsservers_id` (`plugin_ocsinventoryng_ocsservers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_snmpocslinks

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_snmpocslinks`;
CREATE TABLE `glpi_plugin_ocsinventoryng_snmpocslinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `ocs_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '0',
  `linked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_teamviewers

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_teamviewers`;
CREATE TABLE `glpi_plugin_ocsinventoryng_teamviewers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `twid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_threads

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_threads`;
CREATE TABLE `glpi_plugin_ocsinventoryng_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `threadid` int(11) NOT NULL DEFAULT '0',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `error_msg` text COLLATE utf8_unicode_ci NOT NULL,
  `imported_machines_number` int(11) NOT NULL DEFAULT '0',
  `synchronized_machines_number` int(11) NOT NULL DEFAULT '0',
  `failed_rules_machines_number` int(11) NOT NULL DEFAULT '0',
  `linked_machines_number` int(11) NOT NULL DEFAULT '0',
  `notupdated_machines_number` int(11) NOT NULL DEFAULT '0',
  `not_unique_machines_number` int(11) NOT NULL DEFAULT '0',
  `link_refused_machines_number` int(11) NOT NULL DEFAULT '0',
  `total_number_machines` int(11) NOT NULL DEFAULT '0',
  `plugin_ocsinventoryng_ocsservers_id` int(11) NOT NULL DEFAULT '1',
  `processid` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `rules_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `end_time` (`end_time`),
  KEY `process_thread` (`processid`,`threadid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_winupdates

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_winupdates`;
CREATE TABLE `glpi_plugin_ocsinventoryng_winupdates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `auoptions` int(11) NOT NULL DEFAULT '0',
  `scheduleinstalldate` datetime DEFAULT NULL,
  `lastsuccesstime` datetime DEFAULT NULL,
  `detectsuccesstime` datetime DEFAULT NULL,
  `downloadsuccesstime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_ocsinventoryng_winusers

DROP TABLE IF EXISTS `glpi_plugin_ocsinventoryng_winusers`;
CREATE TABLE `glpi_plugin_ocsinventoryng_winusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `disabled` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_botan_shortener

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_botan_shortener`;
CREATE TABLE `glpi_plugin_telegrambot_botan_shortener` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `url` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Original URL',
  `short_url` char(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Shortened URL',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_callback_query

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_callback_query`;
CREATE TABLE `glpi_plugin_telegrambot_callback_query` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_message_id` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Identifier of the message sent via the bot in inline mode, that originated the query',
  `data` char(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Data associated with the callback button',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `chat_id` (`chat_id`),
  KEY `message_id` (`message_id`),
  KEY `chat_id_2` (`chat_id`,`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_chat

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_chat`;
CREATE TABLE `glpi_plugin_telegrambot_chat` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Unique user or chat identifier',
  `type` enum('private','group','supergroup','channel') COLLATE utf8_unicode_ci NOT NULL COMMENT 'Chat type, either private, group, supergroup or channel',
  `title` char(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'Chat (group) title, is null if chat type is private',
  `username` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Username, for private chats, supergroups and channels if available',
  `all_members_are_administrators` tinyint(1) DEFAULT '0' COMMENT 'True if a all members of this group are admins',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  `old_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, this is filled when a group is converted to a supergroup',
  PRIMARY KEY (`id`),
  KEY `old_id` (`old_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_chat` VALUES ('399679617','private',NULL,'eduardofraga',NULL,'2018-01-18 21:48:58','2018-01-18 21:49:00',NULL);

### Dump table glpi_plugin_telegrambot_chosen_inline_result

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_chosen_inline_result`;
CREATE TABLE `glpi_plugin_telegrambot_chosen_inline_result` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry',
  `result_id` char(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'Identifier for this result',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Location object, user''s location',
  `inline_message_id` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `query` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'The query that was used to obtain the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_conversation

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_conversation`;
CREATE TABLE `glpi_plugin_telegrambot_conversation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique user or chat identifier',
  `status` enum('active','cancelled','stopped') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'Conversation state',
  `command` varchar(160) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'Default command to execute',
  `notes` text COLLATE utf8_unicode_ci COMMENT 'Data stored from command',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `chat_id` (`chat_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_edited_message

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_edited_message`;
CREATE TABLE `glpi_plugin_telegrambot_edited_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `edit_date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was edited in timestamp format',
  `text` text COLLATE utf8_unicode_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8',
  `entities` text COLLATE utf8_unicode_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `caption` text COLLATE utf8_unicode_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  PRIMARY KEY (`id`),
  KEY `chat_id` (`chat_id`),
  KEY `message_id` (`message_id`),
  KEY `user_id` (`user_id`),
  KEY `chat_id_2` (`chat_id`,`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_inline_query

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_inline_query`;
CREATE TABLE `glpi_plugin_telegrambot_inline_query` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Unique identifier for this query',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `location` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Location of the user',
  `query` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Text of the query',
  `offset` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Offset of the result',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_message

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_message`;
CREATE TABLE `glpi_plugin_telegrambot_message` (
  `chat_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Unique chat identifier',
  `id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Unique message identifier',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier',
  `date` timestamp NULL DEFAULT NULL COMMENT 'Date the message was sent in timestamp format',
  `forward_from` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, sender of the original message',
  `forward_from_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier, chat the original message belongs to',
  `forward_from_message_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier of the original message in the channel',
  `forward_date` timestamp NULL DEFAULT NULL COMMENT 'date the original message was sent in timestamp format',
  `reply_to_chat` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `reply_to_message` bigint(20) unsigned DEFAULT NULL COMMENT 'Message that this message is reply to',
  `text` text COLLATE utf8_unicode_ci COMMENT 'For text messages, the actual UTF-8 text of the message max message length 4096 char utf8mb4',
  `entities` text COLLATE utf8_unicode_ci COMMENT 'For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text',
  `audio` text COLLATE utf8_unicode_ci COMMENT 'Audio object. Message is an audio file, information about the file',
  `document` text COLLATE utf8_unicode_ci COMMENT 'Document object. Message is a general file, information about the file',
  `photo` text COLLATE utf8_unicode_ci COMMENT 'Array of PhotoSize objects. Message is a photo, available sizes of the photo',
  `sticker` text COLLATE utf8_unicode_ci COMMENT 'Sticker object. Message is a sticker, information about the sticker',
  `video` text COLLATE utf8_unicode_ci COMMENT 'Video object. Message is a video, information about the video',
  `voice` text COLLATE utf8_unicode_ci COMMENT 'Voice Object. Message is a Voice, information about the Voice',
  `video_note` text COLLATE utf8_unicode_ci COMMENT 'VoiceNote Object. Message is a Video Note, information about the Video Note',
  `contact` text COLLATE utf8_unicode_ci COMMENT 'Contact object. Message is a shared contact, information about the contact',
  `location` text COLLATE utf8_unicode_ci COMMENT 'Location object. Message is a shared location, information about the location',
  `venue` text COLLATE utf8_unicode_ci COMMENT 'Venue object. Message is a Venue, information about the Venue',
  `caption` text COLLATE utf8_unicode_ci COMMENT 'For message with caption, the actual UTF-8 text of the caption',
  `new_chat_members` text COLLATE utf8_unicode_ci COMMENT 'List of unique user identifiers, new member(s) were added to the group, information about them (one of these members may be the bot itself)',
  `left_chat_member` bigint(20) DEFAULT NULL COMMENT 'Unique user identifier, a member was removed from the group, information about them (this member may be the bot itself)',
  `new_chat_title` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'A chat title was changed to this value',
  `new_chat_photo` text COLLATE utf8_unicode_ci COMMENT 'Array of PhotoSize objects. A chat photo was change to this value',
  `delete_chat_photo` tinyint(1) DEFAULT '0' COMMENT 'Informs that the chat photo was deleted',
  `group_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the group has been created',
  `supergroup_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the supergroup has been created',
  `channel_chat_created` tinyint(1) DEFAULT '0' COMMENT 'Informs that the channel chat has been created',
  `migrate_to_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate to chat identifier. The group has been migrated to a supergroup with the specified identifier',
  `migrate_from_chat_id` bigint(20) DEFAULT NULL COMMENT 'Migrate from chat identifier. The supergroup has been migrated from a group with the specified identifier',
  `pinned_message` text COLLATE utf8_unicode_ci COMMENT 'Message object. Specified message was pinned',
  PRIMARY KEY (`chat_id`,`id`),
  KEY `user_id` (`user_id`),
  KEY `forward_from` (`forward_from`),
  KEY `forward_from_chat` (`forward_from_chat`),
  KEY `reply_to_chat` (`reply_to_chat`),
  KEY `reply_to_message` (`reply_to_message`),
  KEY `left_chat_member` (`left_chat_member`),
  KEY `migrate_from_chat_id` (`migrate_from_chat_id`),
  KEY `migrate_to_chat_id` (`migrate_to_chat_id`),
  KEY `reply_to_chat_2` (`reply_to_chat`,`reply_to_message`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_message` VALUES ('399679617','4','399679617','2018-01-18 21:48:58',NULL,NULL,NULL,NULL,NULL,NULL,'test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_plugin_telegrambot_message` VALUES ('399679617','5','399679617','2018-01-18 21:49:00',NULL,NULL,NULL,NULL,NULL,NULL,'teste',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

### Dump table glpi_plugin_telegrambot_request_limiter

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_request_limiter`;
CREATE TABLE `glpi_plugin_telegrambot_request_limiter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for this entry',
  `chat_id` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique chat identifier',
  `inline_message_id` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Identifier of the sent inline message',
  `method` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Request method',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_telegrambot_telegram_update

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_telegram_update`;
CREATE TABLE `glpi_plugin_telegrambot_telegram_update` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Update''s unique identifier',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Unique chat identifier',
  `message_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Unique message identifier',
  `inline_query_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Unique inline query identifier',
  `chosen_inline_result_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Local chosen inline result identifier',
  `callback_query_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Unique callback query identifier',
  `edited_message_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Local edited message identifier',
  PRIMARY KEY (`id`),
  KEY `message_id` (`chat_id`,`message_id`),
  KEY `inline_query_id` (`inline_query_id`),
  KEY `chosen_inline_result_id` (`chosen_inline_result_id`),
  KEY `callback_query_id` (`callback_query_id`),
  KEY `edited_message_id` (`edited_message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_telegram_update` VALUES ('874707977','399679617','4',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_plugin_telegrambot_telegram_update` VALUES ('874707978','399679617','5',NULL,NULL,NULL,NULL);

### Dump table glpi_plugin_telegrambot_user

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_user`;
CREATE TABLE `glpi_plugin_telegrambot_user` (
  `id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Unique user identifier',
  `is_bot` tinyint(1) DEFAULT '0' COMMENT 'True if this user is a bot',
  `first_name` char(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'User''s first name',
  `last_name` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'User''s last name',
  `username` char(191) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'User''s username',
  `language_code` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'User''s system language',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date creation',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Entry date update',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_user` VALUES ('399679617','0','Eduardo','Fraga','eduardofraga','en-US','2018-01-18 21:48:58','2018-01-18 21:49:00');

### Dump table glpi_plugin_telegrambot_user_chat

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_user_chat`;
CREATE TABLE `glpi_plugin_telegrambot_user_chat` (
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Unique user identifier',
  `chat_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Unique user or chat identifier',
  PRIMARY KEY (`user_id`,`chat_id`),
  KEY `chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_user_chat` VALUES ('399679617','399679617');

### Dump table glpi_plugin_telegrambot_users

DROP TABLE IF EXISTS `glpi_plugin_telegrambot_users`;
CREATE TABLE `glpi_plugin_telegrambot_users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_telegrambot_users` VALUES ('6','eduardofraga');

### Dump table glpi_plugins

DROP TABLE IF EXISTS `glpi_plugins`;
CREATE TABLE `glpi_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homepage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`directory`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugins` VALUES ('1','ocsinventoryng','OCS Inventory NG','1.4.3','4','Gilles Dubois, Remi Collet, Nelly Mahu-Lasson, David Durieux, Xavier Caillaud, Walid Nouh, Arthur Jaouen','https://github.com/pluginsGLPI/ocsinventoryng','GPLv2+');
INSERT INTO `glpi_plugins` VALUES ('2','telegrambot','TelegramBot','2.0.0','4','<a href=\"http://trulymanager.com\" target=\"_blank\">Truly Systems</a>','https://github.com/pluginsGLPI/telegrambot','GPLv2+');

### Dump table glpi_plugs

DROP TABLE IF EXISTS `glpi_plugs`;
CREATE TABLE `glpi_plugs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugs` VALUES ('1','C13',NULL,NULL,NULL);
INSERT INTO `glpi_plugs` VALUES ('2','C15',NULL,NULL,NULL);
INSERT INTO `glpi_plugs` VALUES ('3','C19',NULL,NULL,NULL);

### Dump table glpi_printermodels

DROP TABLE IF EXISTS `glpi_printermodels`;
CREATE TABLE `glpi_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_printermodels` VALUES ('1','KM2030','','2030','2017-12-07 10:17:56','2017-12-07 10:17:56');

### Dump table glpi_printers

DROP TABLE IF EXISTS `glpi_printers`;
CREATE TABLE `glpi_printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_serial` tinyint(1) NOT NULL DEFAULT '0',
  `have_parallel` tinyint(1) NOT NULL DEFAULT '0',
  `have_usb` tinyint(1) NOT NULL DEFAULT '0',
  `have_wifi` tinyint(1) NOT NULL DEFAULT '0',
  `have_ethernet` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `memory_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `printertypes_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `init_pages_counter` int(11) NOT NULL DEFAULT '0',
  `last_pages_counter` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `printermodels_id` (`printermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `printertypes_id` (`printertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `last_pages_counter` (`last_pages_counter`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_printers` VALUES ('1','0','0','&lt;IMP-\\Y-###&gt;','2017-12-07 10:18:34','','','5','0','','&lt;###&gt;','0','0','0','0','1','','128','1','0','0','1','1','7','0','0','1','Kyocera KM2030','1000','1599','0','0','1','0.0000','0','2017-12-07 10:18:05');
INSERT INTO `glpi_printers` VALUES ('2','0','0','IMP-2017-001','2017-12-07 10:22:28','','','5','0','','001','0','0','0','0','1','','128','1','0','1','1','1','7','1','0','0','Kyocera KM2030','1000','1599','0','0','1','0.0000','0','2017-12-07 10:18:58');

### Dump table glpi_printertypes

DROP TABLE IF EXISTS `glpi_printertypes`;
CREATE TABLE `glpi_printertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_printertypes` VALUES ('1','Impressora','','2017-12-07 10:17:29','2017-12-07 10:17:29');

### Dump table glpi_problemcosts

DROP TABLE IF EXISTS `glpi_problemcosts`;
CREATE TABLE `glpi_problemcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `problems_id` (`problems_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems

DROP TABLE IF EXISTS `glpi_problems`;
CREATE TABLE `glpi_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `time_to_resolve` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `causecontent` longtext COLLATE utf8_unicode_ci,
  `symptomcontent` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_suppliers

DROP TABLE IF EXISTS `glpi_problems_suppliers`;
CREATE TABLE `glpi_problems_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_tickets

DROP TABLE IF EXISTS `glpi_problems_tickets`;
CREATE TABLE `glpi_problems_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_users

DROP TABLE IF EXISTS `glpi_problems_users`;
CREATE TABLE `glpi_problems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemtasks

DROP TABLE IF EXISTS `glpi_problemtasks`;
CREATE TABLE `glpi_problemtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `problems_id` (`problems_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `state` (`state`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profilerights

DROP TABLE IF EXISTS `glpi_profilerights`;
CREATE TABLE `glpi_profilerights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rights` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`profiles_id`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profilerights` VALUES ('1','1','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('2','1','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('3','1','software','0');
INSERT INTO `glpi_profilerights` VALUES ('4','1','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('5','1','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('6','1','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('7','1','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('8','1','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('9','1','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('10','1','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('12','1','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('13','1','document','0');
INSERT INTO `glpi_profilerights` VALUES ('14','1','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('15','1','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('16','1','knowbase','10240');
INSERT INTO `glpi_profilerights` VALUES ('20','1','reservation','1024');
INSERT INTO `glpi_profilerights` VALUES ('21','1','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('22','1','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('24','1','device','0');
INSERT INTO `glpi_profilerights` VALUES ('25','1','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('26','1','link','0');
INSERT INTO `glpi_profilerights` VALUES ('27','1','config','0');
INSERT INTO `glpi_profilerights` VALUES ('29','1','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('30','1','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('31','1','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('32','1','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('33','1','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('36','1','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('37','1','user','0');
INSERT INTO `glpi_profilerights` VALUES ('39','1','group','0');
INSERT INTO `glpi_profilerights` VALUES ('40','1','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('41','1','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('42','1','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('43','1','reminder_public','1');
INSERT INTO `glpi_profilerights` VALUES ('44','1','rssfeed_public','1');
INSERT INTO `glpi_profilerights` VALUES ('45','1','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('46','1','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('47','1','ticket','131077');
INSERT INTO `glpi_profilerights` VALUES ('51','1','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('52','1','task','1');
INSERT INTO `glpi_profilerights` VALUES ('64','1','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('67','1','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('68','1','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('70','1','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('71','1','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('72','1','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('73','1','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('75','1','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('76','1','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('79','1','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('80','1','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('81','1','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('84','1','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('85','1','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('89','1','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('90','1','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('91','1','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('94','1','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('95','2','computer','33');
INSERT INTO `glpi_profilerights` VALUES ('96','2','monitor','33');
INSERT INTO `glpi_profilerights` VALUES ('97','2','software','33');
INSERT INTO `glpi_profilerights` VALUES ('98','2','networking','33');
INSERT INTO `glpi_profilerights` VALUES ('99','2','internet','1');
INSERT INTO `glpi_profilerights` VALUES ('100','2','printer','33');
INSERT INTO `glpi_profilerights` VALUES ('101','2','peripheral','33');
INSERT INTO `glpi_profilerights` VALUES ('102','2','cartridge','33');
INSERT INTO `glpi_profilerights` VALUES ('103','2','consumable','33');
INSERT INTO `glpi_profilerights` VALUES ('104','2','phone','33');
INSERT INTO `glpi_profilerights` VALUES ('106','2','contact_enterprise','33');
INSERT INTO `glpi_profilerights` VALUES ('107','2','document','33');
INSERT INTO `glpi_profilerights` VALUES ('108','2','contract','33');
INSERT INTO `glpi_profilerights` VALUES ('109','2','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('110','2','knowbase','10241');
INSERT INTO `glpi_profilerights` VALUES ('114','2','reservation','1025');
INSERT INTO `glpi_profilerights` VALUES ('115','2','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('116','2','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('118','2','device','0');
INSERT INTO `glpi_profilerights` VALUES ('119','2','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('120','2','link','1');
INSERT INTO `glpi_profilerights` VALUES ('121','2','config','0');
INSERT INTO `glpi_profilerights` VALUES ('123','2','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('124','2','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('125','2','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('126','2','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('127','2','search_config','1055');
INSERT INTO `glpi_profilerights` VALUES ('130','2','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('131','2','user','2049');
INSERT INTO `glpi_profilerights` VALUES ('133','2','group','1');
INSERT INTO `glpi_profilerights` VALUES ('134','2','entity','32');
INSERT INTO `glpi_profilerights` VALUES ('135','2','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('136','2','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('137','2','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('138','2','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('139','2','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('140','2','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('141','2','ticket','168989');
INSERT INTO `glpi_profilerights` VALUES ('145','2','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('146','2','task','1');
INSERT INTO `glpi_profilerights` VALUES ('158','2','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('161','2','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('162','2','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('164','2','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('165','2','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('166','2','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('167','2','budget','33');
INSERT INTO `glpi_profilerights` VALUES ('169','2','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('170','2','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('173','2','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('174','2','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('175','2','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('179','2','problem','1057');
INSERT INTO `glpi_profilerights` VALUES ('183','2','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('184','2','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('185','2','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('188','2','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('189','3','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('190','3','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('191','3','software','127');
INSERT INTO `glpi_profilerights` VALUES ('192','3','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('193','3','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('194','3','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('195','3','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('196','3','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('197','3','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('198','3','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('200','3','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('201','3','document','127');
INSERT INTO `glpi_profilerights` VALUES ('202','3','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('203','3','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('204','3','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('208','3','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('209','3','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('210','3','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('212','3','device','31');
INSERT INTO `glpi_profilerights` VALUES ('213','3','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('214','3','link','31');
INSERT INTO `glpi_profilerights` VALUES ('215','3','config','0');
INSERT INTO `glpi_profilerights` VALUES ('217','3','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('218','3','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('219','3','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('220','3','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('221','3','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('224','3','profile','1');
INSERT INTO `glpi_profilerights` VALUES ('225','3','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('227','3','group','31');
INSERT INTO `glpi_profilerights` VALUES ('228','3','entity','96');
INSERT INTO `glpi_profilerights` VALUES ('229','3','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('230','3','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('231','3','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('232','3','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('233','3','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('234','3','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('235','3','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('239','3','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('240','3','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('252','3','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('255','3','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('256','3','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('258','3','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('259','3','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('260','3','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('261','3','budget','127');
INSERT INTO `glpi_profilerights` VALUES ('263','3','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('264','3','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('267','3','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('268','3','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('269','3','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('273','3','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('277','3','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('278','3','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('279','3','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('282','3','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('283','4','computer','255');
INSERT INTO `glpi_profilerights` VALUES ('284','4','monitor','255');
INSERT INTO `glpi_profilerights` VALUES ('285','4','software','255');
INSERT INTO `glpi_profilerights` VALUES ('286','4','networking','255');
INSERT INTO `glpi_profilerights` VALUES ('287','4','internet','159');
INSERT INTO `glpi_profilerights` VALUES ('288','4','printer','255');
INSERT INTO `glpi_profilerights` VALUES ('289','4','peripheral','255');
INSERT INTO `glpi_profilerights` VALUES ('290','4','cartridge','255');
INSERT INTO `glpi_profilerights` VALUES ('291','4','consumable','255');
INSERT INTO `glpi_profilerights` VALUES ('292','4','phone','255');
INSERT INTO `glpi_profilerights` VALUES ('294','4','contact_enterprise','255');
INSERT INTO `glpi_profilerights` VALUES ('295','4','document','255');
INSERT INTO `glpi_profilerights` VALUES ('296','4','contract','255');
INSERT INTO `glpi_profilerights` VALUES ('297','4','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('298','4','knowbase','15519');
INSERT INTO `glpi_profilerights` VALUES ('302','4','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('303','4','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('304','4','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('306','4','device','31');
INSERT INTO `glpi_profilerights` VALUES ('307','4','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('308','4','link','159');
INSERT INTO `glpi_profilerights` VALUES ('309','4','config','31');
INSERT INTO `glpi_profilerights` VALUES ('311','4','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('312','4','rule_import','31');
INSERT INTO `glpi_profilerights` VALUES ('313','4','rule_ldap','31');
INSERT INTO `glpi_profilerights` VALUES ('314','4','rule_softwarecategories','31');
INSERT INTO `glpi_profilerights` VALUES ('315','4','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('318','4','profile','159');
INSERT INTO `glpi_profilerights` VALUES ('319','4','user','7327');
INSERT INTO `glpi_profilerights` VALUES ('321','4','group','159');
INSERT INTO `glpi_profilerights` VALUES ('322','4','entity','3327');
INSERT INTO `glpi_profilerights` VALUES ('323','4','transfer','31');
INSERT INTO `glpi_profilerights` VALUES ('324','4','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('325','4','reminder_public','159');
INSERT INTO `glpi_profilerights` VALUES ('326','4','rssfeed_public','159');
INSERT INTO `glpi_profilerights` VALUES ('327','4','bookmark_public','31');
INSERT INTO `glpi_profilerights` VALUES ('328','4','backup','1055');
INSERT INTO `glpi_profilerights` VALUES ('329','4','ticket','259231');
INSERT INTO `glpi_profilerights` VALUES ('333','4','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('334','4','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('346','4','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('349','4','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('350','4','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('352','4','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('353','4','rule_dictionnary_software','31');
INSERT INTO `glpi_profilerights` VALUES ('354','4','rule_dictionnary_dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('355','4','budget','255');
INSERT INTO `glpi_profilerights` VALUES ('357','4','notification','31');
INSERT INTO `glpi_profilerights` VALUES ('358','4','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('361','4','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('362','4','slm','31');
INSERT INTO `glpi_profilerights` VALUES ('363','4','rule_dictionnary_printer','31');
INSERT INTO `glpi_profilerights` VALUES ('367','4','problem','1279');
INSERT INTO `glpi_profilerights` VALUES ('371','4','tickettemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('372','4','ticketrecurrent','31');
INSERT INTO `glpi_profilerights` VALUES ('373','4','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('376','4','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('377','5','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('378','5','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('379','5','software','0');
INSERT INTO `glpi_profilerights` VALUES ('380','5','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('381','5','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('382','5','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('383','5','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('384','5','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('385','5','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('386','5','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('388','5','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('389','5','document','0');
INSERT INTO `glpi_profilerights` VALUES ('390','5','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('391','5','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('392','5','knowbase','8192');
INSERT INTO `glpi_profilerights` VALUES ('396','5','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('397','5','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('398','5','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('400','5','device','0');
INSERT INTO `glpi_profilerights` VALUES ('401','5','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('402','5','link','0');
INSERT INTO `glpi_profilerights` VALUES ('403','5','config','0');
INSERT INTO `glpi_profilerights` VALUES ('405','5','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('406','5','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('407','5','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('408','5','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('409','5','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('412','5','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('413','5','user','1025');
INSERT INTO `glpi_profilerights` VALUES ('415','5','group','0');
INSERT INTO `glpi_profilerights` VALUES ('416','5','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('417','5','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('418','5','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('419','5','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('420','5','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('421','5','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('422','5','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('423','5','ticket','140295');
INSERT INTO `glpi_profilerights` VALUES ('427','5','followup','12295');
INSERT INTO `glpi_profilerights` VALUES ('428','5','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('440','5','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('443','5','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('444','5','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('446','5','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('447','5','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('448','5','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('449','5','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('451','5','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('452','5','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('455','5','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('456','5','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('457','5','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('461','5','problem','1024');
INSERT INTO `glpi_profilerights` VALUES ('465','5','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('466','5','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('467','5','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('470','5','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('471','6','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('472','6','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('473','6','software','127');
INSERT INTO `glpi_profilerights` VALUES ('474','6','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('475','6','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('476','6','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('477','6','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('478','6','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('479','6','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('480','6','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('482','6','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('483','6','document','127');
INSERT INTO `glpi_profilerights` VALUES ('484','6','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('485','6','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('486','6','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('490','6','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('491','6','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('492','6','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('494','6','device','0');
INSERT INTO `glpi_profilerights` VALUES ('495','6','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('496','6','link','0');
INSERT INTO `glpi_profilerights` VALUES ('497','6','config','0');
INSERT INTO `glpi_profilerights` VALUES ('499','6','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('500','6','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('501','6','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('502','6','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('503','6','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('506','6','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('507','6','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('509','6','group','1');
INSERT INTO `glpi_profilerights` VALUES ('510','6','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('511','6','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('512','6','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('513','6','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('514','6','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('515','6','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('516','6','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('517','6','ticket','168967');
INSERT INTO `glpi_profilerights` VALUES ('521','6','followup','13319');
INSERT INTO `glpi_profilerights` VALUES ('522','6','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('534','6','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('537','6','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('538','6','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('540','6','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('541','6','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('542','6','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('543','6','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('545','6','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('546','6','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('549','6','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('550','6','slm','1');
INSERT INTO `glpi_profilerights` VALUES ('551','6','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('555','6','problem','1121');
INSERT INTO `glpi_profilerights` VALUES ('559','6','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('560','6','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('561','6','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('564','6','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('565','7','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('566','7','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('567','7','software','127');
INSERT INTO `glpi_profilerights` VALUES ('568','7','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('569','7','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('570','7','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('571','7','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('572','7','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('573','7','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('574','7','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('576','7','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('577','7','document','127');
INSERT INTO `glpi_profilerights` VALUES ('578','7','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('579','7','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('580','7','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('584','7','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('585','7','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('586','7','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('588','7','device','0');
INSERT INTO `glpi_profilerights` VALUES ('589','7','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('590','7','link','0');
INSERT INTO `glpi_profilerights` VALUES ('591','7','config','0');
INSERT INTO `glpi_profilerights` VALUES ('593','7','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('594','7','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('595','7','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('596','7','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('597','7','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('600','7','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('601','7','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('603','7','group','1');
INSERT INTO `glpi_profilerights` VALUES ('604','7','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('605','7','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('606','7','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('607','7','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('608','7','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('609','7','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('610','7','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('611','7','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('615','7','followup','13335');
INSERT INTO `glpi_profilerights` VALUES ('616','7','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('628','7','planning','2049');
INSERT INTO `glpi_profilerights` VALUES ('631','7','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('632','7','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('634','7','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('635','7','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('636','7','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('637','7','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('639','7','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('640','7','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('643','7','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('644','7','slm','31');
INSERT INTO `glpi_profilerights` VALUES ('645','7','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('649','7','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('653','7','tickettemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('654','7','ticketrecurrent','31');
INSERT INTO `glpi_profilerights` VALUES ('655','7','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('658','7','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('659','1','change','0');
INSERT INTO `glpi_profilerights` VALUES ('660','2','change','1057');
INSERT INTO `glpi_profilerights` VALUES ('661','3','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('662','4','change','1279');
INSERT INTO `glpi_profilerights` VALUES ('663','5','change','1054');
INSERT INTO `glpi_profilerights` VALUES ('664','6','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('665','7','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('666','1','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('667','2','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('668','3','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('669','4','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('670','5','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('671','6','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('672','7','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('673','1','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('674','2','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('675','3','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('676','4','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('677','5','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('678','6','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('679','7','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('680','1','location','0');
INSERT INTO `glpi_profilerights` VALUES ('681','2','location','0');
INSERT INTO `glpi_profilerights` VALUES ('682','3','location','31');
INSERT INTO `glpi_profilerights` VALUES ('683','4','location','31');
INSERT INTO `glpi_profilerights` VALUES ('684','5','location','0');
INSERT INTO `glpi_profilerights` VALUES ('685','6','location','0');
INSERT INTO `glpi_profilerights` VALUES ('686','7','location','31');
INSERT INTO `glpi_profilerights` VALUES ('687','1','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('688','2','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('689','3','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('690','4','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('691','5','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('692','6','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('693','7','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('694','1','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('695','2','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('696','3','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('697','4','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('698','5','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('699','6','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('700','7','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('701','1','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('702','2','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('703','3','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('704','4','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('705','5','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('706','6','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('707','7','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('708','1','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('709','2','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('710','3','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('711','4','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('712','5','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('713','6','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('714','7','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('715','1','state','0');
INSERT INTO `glpi_profilerights` VALUES ('716','2','state','0');
INSERT INTO `glpi_profilerights` VALUES ('717','3','state','31');
INSERT INTO `glpi_profilerights` VALUES ('718','4','state','31');
INSERT INTO `glpi_profilerights` VALUES ('719','5','state','0');
INSERT INTO `glpi_profilerights` VALUES ('720','6','state','0');
INSERT INTO `glpi_profilerights` VALUES ('721','7','state','31');
INSERT INTO `glpi_profilerights` VALUES ('722','1','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('723','2','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('724','3','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('725','4','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('726','5','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('727','6','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('728','7','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('729','1','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('730','2','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('731','3','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('732','4','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('733','5','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('734','6','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('735','7','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('736','1','project','0');
INSERT INTO `glpi_profilerights` VALUES ('737','2','project','1025');
INSERT INTO `glpi_profilerights` VALUES ('738','3','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('739','4','project','1279');
INSERT INTO `glpi_profilerights` VALUES ('740','5','project','1150');
INSERT INTO `glpi_profilerights` VALUES ('741','6','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('742','7','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('743','1','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('744','2','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('745','3','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('746','4','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('747','5','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('748','6','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('749','7','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('750','8','backup','1');
INSERT INTO `glpi_profilerights` VALUES ('751','8','bookmark_public','1');
INSERT INTO `glpi_profilerights` VALUES ('752','8','budget','161');
INSERT INTO `glpi_profilerights` VALUES ('753','8','calendar','1');
INSERT INTO `glpi_profilerights` VALUES ('754','8','cartridge','161');
INSERT INTO `glpi_profilerights` VALUES ('755','8','change','1185');
INSERT INTO `glpi_profilerights` VALUES ('756','8','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('757','8','computer','161');
INSERT INTO `glpi_profilerights` VALUES ('758','8','config','1');
INSERT INTO `glpi_profilerights` VALUES ('759','8','consumable','161');
INSERT INTO `glpi_profilerights` VALUES ('760','8','contact_enterprise','161');
INSERT INTO `glpi_profilerights` VALUES ('761','8','contract','161');
INSERT INTO `glpi_profilerights` VALUES ('762','8','device','0');
INSERT INTO `glpi_profilerights` VALUES ('763','8','document','161');
INSERT INTO `glpi_profilerights` VALUES ('764','8','domain','1');
INSERT INTO `glpi_profilerights` VALUES ('765','8','dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('766','8','entity','1185');
INSERT INTO `glpi_profilerights` VALUES ('767','8','followup','8193');
INSERT INTO `glpi_profilerights` VALUES ('768','8','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('769','8','group','129');
INSERT INTO `glpi_profilerights` VALUES ('770','8','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('771','8','internet','129');
INSERT INTO `glpi_profilerights` VALUES ('772','8','itilcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('773','8','knowbase','10369');
INSERT INTO `glpi_profilerights` VALUES ('774','8','knowbasecategory','1');
INSERT INTO `glpi_profilerights` VALUES ('775','8','link','129');
INSERT INTO `glpi_profilerights` VALUES ('776','8','location','1');
INSERT INTO `glpi_profilerights` VALUES ('777','8','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('778','8','monitor','161');
INSERT INTO `glpi_profilerights` VALUES ('779','8','netpoint','1');
INSERT INTO `glpi_profilerights` VALUES ('780','8','networking','161');
INSERT INTO `glpi_profilerights` VALUES ('781','8','notification','1');
INSERT INTO `glpi_profilerights` VALUES ('782','8','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('783','8','peripheral','161');
INSERT INTO `glpi_profilerights` VALUES ('784','8','phone','161');
INSERT INTO `glpi_profilerights` VALUES ('785','8','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('786','8','printer','161');
INSERT INTO `glpi_profilerights` VALUES ('787','8','problem','1185');
INSERT INTO `glpi_profilerights` VALUES ('788','8','profile','129');
INSERT INTO `glpi_profilerights` VALUES ('789','8','project','1185');
INSERT INTO `glpi_profilerights` VALUES ('790','8','projecttask','1');
INSERT INTO `glpi_profilerights` VALUES ('791','8','queuednotification','1');
INSERT INTO `glpi_profilerights` VALUES ('792','8','reminder_public','129');
INSERT INTO `glpi_profilerights` VALUES ('793','8','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('794','8','reservation','1');
INSERT INTO `glpi_profilerights` VALUES ('795','8','rssfeed_public','129');
INSERT INTO `glpi_profilerights` VALUES ('796','8','rule_dictionnary_dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('797','8','rule_dictionnary_printer','1');
INSERT INTO `glpi_profilerights` VALUES ('798','8','rule_dictionnary_software','1');
INSERT INTO `glpi_profilerights` VALUES ('799','8','rule_import','1');
INSERT INTO `glpi_profilerights` VALUES ('800','8','rule_ldap','1');
INSERT INTO `glpi_profilerights` VALUES ('801','8','rule_mailcollector','1');
INSERT INTO `glpi_profilerights` VALUES ('802','8','rule_softwarecategories','1');
INSERT INTO `glpi_profilerights` VALUES ('803','8','rule_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('804','8','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('805','8','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('806','8','slm','1');
INSERT INTO `glpi_profilerights` VALUES ('807','8','software','161');
INSERT INTO `glpi_profilerights` VALUES ('808','8','solutiontemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('809','8','state','1');
INSERT INTO `glpi_profilerights` VALUES ('810','8','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('811','8','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('812','8','taskcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('813','8','ticket','138369');
INSERT INTO `glpi_profilerights` VALUES ('814','8','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('815','8','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('816','8','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('817','8','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('818','8','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('819','8','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('820','8','user','2177');
INSERT INTO `glpi_profilerights` VALUES ('821','1','license','0');
INSERT INTO `glpi_profilerights` VALUES ('822','2','license','33');
INSERT INTO `glpi_profilerights` VALUES ('823','3','license','127');
INSERT INTO `glpi_profilerights` VALUES ('824','4','license','255');
INSERT INTO `glpi_profilerights` VALUES ('825','5','license','0');
INSERT INTO `glpi_profilerights` VALUES ('826','6','license','127');
INSERT INTO `glpi_profilerights` VALUES ('827','7','license','127');
INSERT INTO `glpi_profilerights` VALUES ('828','8','license','161');
INSERT INTO `glpi_profilerights` VALUES ('829','1','line','0');
INSERT INTO `glpi_profilerights` VALUES ('830','2','line','33');
INSERT INTO `glpi_profilerights` VALUES ('831','3','line','127');
INSERT INTO `glpi_profilerights` VALUES ('832','4','line','255');
INSERT INTO `glpi_profilerights` VALUES ('833','5','line','0');
INSERT INTO `glpi_profilerights` VALUES ('834','6','line','127');
INSERT INTO `glpi_profilerights` VALUES ('835','7','line','127');
INSERT INTO `glpi_profilerights` VALUES ('836','8','line','161');
INSERT INTO `glpi_profilerights` VALUES ('837','1','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('838','2','lineoperator','33');
INSERT INTO `glpi_profilerights` VALUES ('839','3','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('840','4','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('841','5','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('842','6','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('843','7','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('844','8','lineoperator','1');
INSERT INTO `glpi_profilerights` VALUES ('846','2','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('847','3','devicesimcard_pinpuk','3');
INSERT INTO `glpi_profilerights` VALUES ('848','4','devicesimcard_pinpuk','3');
INSERT INTO `glpi_profilerights` VALUES ('849','5','devicesimcard_pinpuk','1');
INSERT INTO `glpi_profilerights` VALUES ('850','6','devicesimcard_pinpuk','3');
INSERT INTO `glpi_profilerights` VALUES ('851','7','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('852','8','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('853','1','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('854','2','certificate','33');
INSERT INTO `glpi_profilerights` VALUES ('855','3','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('856','4','certificate','255');
INSERT INTO `glpi_profilerights` VALUES ('857','5','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('858','6','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('859','7','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('860','8','certificate','161');
INSERT INTO `glpi_profilerights` VALUES ('861','1','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('862','2','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('863','3','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('865','5','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('866','6','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('867','7','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('868','8','plugin_ocsinventoryng','0');
INSERT INTO `glpi_profilerights` VALUES ('869','1','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('870','2','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('871','3','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('873','5','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('874','6','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('875','7','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('876','8','plugin_ocsinventoryng_sync','0');
INSERT INTO `glpi_profilerights` VALUES ('877','1','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('878','2','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('879','3','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('881','5','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('882','6','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('883','7','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('884','8','plugin_ocsinventoryng_view','0');
INSERT INTO `glpi_profilerights` VALUES ('885','1','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('886','2','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('887','3','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('889','5','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('890','6','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('891','7','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('892','8','plugin_ocsinventoryng_clean','0');
INSERT INTO `glpi_profilerights` VALUES ('893','1','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('894','2','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('895','3','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('897','5','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('898','6','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('899','7','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('900','8','plugin_ocsinventoryng_import','0');
INSERT INTO `glpi_profilerights` VALUES ('901','1','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('902','2','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('903','3','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('905','5','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('906','6','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('907','7','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('908','8','plugin_ocsinventoryng_link','0');
INSERT INTO `glpi_profilerights` VALUES ('909','1','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('910','2','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('911','3','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('913','5','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('914','6','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('915','7','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('916','8','plugin_ocsinventoryng_rule','0');
INSERT INTO `glpi_profilerights` VALUES ('917','4','plugin_ocsinventoryng','23');
INSERT INTO `glpi_profilerights` VALUES ('918','4','plugin_ocsinventoryng_sync','3');
INSERT INTO `glpi_profilerights` VALUES ('919','4','plugin_ocsinventoryng_view','1');
INSERT INTO `glpi_profilerights` VALUES ('920','4','plugin_ocsinventoryng_import','3');
INSERT INTO `glpi_profilerights` VALUES ('921','4','plugin_ocsinventoryng_link','3');
INSERT INTO `glpi_profilerights` VALUES ('922','4','plugin_ocsinventoryng_clean','3');
INSERT INTO `glpi_profilerights` VALUES ('923','4','plugin_ocsinventoryng_rule','3');
INSERT INTO `glpi_profilerights` VALUES ('924','1','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('925','2','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('926','3','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('927','4','datacenter','255');
INSERT INTO `glpi_profilerights` VALUES ('928','5','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('929','6','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('930','7','datacenter','0');
INSERT INTO `glpi_profilerights` VALUES ('931','8','datacenter','255');

### Dump table glpi_profiles

DROP TABLE IF EXISTS `glpi_profiles`;
CREATE TABLE `glpi_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'helpdesk',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `helpdesk_hardware` int(11) NOT NULL DEFAULT '0',
  `helpdesk_item_type` text COLLATE utf8_unicode_ci,
  `ticket_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `problem_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `create_ticket_on_login` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `change_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interface` (`interface`),
  KEY `is_default` (`is_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles` VALUES ('1','Self-Service','helpdesk','1','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('2','Observer','central','0','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('3','Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('4','Super-Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('5','Hotliner','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','1','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('6','Technician','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('7','Supervisor','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('8','Read-Only','central','0','0','[]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},
                       \"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},
                       \"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,'This profile defines read-only access. It is used when objects are locked. It can also be used to give to users rights to unlock objects.','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},
                      \"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                      \"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},
                       \"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},
                       \"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2016-02-08 16:57:46');

### Dump table glpi_profiles_reminders

DROP TABLE IF EXISTS `glpi_profiles_reminders`;
CREATE TABLE `glpi_profiles_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_rssfeeds

DROP TABLE IF EXISTS `glpi_profiles_rssfeeds`;
CREATE TABLE `glpi_profiles_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_users

DROP TABLE IF EXISTS `glpi_profiles_users`;
CREATE TABLE `glpi_profiles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `users_id` (`users_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles_users` VALUES ('2','2','4','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('3','3','1','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('4','4','6','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('5','5','2','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('6','6','1','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('7','0','3','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('11','6','1','2','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('12','7','1','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('13','8','1','0','0','1');
INSERT INTO `glpi_profiles_users` VALUES ('14','9','1','0','0','1');
INSERT INTO `glpi_profiles_users` VALUES ('15','10','1','0','0','1');
INSERT INTO `glpi_profiles_users` VALUES ('16','11','1','0','0','1');
INSERT INTO `glpi_profiles_users` VALUES ('17','12','1','0','0','1');

### Dump table glpi_projectcosts

DROP TABLE IF EXISTS `glpi_projectcosts`;
CREATE TABLE `glpi_projectcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `projects_id` (`projects_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projects

DROP TABLE IF EXISTS `glpi_projects`;
CREATE TABLE `glpi_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttypes_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `show_on_global_gantt` tinyint(1) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `projecttemplates_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttypes_id` (`projecttypes_id`),
  KEY `priority` (`priority`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `show_on_global_gantt` (`show_on_global_gantt`),
  KEY `date_creation` (`date_creation`),
  KEY `projecttemplates_id` (`projecttemplates_id`),
  KEY `is_template` (`is_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectstates

DROP TABLE IF EXISTS `glpi_projectstates`;
CREATE TABLE `glpi_projectstates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_finished` (`is_finished`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projectstates` VALUES ('1','New',NULL,'#06ff00','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('2','Processing',NULL,'#ffb800','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('3','Closed',NULL,'#ff0000','1',NULL,NULL);

### Dump table glpi_projecttasks

DROP TABLE IF EXISTS `glpi_projecttasks`;
CREATE TABLE `glpi_projecttasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  `projecttasktemplates_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `projecttasktemplates_id` (`projecttasktemplates_id`),
  KEY `is_template` (`is_template`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasks_tickets

DROP TABLE IF EXISTS `glpi_projecttasks_tickets`;
CREATE TABLE `glpi_projecttasks_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`projecttasks_id`),
  KEY `projects_id` (`projecttasks_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttaskteams

DROP TABLE IF EXISTS `glpi_projecttaskteams`;
CREATE TABLE `glpi_projecttaskteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projecttasks_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasktemplates

DROP TABLE IF EXISTS `glpi_projecttasktemplates`;
CREATE TABLE `glpi_projecttasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasktypes

DROP TABLE IF EXISTS `glpi_projecttasktypes`;
CREATE TABLE `glpi_projecttasktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectteams

DROP TABLE IF EXISTS `glpi_projectteams`;
CREATE TABLE `glpi_projectteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttypes

DROP TABLE IF EXISTS `glpi_projecttypes`;
CREATE TABLE `glpi_projecttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_queuednotifications

DROP TABLE IF EXISTS `glpi_queuednotifications`;
CREATE TABLE `glpi_queuednotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sent_try` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL,
  `sent_time` datetime DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `sender` text COLLATE utf8_unicode_ci,
  `sendername` text COLLATE utf8_unicode_ci,
  `recipient` text COLLATE utf8_unicode_ci,
  `recipientname` text COLLATE utf8_unicode_ci,
  `replyto` text COLLATE utf8_unicode_ci,
  `replytoname` text COLLATE utf8_unicode_ci,
  `headers` text COLLATE utf8_unicode_ci,
  `body_html` longtext COLLATE utf8_unicode_ci,
  `body_text` longtext COLLATE utf8_unicode_ci,
  `messageid` text COLLATE utf8_unicode_ci,
  `documents` text COLLATE utf8_unicode_ci,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants',
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`,`notificationtemplates_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `entities_id` (`entities_id`),
  KEY `sent_try` (`sent_try`),
  KEY `create_time` (`create_time`),
  KEY `send_time` (`send_time`),
  KEY `sent_time` (`sent_time`),
  KEY `mode` (`mode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_queuednotifications` VALUES ('45','MailCollector','0','20','0','1','0','2018-05-21 14:53:17','2018-05-21 14:53:17','2018-05-21 21:23:39','[GLPI] erros de destinatário','chamados@eftech.com.br','GLPI','chamados@eftech.com.br','GLPI',NULL,NULL,'{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI] erros de destinat&aacute;rio</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<p><br />Nome : chamados@eftech.com.br<br /> Erros de conex&atilde;o : 1<br /><a href=\"http://192.168.56.101/glpi/index.php?redirect=MailCollector_1\">http://192.168.56.101/glpi/index.php?redirect=MailCollector_1</a><br /> </p>
<p></p><br><br>-- 
<br>--<br />
Sistema de Chamados<br />
FAME Consultoria<br />
chamados@fameconsultoria.com.br<br />
<br>Gerado automaticamente pelo GLPI 9.2.1<br><br>

</body></html>','Nome : chamados@eftech.com.br
Erros de conexão : 1
http://192.168.56.101/glpi/index.php?redirect=MailCollector_1

-- 
--
Sistema de Chamados
FAME Consultoria
chamados@fameconsultoria.com.br

Gerado automaticamente pelo GLPI 9.2.1

',NULL,'','mailing');

### Dump table glpi_rackmodels

DROP TABLE IF EXISTS `glpi_rackmodels`;
CREATE TABLE `glpi_rackmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_racks

DROP TABLE IF EXISTS `glpi_racks`;
CREATE TABLE `glpi_racks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rackmodels_id` int(11) DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `racktypes_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `number_units` int(11) DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `dcrooms_id` int(11) NOT NULL DEFAULT '0',
  `room_orientation` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bgcolor` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `max_power` int(11) NOT NULL DEFAULT '0',
  `mesured_power` int(11) NOT NULL DEFAULT '0',
  `max_weight` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `rackmodels_id` (`rackmodels_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `racktypes_id` (`racktypes_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `group_id_tech` (`groups_id_tech`),
  KEY `is_template` (`is_template`),
  KEY `is_deleted` (`is_deleted`),
  KEY `dcrooms_id` (`dcrooms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_racktypes

DROP TABLE IF EXISTS `glpi_racktypes`;
CREATE TABLE `glpi_racktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_registeredids

DROP TABLE IF EXISTS `glpi_registeredids`;
CREATE TABLE `glpi_registeredids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'USB, PCI ...',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `item` (`items_id`,`itemtype`),
  KEY `device_type` (`device_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders

DROP TABLE IF EXISTS `glpi_reminders`;
CREATE TABLE `glpi_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `is_planned` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `begin_view_date` datetime DEFAULT NULL,
  `end_view_date` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `users_id` (`users_id`),
  KEY `is_planned` (`is_planned`),
  KEY `state` (`state`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders_users

DROP TABLE IF EXISTS `glpi_reminders_users`;
CREATE TABLE `glpi_reminders_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_requesttypes

DROP TABLE IF EXISTS `glpi_requesttypes`;
CREATE TABLE `glpi_requesttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_helpdesk_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_followup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mail_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mailfollowup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketheader` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketfollowup` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_helpdesk_default` (`is_helpdesk_default`),
  KEY `is_followup_default` (`is_followup_default`),
  KEY `is_mail_default` (`is_mail_default`),
  KEY `is_mailfollowup_default` (`is_mailfollowup_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_active` (`is_active`),
  KEY `is_ticketheader` (`is_ticketheader`),
  KEY `is_ticketfollowup` (`is_ticketfollowup`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_requesttypes` VALUES ('1','Helpdesk','1','1','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('2','E-Mail','0','0','1','1','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('3','Phone','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('4','Direct','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('5','Written','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('6','Other','0','0','0','0','1','1','1',NULL,NULL,NULL);

### Dump table glpi_reservationitems

DROP TABLE IF EXISTS `glpi_reservationitems`;
CREATE TABLE `glpi_reservationitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reservations

DROP TABLE IF EXISTS `glpi_reservations`;
CREATE TABLE `glpi_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservationitems_id` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `group` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `reservationitems_id` (`reservationitems_id`),
  KEY `users_id` (`users_id`),
  KEY `resagroup` (`reservationitems_id`,`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds

DROP TABLE IF EXISTS `glpi_rssfeeds`;
CREATE TABLE `glpi_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `url` text COLLATE utf8_unicode_ci,
  `refresh_rate` int(11) NOT NULL DEFAULT '86400',
  `max_items` int(11) NOT NULL DEFAULT '20',
  `have_error` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `users_id` (`users_id`),
  KEY `date_mod` (`date_mod`),
  KEY `have_error` (`have_error`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds_users

DROP TABLE IF EXISTS `glpi_rssfeeds_users`;
CREATE TABLE `glpi_rssfeeds_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ruleactions

DROP TABLE IF EXISTS `glpi_ruleactions`;
CREATE TABLE `glpi_ruleactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `field_value` (`field`(50),`value`(50))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ruleactions` VALUES ('2','2','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('3','3','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('4','4','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('5','5','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('6','6','fromitem','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('7','7','fromuser','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('8','8','assign','_import_category','1');
INSERT INTO `glpi_ruleactions` VALUES ('9','9','assign','_groups_id_assign','2');
INSERT INTO `glpi_ruleactions` VALUES ('10','10','assign','_groups_id_assign','3');
INSERT INTO `glpi_ruleactions` VALUES ('11','12','assign','_fusion','0');
INSERT INTO `glpi_ruleactions` VALUES ('12','13','assign','entities_id','0');

### Dump table glpi_rulecriterias

DROP TABLE IF EXISTS `glpi_rulecriterias`;
CREATE TABLE `glpi_rulecriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `condition` (`condition`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulecriterias` VALUES ('2','2','uid','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('3','2','samaccountname','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('4','2','MAIL_EMAIL','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('5','3','subject','6','/.*/');
INSERT INTO `glpi_rulecriterias` VALUES ('6','4','x-auto-response-suppress','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('7','5','auto-submitted','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('8','5','auto-submitted','1','no');
INSERT INTO `glpi_rulecriterias` VALUES ('9','6','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('10','6','items_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('11','7','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('12','7','users_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('13','8','name','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('14','9','itilcategories_id','4','Redes');
INSERT INTO `glpi_rulecriterias` VALUES ('15','10','itilcategories_id','4','Sistemas');
INSERT INTO `glpi_rulecriterias` VALUES ('17','12','serial','10','1');
INSERT INTO `glpi_rulecriterias` VALUES ('18','13','TAG','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('19','13','OCS_SERVER','0','1');

### Dump table glpi_rulerightparameters

DROP TABLE IF EXISTS `glpi_rulerightparameters`;
CREATE TABLE `glpi_rulerightparameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulerightparameters` VALUES ('1','(LDAP)Organization','o','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('2','(LDAP)Common Name','cn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('3','(LDAP)Department Number','departmentnumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('4','(LDAP)Email','mail','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('5','Object Class','objectclass','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('6','(LDAP)User ID','uid','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('7','(LDAP)Telephone Number','phone','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('8','(LDAP)Employee Number','employeenumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('9','(LDAP)Manager','manager','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('10','(LDAP)DistinguishedName','dn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('12','(AD)User ID','samaccountname','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('13','(LDAP) Title','title','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('14','(LDAP) MemberOf','memberof','',NULL,NULL);

### Dump table glpi_rules

DROP TABLE IF EXISTS `glpi_rules`;
CREATE TABLE `glpi_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `sub_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ranking` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `sub_type` (`sub_type`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `condition` (`condition`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rules` VALUES ('2','0','RuleRight','1','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd35745.02608131','0',NULL);
INSERT INTO `glpi_rules` VALUES ('3','0','RuleMailCollector','3','Root','','OR','1',NULL,'2018-01-11 18:46:58','0','500717c8-2bd6e957-53a12b5fd36404.54713349','0',NULL);
INSERT INTO `glpi_rules` VALUES ('4','0','RuleMailCollector','1','Auto-Reply X-Auto-Response-Suppress','Exclude Auto-Reply emails using X-Auto-Response-Suppress header','AND','1',NULL,'2018-01-11 18:46:56','1','500717c8-2bd6e957-53a12b5fd36d97.94503423','0',NULL);
INSERT INTO `glpi_rules` VALUES ('5','0','RuleMailCollector','2','Auto-Reply Auto-Submitted','Exclude Auto-Reply emails using Auto-Submitted header','AND','1',NULL,'2018-01-11 18:46:58','1','500717c8-2bd6e957-53a12b5fd376c2.87642651','0',NULL);
INSERT INTO `glpi_rules` VALUES ('6','0','RuleTicket','1','Ticket location from item','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd37f94.10365341','1',NULL);
INSERT INTO `glpi_rules` VALUES ('7','0','RuleTicket','2','Ticket location from user','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86002585','1',NULL);
INSERT INTO `glpi_rules` VALUES ('8','0','RuleSoftwareCategory','1','Import category from inventory tool','','AND','0','Automatically generated by GLPI 9.2',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86003425','1',NULL);
INSERT INTO `glpi_rules` VALUES ('9','0','RuleTicket','3','Categoria Redes','','AND','1','','2018-01-11 06:40:53','0','17a92ede-d9d62df8-5a5730f14452b9.80445930','2','2018-01-11 06:40:01');
INSERT INTO `glpi_rules` VALUES ('10','0','RuleTicket','4','Categoria Sistemas','','AND','1','','2018-01-11 06:43:37','0','17a92ede-d9d62df8-5a573199e57f77.03452610','3','2018-01-11 06:42:49');
INSERT INTO `glpi_rules` VALUES ('12','0','RuleImportComputer','1','RootComputerOcs','','AND','1','Gerado automaticamente pelo GLPI 140',NULL,'0',NULL,'0',NULL);
INSERT INTO `glpi_rules` VALUES ('13','0','RuleImportEntity','1','RootEntityOcs','','AND','1','Gerado automaticamente pelo GLPI 140',NULL,'1',NULL,'0',NULL);
INSERT INTO `glpi_rules` VALUES ('14','0','RuleRight','2','usuario_desativado','','AND','0','','2018-07-29 08:28:20','0','bc7057ec-d9d62df8-5b5da4d4530450.68564125','0','2018-07-29 08:28:20');

### Dump table glpi_savedsearches

DROP TABLE IF EXISTS `glpi_savedsearches`;
CREATE TABLE `glpi_savedsearches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see SavedSearch:: constants',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  `last_execution_time` int(11) DEFAULT NULL,
  `do_count` tinyint(1) NOT NULL DEFAULT '2' COMMENT 'Do or do not count results on list display; see SavedSearch::COUNT_* constants',
  `last_execution_date` datetime DEFAULT NULL,
  `counter` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `is_private` (`is_private`),
  KEY `is_recursive` (`is_recursive`),
  KEY `last_execution_time` (`last_execution_time`),
  KEY `last_execution_date` (`last_execution_date`),
  KEY `do_count` (`do_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_savedsearches_alerts

DROP TABLE IF EXISTS `glpi_savedsearches_alerts`;
CREATE TABLE `glpi_savedsearches_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `savedsearches_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `operator` tinyint(1) NOT NULL,
  `value` int(11) NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`savedsearches_id`,`operator`,`value`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_savedsearches_users

DROP TABLE IF EXISTS `glpi_savedsearches_users`;
CREATE TABLE `glpi_savedsearches_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `savedsearches_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  KEY `savedsearches_id` (`savedsearches_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevelactions

DROP TABLE IF EXISTS `glpi_slalevelactions`;
CREATE TABLE `glpi_slalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_slalevelactions` VALUES ('1','1','append','_groups_id_assign','1');
INSERT INTO `glpi_slalevelactions` VALUES ('3','2','append','_groups_id_assign','2');
INSERT INTO `glpi_slalevelactions` VALUES ('4','2','assign','olas_tto_id','1');
INSERT INTO `glpi_slalevelactions` VALUES ('5','2','assign','olas_ttr_id','2');

### Dump table glpi_slalevelcriterias

DROP TABLE IF EXISTS `glpi_slalevelcriterias`;
CREATE TABLE `glpi_slalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_slalevelcriterias` VALUES ('1','1','status','0','1');
INSERT INTO `glpi_slalevelcriterias` VALUES ('2','2','status','1','6');
INSERT INTO `glpi_slalevelcriterias` VALUES ('3','2','status','1','5');

### Dump table glpi_slalevels

DROP TABLE IF EXISTS `glpi_slalevels`;
CREATE TABLE `glpi_slalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slas_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `slas_id` (`slas_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_slalevels` VALUES ('1','Escalar para Servicedesk','1','-3000','1','0','1','AND','17a92ede-d9d62df8-5a5a33b8bcdfe8.20151632');
INSERT INTO `glpi_slalevels` VALUES ('2','Escalar para Redes','2','-43200','1','0','1','OR','17a92ede-d9d62df8-5a5a36525f5521.95622566');

### Dump table glpi_slalevels_tickets

DROP TABLE IF EXISTS `glpi_slalevels_tickets`;
CREATE TABLE `glpi_slalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`slalevels_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slas

DROP TABLE IF EXISTS `glpi_slas`;
CREATE TABLE `glpi_slas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slms_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `calendars_id` (`calendars_id`),
  KEY `slms_id` (`slms_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_slas` VALUES ('1','SLA 1hora Aceitar','0','1','1','','1','0','2018-01-13 13:22:01','hour','0','2018-01-13 13:19:20','1');
INSERT INTO `glpi_slas` VALUES ('2','SLA 1dia Solução','0','1','0','','1','0','2018-01-13 13:22:01','day','0','2018-01-13 13:20:00','1');

### Dump table glpi_slms

DROP TABLE IF EXISTS `glpi_slms`;
CREATE TABLE `glpi_slms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `calendars_id` (`calendars_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_slms` VALUES ('1','Default','0','1','','0','2018-01-13 13:22:01','2018-01-13 13:18:26');

### Dump table glpi_softwarecategories

DROP TABLE IF EXISTS `glpi_softwarecategories`;
CREATE TABLE `glpi_softwarecategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `softwarecategories_id` (`softwarecategories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarecategories` VALUES ('1','FUSION',NULL,'0','FUSION','1',NULL,NULL);
INSERT INTO `glpi_softwarecategories` VALUES ('4','Manual','','0','Manual','1','[]',NULL);
INSERT INTO `glpi_softwarecategories` VALUES ('5','OCS','','0','OCS','1','[]',NULL);

### Dump table glpi_softwarelicenses

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
CREATE TABLE `glpi_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `softwareversions_id_buy` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id_use` int(11) NOT NULL DEFAULT '0',
  `expire` date DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `expire` (`expire`),
  KEY `softwareversions_id_buy` (`softwareversions_id_buy`),
  KEY `entities_id` (`entities_id`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  KEY `softwareversions_id_use` (`softwareversions_id_use`),
  KEY `date_mod` (`date_mod`),
  KEY `softwares_id_expire` (`softwares_id`,`expire`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `users_id` (`users_id`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarelicenses` VALUES ('2','2','0','Mozilla Public License Version 2.0','1','0','0','-1','0','Mozilla Public License Version 2.0','','','2','2',NULL,'','2017-12-03 14:24:06','1','2017-12-03 14:21:36','0','1','0','0','0','0','0','0',NULL,'1','5',NULL,NULL);

### Dump table glpi_softwarelicensetypes

DROP TABLE IF EXISTS `glpi_softwarelicensetypes`;
CREATE TABLE `glpi_softwarelicensetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarelicensetypes` VALUES ('1','OEM','',NULL,NULL,'0','0',NULL,NULL,'0','1','OEM');

### Dump table glpi_softwares

DROP TABLE IF EXISTS `glpi_softwares`;
CREATE TABLE `glpi_softwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_update` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '1',
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_update` (`is_update`),
  KEY `softwarecategories_id` (`softwarecategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `softwares_id` (`softwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwares` VALUES ('2','0','0','LibreOffice','','1','5','0','0','0','4','0','0',NULL,'2017-12-03 14:17:33','0','0','0.0000','1','4','1','2017-12-03 14:17:33');

### Dump table glpi_softwareversions

DROP TABLE IF EXISTS `glpi_softwareversions`;
CREATE TABLE `glpi_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `softwares_id` (`softwares_id`),
  KEY `states_id` (`states_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwareversions` VALUES ('2','0','0','2','1','5.4.3','','3','2017-12-03 14:19:06','2017-12-03 14:19:06');

### Dump table glpi_solutiontemplates

DROP TABLE IF EXISTS `glpi_solutiontemplates`;
CREATE TABLE `glpi_solutiontemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontypes

DROP TABLE IF EXISTS `glpi_solutiontypes`;
CREATE TABLE `glpi_solutiontypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ssovariables

DROP TABLE IF EXISTS `glpi_ssovariables`;
CREATE TABLE `glpi_ssovariables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ssovariables` VALUES ('1','HTTP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('2','REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('3','PHP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('4','USERNAME','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('5','REDIRECT_REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('6','HTTP_REMOTE_USER','',NULL,NULL);

### Dump table glpi_states

DROP TABLE IF EXISTS `glpi_states`;
CREATE TABLE `glpi_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_visible_computer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_monitor` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_networkequipment` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_peripheral` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_phone` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_printer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwareversion` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwarelicense` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_line` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_certificate` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_rack` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`states_id`,`name`),
  KEY `name` (`name`),
  KEY `is_visible_computer` (`is_visible_computer`),
  KEY `is_visible_monitor` (`is_visible_monitor`),
  KEY `is_visible_networkequipment` (`is_visible_networkequipment`),
  KEY `is_visible_peripheral` (`is_visible_peripheral`),
  KEY `is_visible_phone` (`is_visible_phone`),
  KEY `is_visible_printer` (`is_visible_printer`),
  KEY `is_visible_softwareversion` (`is_visible_softwareversion`),
  KEY `is_visible_softwarelicense` (`is_visible_softwarelicense`),
  KEY `is_visible_line` (`is_visible_line`),
  KEY `is_visible_certificate` (`is_visible_certificate`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_visible_rack` (`is_visible_rack`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_states` VALUES ('1','Operacional','0','0','','0','Operacional','1','[]',NULL,'1','1','1','1','1','1','1','1','1','1','1','2017-11-29 10:04:37','2017-11-29 10:04:37');
INSERT INTO `glpi_states` VALUES ('2','Disponível','0','0','','0','Disponível','1','[]',NULL,'1','1','1','1','1','1','1','1','1','1','1','2017-11-29 10:04:46','2017-11-29 10:04:46');
INSERT INTO `glpi_states` VALUES ('3','Defeito','0','0','','0','Defeito','1','[]',NULL,'1','1','1','1','1','1','1','1','1','1','1','2017-11-29 10:04:55','2017-11-29 10:04:55');

### Dump table glpi_suppliers

DROP TABLE IF EXISTS `glpi_suppliers`;
CREATE TABLE `glpi_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliertypes_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `suppliertypes_id` (`suppliertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliers_tickets

DROP TABLE IF EXISTS `glpi_suppliers_tickets`;
CREATE TABLE `glpi_suppliers_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliertypes

DROP TABLE IF EXISTS `glpi_suppliertypes`;
CREATE TABLE `glpi_suppliertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_taskcategories

DROP TABLE IF EXISTS `glpi_taskcategories`;
CREATE TABLE `glpi_taskcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tasktemplates

DROP TABLE IF EXISTS `glpi_tasktemplates`;
CREATE TABLE `glpi_tasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_private` (`is_private`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketcosts

DROP TABLE IF EXISTS `glpi_ticketcosts`;
CREATE TABLE `glpi_ticketcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `tickets_id` (`tickets_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketfollowups

DROP TABLE IF EXISTS `glpi_ticketfollowups`;
CREATE TABLE `glpi_ticketfollowups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `requesttypes_id` (`requesttypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ticketfollowups` VALUES ('1','1','2018-01-09 17:21:08','2','0','Verificado a configuração no switch','0','1','2018-01-09 17:21:08','2018-01-09 17:21:08','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('2','1','2018-01-11 06:12:06','2','0','Classificado categoria para Redes &gt; Internet','0','1','2018-01-11 06:12:06','2018-01-11 06:12:06','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('3','1','2018-01-11 06:32:01','2','0','Reabrir','0','1','2018-01-11 06:32:01','2018-01-11 06:32:01','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('4','2','2018-01-11 06:53:21','2','0','Reload do apache','0','1','2018-01-11 06:53:21','2018-01-11 06:53:21','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('5','4','2018-01-13 12:57:58','2','0','Ok configuração realizada, favor conferir. 

','0','1','2018-01-13 12:57:58','2018-01-13 12:57:58','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('6','4','2018-01-13 13:02:05','6','0','OK, confirmo a confiugração

Pode encerrar o chamado. 

--
Eduardo Fraga

(85) 9-8803-7625

eduardo@eftech.com.br
https://www.linkedin.com/pub/carlos-eduardo-fraga-ribeiro/82/a2/690

https://www.eftech.com.br

2018-01-13 13:00 GMT-03:00 GLPI &amp;lt;chamados@eftech.com.br&amp;gt;:

 

','0','2','2018-01-13 13:02:05','2018-01-13 13:02:05','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('7','4','2018-01-13 13:03:00','2','0','Chamado encerrado. ','0','1','2018-01-13 13:03:00','2018-01-13 13:03:00','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('8','4','2018-01-13 13:06:25','2','0','Reabrir','0','1','2018-01-13 13:06:25','2018-01-13 13:06:25','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('9','4','2018-01-13 13:07:45','6','0','OK, confirmo a confiugração

Pode encerrar o chamado. 

--
Eduardo Fraga

(85) 9-8803-7625

eduardo@eftech.com.br
https://www.linkedin.com/pub/carlos-eduardo-fraga-ribeiro/82/a2/690

https://www.eftech.com.br

2018-01-13 13:06 GMT-03:00 GLPI &amp;lt;chamados@eftech.com.br&amp;gt;:

 

','0','2','2018-01-13 13:07:45','2018-01-13 13:07:45','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('10','4','2018-01-13 13:08:35','2','0','Chamado encerrado. ','0','1','2018-01-13 13:08:35','2018-01-13 13:08:35','1');
INSERT INTO `glpi_ticketfollowups` VALUES ('11','7','2018-03-20 07:52:00','2','0','não funcionou','0','1','2018-03-20 07:52:00','2018-03-20 07:52:00','1');

### Dump table glpi_ticketrecurrents

DROP TABLE IF EXISTS `glpi_ticketrecurrents`;
CREATE TABLE `glpi_ticketrecurrents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` datetime DEFAULT NULL,
  `periodicity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT '0',
  `next_creation_date` datetime DEFAULT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `tickettemplates_id` (`tickettemplates_id`),
  KEY `next_creation_date` (`next_creation_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets

DROP TABLE IF EXISTS `glpi_tickets`;
CREATE TABLE `glpi_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `slas_ttr_id` int(11) NOT NULL DEFAULT '0',
  `slas_tto_id` int(11) NOT NULL DEFAULT '0',
  `ttr_slalevels_id` int(11) NOT NULL DEFAULT '0',
  `time_to_resolve` datetime DEFAULT NULL,
  `time_to_own` datetime DEFAULT NULL,
  `begin_waiting_date` datetime DEFAULT NULL,
  `sla_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `ola_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `olas_tto_id` int(11) NOT NULL DEFAULT '0',
  `olas_ttr_id` int(11) NOT NULL DEFAULT '0',
  `ttr_olalevels_id` int(11) NOT NULL DEFAULT '0',
  `internal_time_to_resolve` datetime DEFAULT NULL,
  `internal_time_to_own` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `takeintoaccount_delay_stat` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `request_type` (`requesttypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `global_validation` (`global_validation`),
  KEY `slas_tto_id` (`slas_tto_id`),
  KEY `slas_ttr_id` (`slas_ttr_id`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `time_to_own` (`time_to_own`),
  KEY `olas_tto_id` (`olas_tto_id`),
  KEY `olas_ttr_id` (`olas_ttr_id`),
  KEY `ttr_slalevels_id` (`ttr_slalevels_id`),
  KEY `internal_time_to_resolve` (`internal_time_to_resolve`),
  KEY `internal_time_to_own` (`internal_time_to_own`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `type` (`type`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `name` (`name`),
  KEY `locations_id` (`locations_id`),
  KEY `date_creation` (`date_creation`),
  KEY `ola_waiting_duration` (`ola_waiting_duration`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets` VALUES ('1','0','Não consigo acessar a Internet','2018-01-09 07:40:37','2018-01-11 06:27:25','2018-01-11 06:27:25','2018-01-11 06:32:01','2','6','2','1','Não estou conseguindo conectar no site www.google.com','3','3','3','4','1','1','0','0','0','2018-01-11 07:41:00','2018-01-09 08:10:00',NULL,'0','0','0','0','0',NULL,NULL,'0','168408','168408','235','0','0','1','0','2018-01-09 07:44:32');
INSERT INTO `glpi_tickets` VALUES ('2','0','Sistema de vendas fora do ar','2018-01-11 06:24:15','2018-01-11 06:56:11','2018-01-11 06:56:11','2018-01-11 06:56:11','2','6','2','1','Sistema de vendas fora do ar','3','3','3','6','1','3','0','0','0','2018-01-11 10:24:00','2018-01-11 07:24:00',NULL,'0','0','0','0','0',NULL,NULL,'0','1916','1916','58','0','0','0','100','2018-01-11 06:25:13');
INSERT INTO `glpi_tickets` VALUES ('3','0','TESTE 4','2018-01-11 18:52:14',NULL,NULL,'2018-01-11 18:52:14','0','1','7','2','TESTEEE

kdjdkdj

dkdjkddj

----
Sent using Guerrillamail.com
Block or report abuse: https://www.guerrillamail.com//abuse/?a=Qkl1CAwETKc1jQig9X0XPBfIQISSwA%3D%3D','3','3','3','0','1','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','0','0','0','0','0','2018-01-11 18:52:14');
INSERT INTO `glpi_tickets` VALUES ('4','0','Solicito receber notificações por email','2018-01-13 12:57:00','2018-01-13 13:08:35','2018-01-13 13:08:35','2018-01-13 13:08:35','2','6','6','2','Gostaria de receber notificações por email. 

--
Eduardo Fraga

(85) 9-8803-7625

eduardo@eftech.com.br
https://www.linkedin.com/pub/carlos-eduardo-fraga-ribeiro/82/a2/690

https://www.eftech.com.br','3','3','3','0','1','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','0',NULL,NULL,'247','448','448','58','0','0','0','0','2018-01-13 12:57:00');
INSERT INTO `glpi_tickets` VALUES ('5','0','kdjdkjdkjdkj','2018-01-13 13:22:38',NULL,NULL,'2018-01-13 13:23:34','2','1','2','1','ddkjddkdkjdkjdkjdjd','3','3','3','0','1','1','2','1','0','2018-01-14 13:22:38','2018-01-13 14:22:38',NULL,'0','0','1','2','0','2018-01-14 01:22:38','2018-01-13 13:52:38','0','0','0','41','0','0','0','0','2018-01-13 13:23:19');
INSERT INTO `glpi_tickets` VALUES ('7','0','TESTE SLA 123','2018-01-13 12:51:00',NULL,NULL,'2018-03-20 07:52:00','2','4','3','1','Qualquer coisa 

ldkjdkdj

','3','3','3','0','1','1','2','1','2','2018-01-14 13:46:12','2018-01-13 13:51:00','2018-03-20 07:52:00','0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','81','0','0','0','0','2018-01-13 13:46:12');
INSERT INTO `glpi_tickets` VALUES ('8','0','dkjdkdjd','2018-01-13 13:00:00',NULL,NULL,'2018-01-13 14:31:29','2','1','2','1','dkjdkdjkdkdkdj','3','3','3','0','1','1','2','1','2','2018-01-14 13:00:00','2018-01-13 14:00:00',NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','3573','0','1','0','0','2018-01-13 13:59:33');
INSERT INTO `glpi_tickets` VALUES ('9','0','Teste','2018-01-13 14:01:00',NULL,NULL,'2018-01-13 14:31:29','2','1','2','1','TESTE 6','3','3','3','0','1','1','2','1','2','2018-01-14 14:01:00','2018-01-13 15:01:00',NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','71','0','1','0','0','2018-01-13 14:02:11');
INSERT INTO `glpi_tickets` VALUES ('10','0','dkdkjdkjdkjdkjkdk','2018-01-12 14:06:00',NULL,NULL,'2018-01-13 14:31:29','2','2','2','1','dkdkjdkjdkjdkjkdk','3','3','3','0','1','1','2','1','2','2018-01-13 14:06:00','2018-01-12 15:06:00',NULL,'0','0','1','2','0','2018-01-14 02:04:09','2018-01-13 14:34:09','0','0','0','86288','0','1','0','0','2018-01-13 14:04:08');
INSERT INTO `glpi_tickets` VALUES ('11','0','TESTE SLA','2018-01-13 14:09:06',NULL,NULL,'2018-01-13 14:31:29','3','1','3','1','TESTE SLA','3','3','3','0','1','1','2','1','2','2018-01-14 14:09:06','2018-01-13 15:09:06',NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','0','0','1','0','0','2018-01-13 14:09:06');
INSERT INTO `glpi_tickets` VALUES ('12','0','jkjkjk','2018-01-13 00:00:00',NULL,NULL,'2018-01-13 14:31:29','2','1','2','1','jkjkjk','3','3','3','0','1','1','2','1','2','2018-01-14 14:11:00','2018-01-13 01:00:00',NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','62','0','1','0','0','2018-01-13 14:12:02');
INSERT INTO `glpi_tickets` VALUES ('13','0','TESTE 7','2018-01-13 13:16:00',NULL,NULL,'2018-01-13 14:31:29','2','1','2','1','TESTE 7','3','3','3','0','1','1','2','1','2','2018-01-14 14:16:00','2018-01-13 14:16:00',NULL,'0','0','0','0','0',NULL,NULL,'0','0','0','71','0','1','0','0','2018-01-13 14:17:11');
INSERT INTO `glpi_tickets` VALUES ('14','0','TESTE SLA','2018-01-13 14:00:00',NULL,NULL,'2018-01-18 21:21:59','2','1','2','1','TESTE SLA','3','3','3','0','1','1','2','1','2','2018-01-14 14:00:00','2018-01-13 15:00:00',NULL,'0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','2264','0','0','0','0','2018-01-13 14:37:44');
INSERT INTO `glpi_tickets` VALUES ('15','0','dkdjdkdjkdj','2018-01-13 14:01:00',NULL,NULL,'2018-01-18 21:21:59','2','1','2','1','dkdjdkdjkdj','3','3','3','0','1','1','2','1','2','2018-01-14 14:01:00','2018-01-13 15:01:00',NULL,'0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','2297','0','0','0','0','2018-01-13 14:39:17');
INSERT INTO `glpi_tickets` VALUES ('16','0','teste escalation','2018-01-13 14:40:03',NULL,NULL,'2018-01-18 21:21:59','3','1','3','1','teste','3','3','3','0','1','1','2','1','2','2018-01-14 14:40:03','2018-01-13 15:40:03',NULL,'0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','1354','0','0','0','0','2018-01-13 14:40:03');
INSERT INTO `glpi_tickets` VALUES ('17','0','Teste','2018-01-13 14:44:20',NULL,NULL,'2018-01-18 21:21:59','2','1','3','1','TESTE','3','3','3','3','1','1','2','1','2','2018-01-14 14:44:20','2018-01-13 15:44:20',NULL,'0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','1071','0','0','0','0','2018-01-13 14:44:20');
INSERT INTO `glpi_tickets` VALUES ('18','0','configurar email','2018-01-13 14:55:19',NULL,NULL,'2018-01-18 21:21:59','12','1','12','1','teste','3','3','3','0','1','1','2','1','2','2018-01-14 14:55:19','2018-01-13 15:55:19',NULL,'0','0','1','2','0','2018-01-19 09:22:00','2018-01-18 21:52:00','0','0','0','0','0','0','0','0','2018-01-13 14:55:19');
INSERT INTO `glpi_tickets` VALUES ('19','0','Abrir chamado telegram','2018-01-18 21:54:03',NULL,NULL,'2018-05-21 07:59:31','6','1','6','1','teste
','3','3','3','0','1','1','2','1','2','2018-01-19 21:54:03','2018-01-18 22:54:03',NULL,'0','0','1','2','0','2018-05-21 19:59:31','2018-05-21 08:29:31','0','0','0','10577128','0','0','0','0','2018-01-18 21:54:03');

### Dump table glpi_tickets_tickets

DROP TABLE IF EXISTS `glpi_tickets_tickets`;
CREATE TABLE `glpi_tickets_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id_1` int(11) NOT NULL DEFAULT '0',
  `tickets_id_2` int(11) NOT NULL DEFAULT '0',
  `link` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id_1`,`tickets_id_2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets_users

DROP TABLE IF EXISTS `glpi_tickets_users`;
CREATE TABLE `glpi_tickets_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '1',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets_users` VALUES ('3','1','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('4','1','5','3','1','');
INSERT INTO `glpi_tickets_users` VALUES ('5','2','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('6','3','7','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('7','4','6','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('8','5','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('9','5','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('11','7','3','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('12','8','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('14','9','2','1','0','');
INSERT INTO `glpi_tickets_users` VALUES ('16','10','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('17','10','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('18','11','3','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('19','12','2','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('20','12','2','2','1','');
INSERT INTO `glpi_tickets_users` VALUES ('21','13','2','1','0','');
INSERT INTO `glpi_tickets_users` VALUES ('23','14','2','1','0','');
INSERT INTO `glpi_tickets_users` VALUES ('25','15','2','1','0','');
INSERT INTO `glpi_tickets_users` VALUES ('27','16','3','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('28','17','3','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('29','18','12','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('30','19','6','1','1','eduardo@eftech.com.br');

### Dump table glpi_ticketsatisfactions

DROP TABLE IF EXISTS `glpi_ticketsatisfactions`;
CREATE TABLE `glpi_ticketsatisfactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `date_begin` datetime DEFAULT NULL,
  `date_answered` datetime DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_id` (`tickets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettasks

DROP TABLE IF EXISTS `glpi_tickettasks`;
CREATE TABLE `glpi_tickettasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `state` (`state`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettasks` VALUES ('1','1','0','2018-01-09 17:22:33','2','2','Verificar a conexão do cabo de rede no desktop','0','0',NULL,NULL,'2','2','0','2018-01-11 06:12:13','2018-01-09 17:22:33','0','1');

### Dump table glpi_tickettemplatehiddenfields

DROP TABLE IF EXISTS `glpi_tickettemplatehiddenfields`;
CREATE TABLE `glpi_tickettemplatehiddenfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatemandatoryfields

DROP TABLE IF EXISTS `glpi_tickettemplatemandatoryfields`;
CREATE TABLE `glpi_tickettemplatemandatoryfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatemandatoryfields` VALUES ('1','1','21');

### Dump table glpi_tickettemplatepredefinedfields

DROP TABLE IF EXISTS `glpi_tickettemplatepredefinedfields`;
CREATE TABLE `glpi_tickettemplatepredefinedfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `tickettemplates_id_id_num` (`tickettemplates_id`,`num`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('3','1','37','1');
INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('4','1','30','2');

### Dump table glpi_tickettemplates

DROP TABLE IF EXISTS `glpi_tickettemplates`;
CREATE TABLE `glpi_tickettemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplates` VALUES ('1','Default','0','1',NULL);

### Dump table glpi_ticketvalidations

DROP TABLE IF EXISTS `glpi_ticketvalidations`;
CREATE TABLE `glpi_ticketvalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `tickets_id` (`tickets_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ticketvalidations` VALUES ('1','0','2','2','2','Solicito confirmação para encerrar o chamado.','OK','3','2018-01-11 06:54:19','2018-01-11 06:55:17','1');

### Dump table glpi_transfers

DROP TABLE IF EXISTS `glpi_transfers`;
CREATE TABLE `glpi_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keep_ticket` int(11) NOT NULL DEFAULT '0',
  `keep_networklink` int(11) NOT NULL DEFAULT '0',
  `keep_reservation` int(11) NOT NULL DEFAULT '0',
  `keep_history` int(11) NOT NULL DEFAULT '0',
  `keep_device` int(11) NOT NULL DEFAULT '0',
  `keep_infocom` int(11) NOT NULL DEFAULT '0',
  `keep_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `clean_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `keep_dc_phone` int(11) NOT NULL DEFAULT '0',
  `clean_dc_phone` int(11) NOT NULL DEFAULT '0',
  `keep_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `clean_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `keep_dc_printer` int(11) NOT NULL DEFAULT '0',
  `clean_dc_printer` int(11) NOT NULL DEFAULT '0',
  `keep_supplier` int(11) NOT NULL DEFAULT '0',
  `clean_supplier` int(11) NOT NULL DEFAULT '0',
  `keep_contact` int(11) NOT NULL DEFAULT '0',
  `clean_contact` int(11) NOT NULL DEFAULT '0',
  `keep_contract` int(11) NOT NULL DEFAULT '0',
  `clean_contract` int(11) NOT NULL DEFAULT '0',
  `keep_software` int(11) NOT NULL DEFAULT '0',
  `clean_software` int(11) NOT NULL DEFAULT '0',
  `keep_document` int(11) NOT NULL DEFAULT '0',
  `clean_document` int(11) NOT NULL DEFAULT '0',
  `keep_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `clean_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `keep_cartridge` int(11) NOT NULL DEFAULT '0',
  `keep_consumable` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `keep_disk` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_transfers` VALUES ('1','complete','2','2','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',NULL,NULL,'1');

### Dump table glpi_usercategories

DROP TABLE IF EXISTS `glpi_usercategories`;
CREATE TABLE `glpi_usercategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_useremails

DROP TABLE IF EXISTS `glpi_useremails`;
CREATE TABLE `glpi_useremails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`email`),
  KEY `email` (`email`),
  KEY `is_default` (`is_default`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_useremails` VALUES ('1','7','1','0','9if1hr+3vas8i1bhxkck@guerrillamail.com');
INSERT INTO `glpi_useremails` VALUES ('2','6','1','0','eduardo@eftech.com.br');

### Dump table glpi_users

DROP TABLE IF EXISTS `glpi_users`;
CREATE TABLE `glpi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `language` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` int(11) NOT NULL DEFAULT '0',
  `list_limit` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `auths_id` int(11) NOT NULL DEFAULT '0',
  `authtype` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_sync` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `usercategories_id` int(11) NOT NULL DEFAULT '0',
  `date_format` int(11) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `names_format` int(11) DEFAULT NULL,
  `csv_delimiter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_ids_visible` tinyint(1) DEFAULT NULL,
  `use_flat_dropdowntree` tinyint(1) DEFAULT NULL,
  `show_jobs_at_login` tinyint(1) DEFAULT NULL,
  `priority_1` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_2` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_3` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_4` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_5` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_6` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `followup_private` tinyint(1) DEFAULT NULL,
  `task_private` tinyint(1) DEFAULT NULL,
  `default_requesttypes_id` int(11) DEFAULT NULL,
  `password_forget_token` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_forget_token_date` datetime DEFAULT NULL,
  `user_dn` text COLLATE utf8_unicode_ci,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_count_on_tabs` tinyint(1) DEFAULT NULL,
  `refresh_ticket_list` int(11) DEFAULT NULL,
  `set_default_tech` tinyint(1) DEFAULT NULL,
  `personal_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal_token_date` datetime DEFAULT NULL,
  `api_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `api_token_date` datetime DEFAULT NULL,
  `display_count_on_home` int(11) DEFAULT NULL,
  `notification_to_myself` tinyint(1) DEFAULT NULL,
  `duedateok_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_less` int(11) DEFAULT NULL,
  `duedatecritical_less` int(11) DEFAULT NULL,
  `duedatewarning_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_options` text COLLATE utf8_unicode_ci,
  `is_deleted_ldap` tinyint(1) NOT NULL DEFAULT '0',
  `pdffont` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `keep_devices_when_purging_item` tinyint(1) DEFAULT NULL,
  `privatebookmarkorder` longtext COLLATE utf8_unicode_ci,
  `backcreated` tinyint(1) DEFAULT NULL,
  `task_state` int(11) DEFAULT NULL,
  `layout` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `palette` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_timeline` tinyint(1) DEFAULT NULL,
  `ticket_timeline_keep_replaced_tabs` tinyint(1) DEFAULT NULL,
  `set_default_requester` tinyint(1) DEFAULT NULL,
  `lock_autolock_mode` tinyint(1) DEFAULT NULL,
  `lock_directunlock_notification` tinyint(1) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `highcontrast_css` tinyint(1) DEFAULT '0',
  `plannings` text COLLATE utf8_unicode_ci,
  `sync_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicityloginauth` (`name`,`authtype`,`auths_id`),
  KEY `firstname` (`firstname`),
  KEY `realname` (`realname`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `locations_id` (`locations_id`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `usercategories_id` (`usercategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `authitem` (`authtype`,`auths_id`),
  KEY `is_deleted_ldap` (`is_deleted_ldap`),
  KEY `date_creation` (`date_creation`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `sync_field` (`sync_field`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_users` VALUES ('2','glpi','$2y$10$rXXzbc2ShaiCldwkw4AZL.n.9QSH7c0c9XJAyyjrbL9BwmWditAYm','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-08-13 18:19:53','2018-05-21 07:53:02',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'cr6cOfasvIHBohDjed6jdMH75t2ZUhlcsPQJSf2m','2017-11-21 10:15:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL);
INSERT INTO `glpi_users` VALUES ('3','post-only','$2y$10$kYtVmZuwGe7nbsjiXzLdn.14k9sMzHp1qfxWxM24kW.3urVW7xfcW','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-01-13 15:03:27','2018-01-13 13:31:10',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'KHPzxTpiFkEJAEaPnzpl6pukcb3gGXlOSwMN8VHZ','2018-01-13 13:31:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL);
INSERT INTO `glpi_users` VALUES ('4','tech','$2y$10$.xEgErizkp6Az0z.DHyoeOoenuh0RcsX4JapBk2JMD6VI17KtB1lO','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-01-08 10:52:01','2018-01-08 10:41:00',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'NiK8F0XyMv5O8rm9isjMeyoFPgJETCcEqevn3UXT','2018-01-08 10:19:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL);
INSERT INTO `glpi_users` VALUES ('5','normal','$2y$10$Z6doq4zVHkSPZFbPeXTCluN1Q/r0ryZ3ZsSJncJqkN3.8cRiN0NV.','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-01-09 10:20:32','2018-01-09 10:20:34',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'gQDjIAtC2VjitJx0vu99caVwPRzY2YYjiWaYmfX2','2018-01-09 10:20:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL);
INSERT INTO `glpi_users` VALUES ('6','eduardo','$2y$10$fhTqGMq1rxgygsfXzEuDB./Mwj/JOX4ellCBoEr8Kp5YYXgJg8KCm','','','','Fraga','Eduardo','0',NULL,'0',NULL,'1','','0','1','2018-01-18 21:53:38','2018-01-08 10:55:33',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'zaJauI7vAmTfnUKVmnalsVNAo6Dm8uzhQLexiAmu','2018-01-08 10:55:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-08 10:17:49',NULL,NULL,NULL);
INSERT INTO `glpi_users` VALUES ('7','Cliente 1',NULL,'','','','','','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-01-11 18:41:21',NULL,'0','1','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-11 18:37:03','0',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('8','vasco','','','','','Vilaverde','Vasco','0',NULL,'0',NULL,'1','','1','3',NULL,'2018-01-13 14:54:35','2018-01-13 14:54:35','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CN=Vasco Vilaverde,CN=Users,DC=fameconsultoria,DC=local','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-13 14:54:35','0',NULL,'9e13a01b-5352-4f96-acc8-7bb33050c4a9');
INSERT INTO `glpi_users` VALUES ('9','tatiana','','','','','Guedes','Tatiana','0',NULL,'0',NULL,'1','','1','3',NULL,'2018-01-13 14:54:35','2018-01-13 14:54:35','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CN=Tatiana Guedes,CN=Users,DC=fameconsultoria,DC=local','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-13 14:54:35','0',NULL,'0060856e-18fe-4fa6-89f3-e9b27fb85bf9');
INSERT INTO `glpi_users` VALUES ('10','luiz','','','','','Ribas','Luiz','0',NULL,'0',NULL,'1','','1','3',NULL,'2018-01-13 14:54:35','2018-01-13 14:54:35','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CN=Luiz Ribas,CN=Users,DC=fameconsultoria,DC=local','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-13 14:54:35','0',NULL,'3dcbc575-7fda-4a9b-a995-e6857224c518');
INSERT INTO `glpi_users` VALUES ('11','gilberto','','','','','Gil','Gilberto','0',NULL,'0',NULL,'1','','1','3',NULL,'2018-01-13 14:54:35','2018-01-13 14:54:35','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CN=Gilberto Gil,CN=Users,DC=fameconsultoria,DC=local','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-13 14:54:35','0',NULL,'d1dca6f8-44a9-4ba5-8fe1-71b742d85a6a');
INSERT INTO `glpi_users` VALUES ('12','alda','','','','','Nolasco','Alda','0',NULL,'0',NULL,'1','','1','3','2018-01-13 14:55:07','2018-01-13 14:55:07','2018-01-13 14:55:07','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CN=Alda Nolasco,CN=Users,DC=fameconsultoria,DC=local','',NULL,NULL,NULL,'nyuCtxBZ0IQF9bfF2neDvvrYxT2EqUOia5tkeVeX','2018-01-13 14:55:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-01-13 14:54:35',NULL,NULL,'42115f77-251f-42d0-bbc7-95129da9a76a');

### Dump table glpi_usertitles

DROP TABLE IF EXISTS `glpi_usertitles`;
CREATE TABLE `glpi_usertitles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinestates

DROP TABLE IF EXISTS `glpi_virtualmachinestates`;
CREATE TABLE `glpi_virtualmachinestates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinesystems

DROP TABLE IF EXISTS `glpi_virtualmachinesystems`;
CREATE TABLE `glpi_virtualmachinesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinetypes

DROP TABLE IF EXISTS `glpi_virtualmachinetypes`;
CREATE TABLE `glpi_virtualmachinetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_vlans

DROP TABLE IF EXISTS `glpi_vlans`;
CREATE TABLE `glpi_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `tag` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tag` (`tag`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_vlans` VALUES ('1','0','0','vlan200','Acesso a Internet','200','2017-12-07 10:28:13','2017-12-07 10:28:13');
INSERT INTO `glpi_vlans` VALUES ('2','0','0','Default','','1','2017-12-07 10:29:35','2017-12-07 10:29:35');

### Dump table glpi_wifinetworks

DROP TABLE IF EXISTS `glpi_wifinetworks`;
CREATE TABLE `glpi_wifinetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `essid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, access_point',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `essid` (`essid`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

